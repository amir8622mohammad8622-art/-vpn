import { db } from "@/db";
import { inbounds, panels, vpnUsers } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import type { Inbound, Panel, VpnUser } from "@/db/schema";
import {
  detectPanel,
  fetchInbounds,
  marzbanLogin,
  marzbanUserOp,
  wgEasyClientOp,
  wgEasyLogin,
  xuiClientOp,
  xuiLogin,
  type PanelKind,
} from "./panel/adapters";

export { detectPanel };
export type { PanelKind };

const kind = (p: Panel): PanelKind =>
  (["demo", "xui", "marzban", "wgeasy"] as PanelKind[]).includes(p.type as PanelKind)
    ? (p.type as PanelKind)
    : p.type === "demo"
      ? "demo"
      : "xui";

const gbBytes = (gb: number) => Math.round(gb * 1024 * 1024 * 1024);

/* ------------------------------------------------------------------ */
/* Client operations (create / delete / toggle) — multi-panel          */
/* ------------------------------------------------------------------ */

export async function pushClient(
  panel: Panel,
  inbound: Inbound,
  vu: { clientUuid: string; email: string; totalGB: number; expiryMs: number; limitIp: number }
): Promise<{ ok: boolean; secret?: string }> {
  const k = kind(panel);
  if (k === "demo") return { ok: true };
  try {
    if (k === "xui") {
      const cookie = await xuiLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (!cookie) return { ok: false };
      const client: Record<string, unknown> = {
        id: vu.clientUuid,
        email: vu.email,
        totalGB: gbBytes(vu.totalGB),
        expiryTime: vu.expiryMs,
        limitIp: vu.limitIp,
        enable: true,
        tgId: "",
        subId: "",
      };
      if (inbound.flow && inbound.protocol === "vless") client.flow = inbound.flow;
      const ok = await xuiClientOp(panel.baseUrl, cookie, "add", inbound.remoteId, client);
      return { ok };
    }

    if (k === "marzban") {
      const token = await marzbanLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (!token) return { ok: false };
      const ok = await marzbanUserOp(panel.baseUrl, token, "add", {
        username: vu.email,
        protocol: inbound.protocol,
        tag: inbound.remoteTag || inbound.remark,
        dataLimitBytes: gbBytes(vu.totalGB),
        expireUnix: Math.floor(vu.expiryMs / 1000),
        status: "active",
      });
      return { ok };
    }

    if (k === "wgeasy") {
      const cookie = await wgEasyLogin(panel.baseUrl, panel.apiPassword);
      if (!cookie) return { ok: false };
      const r = await wgEasyClientOp(panel.baseUrl, cookie, "create", vu.email, undefined);
      if (!r.ok) return { ok: false };
      return {
        ok: true,
        secret: JSON.stringify({
          wgClientId: r.clientId,
          address: r.address,
          conf: r.config,
        }),
      };
    }
  } catch {
    /* fallthrough */
  }
  return { ok: true }; // never block user flow if push fails silently
}

export async function deleteClientFromPanel(panel: Panel, inbound: Inbound, vu: VpnUser): Promise<void> {
  const k = kind(panel);
  try {
    if (k === "xui") {
      const cookie = await xuiLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (cookie) await xuiClientOp(panel.baseUrl, cookie, "del", inbound.remoteId, { id: vu.clientUuid });
    } else if (k === "marzban") {
      const token = await marzbanLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (token)
        await marzbanUserOp(panel.baseUrl, token, "del", {
          username: vu.email,
          protocol: vu.protocol,
          tag: inbound.remoteTag || inbound.remark,
          dataLimitBytes: 0,
          expireUnix: 0,
          status: "disabled",
        });
    } else if (k === "wgeasy") {
      const cookie = await wgEasyLogin(panel.baseUrl, panel.apiPassword);
      let cid = "";
      try { cid = JSON.parse(vu.secret || "{}").wgClientId ?? ""; } catch { /* noop */ }
      if (cookie && cid) await wgEasyClientOp(panel.baseUrl, cookie, "del", vu.email, cid);
    }
  } catch {
    /* best effort */
  }
}

export async function setPanelClientEnabled(
  panel: Panel,
  inbound: Inbound,
  vu: VpnUser,
  enable: boolean
): Promise<void> {
  const k = kind(panel);
  try {
    if (k === "xui") {
      const cookie = await xuiLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (!cookie) return;
      const client: Record<string, unknown> = {
        id: vu.clientUuid,
        email: vu.email,
        totalGB: gbBytes(vu.dataLimitGb),
        expiryTime: new Date(vu.expireAt).getTime(),
        limitIp: vu.ipLimit,
        enable,
      };
      if (inbound.flow && inbound.protocol === "vless") client.flow = inbound.flow;
      await xuiClientOp(panel.baseUrl, cookie, "update", inbound.remoteId, client);
    } else if (k === "marzban") {
      const token = await marzbanLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
      if (token)
        await marzbanUserOp(panel.baseUrl, token, "update", {
          username: vu.email,
          protocol: vu.protocol,
          tag: inbound.remoteTag || inbound.remark,
          dataLimitBytes: gbBytes(vu.dataLimitGb),
          expireUnix: Math.floor(new Date(vu.expireAt).getTime() / 1000),
          status: enable ? "active" : "disabled",
        });
    } else if (k === "wgeasy") {
      const cookie = await wgEasyLogin(panel.baseUrl, panel.apiPassword);
      let cid = "";
      try { cid = JSON.parse(vu.secret || "{}").wgClientId ?? ""; } catch { /* noop */ }
      if (cookie && cid) await wgEasyClientOp(panel.baseUrl, cookie, enable ? "enable" : "disable", vu.email, cid);
    }
  } catch {
    /* best effort */
  }
}

/* ------------------------------------------------------------------ */
/* Sync: pull inbounds from real panels; simulate traffic on demo     */
/* ------------------------------------------------------------------ */

export async function syncPanel(panelId: number): Promise<{ ok: boolean; added: number; kind?: string }> {
  const [panel] = await db.select().from(panels).where(eq(panels.id, panelId));
  if (!panel) return { ok: false, added: 0 };
  const k = kind(panel);
  let status: "online" | "offline" = "online";
  let added = 0;

  if (k !== "demo") {
    try {
      let creds: { cookie?: string; token?: string } | null = null;
      if (k === "xui") {
        const cookie = await xuiLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
        creds = cookie ? { cookie } : null;
      } else if (k === "marzban") {
        const token = await marzbanLogin(panel.baseUrl, panel.apiUsername, panel.apiPassword);
        creds = token ? { token } : null;
      } else if (k === "wgeasy") {
        const cookie = await wgEasyLogin(panel.baseUrl, panel.apiPassword);
        creds = cookie ? { cookie } : null;
      }
      if (!creds) throw new Error("login failed");

      const list = await fetchInbounds(k, panel.baseUrl, creds, panel.name);
      if (!list) throw new Error("inbounds unavailable");

      for (const raw of list) {
        const existing = await db
          .select()
          .from(inbounds)
          .where(and(eq(inbounds.panelId, panel.id), eq(inbounds.remoteId, raw.remoteId), eq(inbounds.remoteTag, raw.remoteTag)));
        const row = {
          remark: raw.remark,
          protocol: raw.protocol,
          port: raw.port || 443,
          network: raw.network || "tcp",
          security: raw.security || "none",
          sni: raw.sni || panel.subHost,
          path: raw.path,
          hostHeader: raw.hostHeader,
          pbk: raw.pbk,
          sid: raw.sid,
          flow: raw.flow,
          remoteTag: raw.remoteTag,
        };
        if (existing.length) {
          await db.update(inbounds).set(row).where(eq(inbounds.id, existing[0].id));
        } else {
          await db.insert(inbounds).values({ ...row, panelId: panel.id, remoteId: raw.remoteId });
          added++;
        }
      }
    } catch {
      status = "offline";
    }
  } else {
    /* demo panel: simulate consumption */
    const vusers = await db.select().from(vpnUsers).where(eq(vpnUsers.panelId, panel.id));
    for (const u of vusers) {
      if (u.status === "disabled") continue;
      const increment = Math.round((0.2 + Math.random() * 1.4) * 100) / 100;
      const used = Math.min(u.usedGb + increment, u.dataLimitGb);
      const expired = new Date(u.expireAt).getTime() < Date.now();
      const nextStatus = expired ? "expired" : used >= u.dataLimitGb ? "depleted" : "active";
      await db
        .update(vpnUsers)
        .set({ usedGb: used, status: nextStatus, updatedAt: new Date() })
        .where(eq(vpnUsers.id, u.id));
    }
  }

  /* refresh cached counters */
  const ibs = await db.select().from(inbounds).where(eq(inbounds.panelId, panel.id));
  for (const ib of ibs) {
    const count = await db
      .select({ id: vpnUsers.id })
      .from(vpnUsers)
      .where(and(eq(vpnUsers.inboundId, ib.id), eq(vpnUsers.status, "active")));
    await db.update(inbounds).set({ totalClients: count.length }).where(eq(inbounds.id, ib.id));
  }

  await db
    .update(panels)
    .set({ status, lastSyncAt: new Date() })
    .where(eq(panels.id, panel.id));

  return { ok: status === "online", added, kind: k };
}
