import type { Inbound, Panel, VpnUser } from "@/db/schema";

const enc = encodeURIComponent;

function b64(s: string) {
  return Buffer.from(s, "utf-8").toString("base64");
}

export function configHost(panel: Panel, inbound: Inbound) {
  return panel.subHost || panel.baseUrl.replace(/^https?:\/\//, "").split("/")[0] || "vpn.example.com";
}

/** Build a shareable client config (URI or WireGuard ini) */
export function buildClientConfig(
  vu: VpnUser,
  inbound: Inbound,
  panel: Panel,
  remark: string
): string {
  const host = configHost(panel, inbound);
  const port = inbound.port;
  const name = enc(remark);

  switch (inbound.protocol) {
    case "vless": {
      const q = new URLSearchParams();
      q.set("type", inbound.network || "tcp");
      if (inbound.security && inbound.security !== "none") q.set("security", inbound.security);
      if (inbound.sni) q.set("sni", inbound.sni);
      if (inbound.security === "reality") {
        q.set("fp", "chrome");
        if (inbound.pbk) q.set("pbk", inbound.pbk);
        if (inbound.sid) q.set("sid", inbound.sid);
        if (inbound.flow) q.set("flow", inbound.flow);
      }
      if (inbound.network === "ws") {
        if (inbound.path) q.set("path", inbound.path);
        if (inbound.hostHeader) q.set("host", inbound.hostHeader);
      }
      return `vless://${vu.clientUuid}@${host}:${port}?${q.toString()}#${name}`;
    }
    case "vmess": {
      const obj = {
        v: "2",
        ps: remark,
        add: host,
        port: String(port),
        id: vu.clientUuid,
        aid: "0",
        scy: "auto",
        net: inbound.network || "ws",
        type: "none",
        host: inbound.hostHeader || inbound.sni,
        path: inbound.path || "/",
        tls: inbound.security === "tls" ? "tls" : "",
        sni: inbound.sni,
      };
      return `vmess://${b64(JSON.stringify(obj))}`;
    }
    case "trojan": {
      const q = new URLSearchParams();
      q.set("security", "tls");
      if (inbound.sni) q.set("sni", inbound.sni);
      q.set("type", inbound.network === "ws" ? "ws" : "tcp");
      if (inbound.network === "ws") {
        if (inbound.path) q.set("path", inbound.path);
        if (inbound.hostHeader) q.set("host", inbound.hostHeader);
      }
      return `trojan://${vu.clientUuid}@${host}:${port}?${q.toString()}#${name}`;
    }
    case "shadowsocks": {
      const secret = safeSecret(vu);
      const password = secret.password || vu.clientUuid.replace(/-/g, "").slice(0, 16);
      const method = inbound.method || "chacha20-ietf-poly1305";
      return `ss://${b64(`${method}:${password}`)}@${host}:${port}#${name}`;
    }
    case "wireguard": {
      const secret = safeSecret(vu);
      if (secret.conf && secret.conf.includes("[Interface]")) return secret.conf;
      return [
        "[Interface]",
        `PrivateKey = ${secret.privateKey || ""}`,
        `Address = ${secret.address || "10.66.0.2/32"}`,
        "DNS = 1.1.1.1, 8.8.8.8",
        "",
        "[Peer]",
        `PublicKey = ${inbound.pbk || secret.publicKey || ""}`,
        `AllowedIPs = 0.0.0.0/0, ::/0`,
        `Endpoint = ${host}:${port}`,
        "PersistentKeepalive = 25",
      ].join("\n");
    }
    default:
      return `# ${remark}`;
  }
}

export function safeSecret(vu: VpnUser): {
  privateKey?: string;
  publicKey?: string;
  address?: string;
  password?: string;
  conf?: string;
  wgClientId?: string;
} {
  try {
    return vu.secret ? JSON.parse(vu.secret) : {};
  } catch {
    return {};
  }
}

/** Aggregate subscription-userinfo header value */
export function subUserInfo(users: VpnUser[]): string {
  const total = users.reduce((a, u) => a + u.dataLimitGb, 0);
  const used = users.reduce((a, u) => a + u.usedGb, 0);
  const expires = users
    .map((u) => new Date(u.expireAt).getTime())
    .filter((t) => t > Date.now())
    .sort((a, b) => a - b);
  const toBytes = (gb: number) => Math.round(gb * 1024 * 1024 * 1024);
  return `upload=0;download=${toBytes(used)};total=${toBytes(total)};expire=${
    expires.length ? Math.floor(expires[0] / 1000) : 0
  }`;
}
