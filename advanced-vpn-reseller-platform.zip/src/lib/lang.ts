export type Lang = "fa" | "en";
export const dirOf = (l: Lang): "rtl" | "ltr" => (l === "fa" ? "rtl" : "ltr");
