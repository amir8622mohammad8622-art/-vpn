import nodemailer from "nodemailer";
import crypto from "crypto";
import { db } from "@/db";
import { otpCodes } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";

export function generateOtp(): string {
  return String(crypto.randomInt(100000, 999999));
}

function getTransporter() {
  return nodemailer.createTransport({
    host: process.env.SMTP_HOST || "smtp.gmail.com",
    port: Number(process.env.SMTP_PORT || 587),
    secure: process.env.SMTP_SECURE === "true",
    auth: {
      user: process.env.SMTP_USER || "",
      pass: process.env.SMTP_PASS || "",
    },
  });
}

export async function sendOtpEmail(email: string, code: string, purpose: string): Promise<boolean> {
  const subjects: Record<string, string> = {
    register: "هکتور | کد تایید ثبت‌نام",
    login: "هکتور | کد ورود سریع",
    reset: "هکتور | بازیابی رمز عبور",
  };
  const html = `
    <div dir="rtl" style="font-family:Tahoma,sans-serif;max-width:420px;margin:0 auto;background:#0d1020;border-radius:20px;padding:36px;border:1px solid rgba(212,168,0,0.3);">
      <div style="text-align:center;margin-bottom:24px;">
        <img src="cid:logo" alt="هکتور" width="80" style="border-radius:16px;" />
      </div>
      <h2 style="color:#f5c518;margin:0 0 8px;font-size:20px;text-align:center;">${subjects[purpose] || "کد تایید"}</h2>
      <p style="color:#b0b8d0;font-size:14px;text-align:center;margin:0 0 24px;">کد تایید شما:</p>
      <div style="background:linear-gradient(135deg,#1a1f38,#0d1020);border:2px solid #d4a800;border-radius:16px;padding:20px;text-align:center;margin:0 0 20px;">
        <span style="font-size:36px;font-weight:900;letter-spacing:12px;color:#f5c518;font-family:monospace;">${code}</span>
      </div>
      <p style="color:#6b7394;font-size:12px;text-align:center;margin:0;">این کد ۵ دقیقه اعتبار دارد · هکتور VPN</p>
    </div>
  `;
  try {
    const transporter = getTransporter();
    await transporter.sendMail({
      from: process.env.SMTP_FROM || process.env.SMTP_USER || "noreply@hector.vpn",
      to: email,
      subject: subjects[purpose] || "کد تایید هکتور",
      html,
    });
    return true;
  } catch (e) {
    console.error("Email send failed:", e);
    return false;
  }
}

export async function createAndSendOtp(email: string, purpose: string): Promise<{ ok: boolean; code?: string }> {
  const code = generateOtp();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 min

  await db.insert(otpCodes).values({ email: email.toLowerCase().trim(), code, purpose, expiresAt });

  // If SMTP isn't configured, we store the code but return it (for dev/testing)
  if (!process.env.SMTP_USER) {
    console.log(`[OTP] ${purpose} code for ${email}: ${code} (SMTP not configured — showing in response)`);
    return { ok: true, code };
  }

  const sent = await sendOtpEmail(email, code, purpose);
  return { ok: sent };
}

export async function verifyOtp(email: string, code: string, purpose: string): Promise<boolean> {
  const [row] = await db
    .select()
    .from(otpCodes)
    .where(
      and(
        eq(otpCodes.email, email.toLowerCase().trim()),
        eq(otpCodes.code, code.trim()),
        eq(otpCodes.purpose, purpose),
        eq(otpCodes.used, false),
        gt(otpCodes.expiresAt, new Date())
      )
    )
    .limit(1);

  if (!row) return false;
  await db.update(otpCodes).set({ used: true }).where(eq(otpCodes.id, row.id));
  return true;
}
