"use server";

import { and, eq, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { inbounds, panels, transactions, users, vpnUsers } from "@/db/schema";
import { getSession } from "@/lib/auth";
import {
  deleteClientFromPanel,
  pushClient,
  setPanelClientEnabled,
} from "@/lib/panel";
import { addDays, clamp, genWireGuardKeys, newUuid, randomToken } from "@/lib/utils";

type Res<T = undefined> = { ok: boolean; error?: string; data?: T };

function revalidateAll() {
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/services");
  revalidatePath("/dashboard/users");
  revalidatePath("/dashboard/wallet");
  revalidatePath("/dashboard/admin");
}

async function chargeWallet(
  userId: number,
  amount: number,
  description: string
): Promise<{ ok: boolean; balanceAfter?: number }> {
  const [u] = await db.select().from(users).where(eq(users.id, userId));
  if (!u || u.balance < amount) return { ok: false };
  const nb = u.balance - amount;
  await db
    .update(users)
    .set({ balance: nb, totalSpent: u.totalSpent + amount })
    .where(eq(users.id, userId));
  await db.insert(transactions).values({
    userId,
    type: "purchase",
    amount: -amount,
    balanceAfter: nb,
    method: "wallet",
    status: "completed",
    description,
  });
  return { ok: true, balanceAfter: nb };
}

export async function createVpnUser(input: {
  inboundId: number;
  name: string;
  gb: number;
  days: number;
  ipLimit: number;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };

  const name = input.name.trim().slice(0, 120);
  if (name.length < 2) return { ok: false, error: "err.nameShort" };

  const gb = clamp(Math.round(input.gb), 1, 2048);
  const days = clamp(Math.round(input.days), 1, 1095);
  const ipLimit = clamp(Math.round(input.ipLimit), 0, 10);

  const [ib] = await db.select().from(inbounds).where(eq(inbounds.id, input.inboundId));
  if (!ib || !ib.enabled) return { ok: false, error: "err.notFound" };
  const [panel] = await db.select().from(panels).where(eq(panels.id, ib.panelId));
  if (!panel || panel.hidden) return { ok: false, error: "err.notFound" };

  const months = Math.ceil(days / 30);
  const cost = ib.pricePerMonth * months + Math.round(gb * ib.pricePerGb);

  const paid = await chargeWallet(s.uid, cost, `${name} · ${ib.remark}`);
  if (!paid.ok) return { ok: false, error: "err.insufficient" };

  const uuid = newUuid();
  const email = `${s.uid}.${randomToken(4)}`.toLowerCase();
  let secret = "";
  if (ib.protocol === "wireguard") secret = JSON.stringify(genWireGuardKeys());
  if (ib.protocol === "shadowsocks")
    secret = JSON.stringify({ password: randomToken(12) });

  const [vu] = await db
    .insert(vpnUsers)
    .values({
      ownerId: s.uid,
      panelId: panel.id,
      inboundId: ib.id,
      clientUuid: uuid,
      email,
      label: name,
      protocol: ib.protocol,
      dataLimitGb: gb,
      expireAt: addDays(new Date(), days),
      ipLimit,
      status: "active",
      secret,
    })
    .returning();

  await db
    .update(inbounds)
    .set({ totalClients: sql`${inbounds.totalClients} + 1` })
    .where(eq(inbounds.id, ib.id));

  const pushed = await pushClient(panel, ib, {
    clientUuid: uuid,
    email,
    totalGB: gb,
    expiryMs: vu.expireAt.getTime(),
    limitIp: ipLimit,
  });
  if (pushed.secret) {
    await db.update(vpnUsers).set({ secret: pushed.secret }).where(eq(vpnUsers.id, vu.id));
  }

  revalidateAll();
  return { ok: true };
}

async function ownedUser(id: number, uid: number, isAdmin: boolean) {
  const [vu] = await db.select().from(vpnUsers).where(eq(vpnUsers.id, id));
  if (!vu || (!isAdmin && vu.ownerId !== uid)) return null;
  return vu;
}

export async function renewVpnUser(input: {
  id: number;
  addGb: number;
  addDays: number;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };

  const addGb = clamp(Math.round(input.addGb), 0, 2048);
  const extendDays = clamp(Math.round(input.addDays), 0, 1095);
  if (addGb === 0 && extendDays === 0) return { ok: false, error: "err.generic" };

  const vu = await ownedUser(input.id, s.uid, s.role === "admin");
  if (!vu) return { ok: false, error: "err.notFound" };
  const [ib] = await db.select().from(inbounds).where(eq(inbounds.id, vu.inboundId));
  if (!ib) return { ok: false, error: "err.notFound" };

  const months = Math.ceil(extendDays / 30);
  const cost = ib.pricePerMonth * months + Math.round(addGb * ib.pricePerGb);
  const paid = await chargeWallet(s.uid, cost, `renew:${vu.label}`);
  if (!paid.ok) return { ok: false, error: "err.insufficient" };

  const base = Math.max(new Date(vu.expireAt).getTime(), Date.now());
  const newExpire = new Date(base + extendDays * 86400000);
  const newLimit = vu.dataLimitGb + addGb;
  const status =
    newExpire.getTime() < Date.now()
      ? "expired"
      : vu.usedGb >= newLimit
        ? "depleted"
        : "active";

  await db
    .update(vpnUsers)
    .set({
      dataLimitGb: newLimit,
      expireAt: newExpire,
      status,
      updatedAt: new Date(),
    })
    .where(eq(vpnUsers.id, vu.id));

  const [panel] = await db.select().from(panels).where(eq(panels.id, vu.panelId));
  if (panel)
    await setPanelClientEnabled(panel, ib, { ...vu, dataLimitGb: newLimit, expireAt: newExpire }, status === "active");

  revalidateAll();
  return { ok: true };
}

export async function toggleVpnUser(id: number): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const vu = await ownedUser(id, s.uid, s.role === "admin");
  if (!vu) return { ok: false, error: "err.notFound" };

  const next = vu.status === "disabled" ? "active" : "disabled";
  await db
    .update(vpnUsers)
    .set({ status: next, updatedAt: new Date() })
    .where(eq(vpnUsers.id, id));

  const [ib] = await db.select().from(inbounds).where(eq(inbounds.id, vu.inboundId));
  const [panel] = await db.select().from(panels).where(eq(panels.id, vu.panelId));
  if (ib && panel) await setPanelClientEnabled(panel, ib, vu, next === "active");

  revalidateAll();
  return { ok: true };
}

export async function resetUsage(id: number): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const vu = await ownedUser(id, s.uid, s.role === "admin");
  if (!vu) return { ok: false, error: "err.notFound" };

  const [ib] = await db.select().from(inbounds).where(eq(inbounds.id, vu.inboundId));
  if (!ib) return { ok: false, error: "err.notFound" };

  if (vu.usedGb > 0.01) {
    const cost = Math.round(vu.usedGb * ib.pricePerGb);
    const paid = await chargeWallet(s.uid, cost, `reset:${vu.label}`);
    if (!paid.ok) return { ok: false, error: "err.insufficient" };
  }

  const expired = new Date(vu.expireAt).getTime() < Date.now();
  await db
    .update(vpnUsers)
    .set({ usedGb: 0, status: expired ? "expired" : "active", updatedAt: new Date() })
    .where(eq(vpnUsers.id, id));

  revalidateAll();
  return { ok: true };
}

export async function deleteVpnUser(id: number): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const vu = await ownedUser(id, s.uid, s.role === "admin");
  if (!vu) return { ok: false, error: "err.notFound" };

  const [ib] = await db.select().from(inbounds).where(eq(inbounds.id, vu.inboundId));
  const [panel] = await db.select().from(panels).where(eq(panels.id, vu.panelId));
  if (ib && panel) await deleteClientFromPanel(panel, ib, vu);

  await db.delete(vpnUsers).where(eq(vpnUsers.id, id));
  if (ib && vu.status === "active")
    await db
      .update(inbounds)
      .set({ totalClients: sql`GREATEST(${inbounds.totalClients} - 1, 0)` })
      .where(eq(inbounds.id, ib.id));

  revalidateAll();
  return { ok: true };
}
