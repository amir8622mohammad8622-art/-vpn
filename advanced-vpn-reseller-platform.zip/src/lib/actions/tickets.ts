"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { ticketMessages, tickets } from "@/db/schema";
import { getSession } from "@/lib/auth";

type Res = { ok: boolean; error?: string };

function revalidateTickets() {
  revalidatePath("/dashboard/tickets");
  revalidatePath("/dashboard/admin");
}

export async function createTicket(input: {
  subject: string;
  message: string;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const subject = input.subject.trim().slice(0, 160);
  const message = input.message.trim().slice(0, 2000);
  if (!subject || !message) return { ok: false, error: "err.generic" };

  const [t] = await db
    .insert(tickets)
    .values({ userId: s.uid, subject })
    .returning();
  await db.insert(ticketMessages).values({
    ticketId: t.id,
    senderId: s.uid,
    body: message,
  });
  revalidateTickets();
  return { ok: true };
}

export async function replyTicket(input: {
  ticketId: number;
  body: string;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const body = input.body.trim().slice(0, 2000);
  if (!body) return { ok: false, error: "err.generic" };

  const [t] = await db.select().from(tickets).where(eq(tickets.id, input.ticketId));
  if (!t || (s.role !== "admin" && t.userId !== s.uid))
    return { ok: false, error: "err.forbidden" };
  if (t.status === "closed") return { ok: false, error: "err.generic" };

  await db.insert(ticketMessages).values({ ticketId: t.id, senderId: s.uid, body });
  await db
    .update(tickets)
    .set({
      status: s.role === "admin" ? "answered" : "open",
      updatedAt: new Date(),
    })
    .where(eq(tickets.id, t.id));
  revalidateTickets();
  return { ok: true };
}

export async function closeTicket(id: number): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const [t] = await db.select().from(tickets).where(eq(tickets.id, id));
  if (!t || (s.role !== "admin" && t.userId !== s.uid))
    return { ok: false, error: "err.forbidden" };
  await db
    .update(tickets)
    .set({ status: "closed", updatedAt: new Date() })
    .where(eq(tickets.id, id));
  revalidateTickets();
  return { ok: true };
}
