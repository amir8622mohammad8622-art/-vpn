"use server";

import { desc, eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { paymentRequests, settings, transactions } from "@/db/schema";
import { getSession } from "@/lib/auth";

type Res = { ok: boolean; error?: string };

export async function getSettingValue(key: string, fallback = ""): Promise<string> {
  const [row] = await db.select().from(settings).where(eq(settings.key, key));
  return row?.value ?? fallback;
}

export async function requestTopUp(input: {
  amount: number;
  receiptPath: string;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };

  const amount = Math.round(input.amount);
  const min = Number(await getSettingValue("min_charge", "50000")) || 0;
  if (!Number.isFinite(amount) || amount < min) return { ok: false, error: "err.generic" };
  if (!input.receiptPath) return { ok: false, error: "wal.receiptNeeded" };

  await db.insert(paymentRequests).values({
    userId: s.uid,
    amount,
    receiptPath: input.receiptPath,
    status: "pending",
  });
  await db.insert(transactions).values({
    userId: s.uid,
    type: "charge",
    amount,
    balanceAfter: 0,
    method: "card",
    status: "pending",
    description: `topup:${amount}`,
  });

  revalidatePath("/dashboard/wallet");
  revalidatePath("/dashboard/admin/payments");
  return { ok: true };
}
