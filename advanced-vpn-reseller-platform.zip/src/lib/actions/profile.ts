"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import { users } from "@/db/schema";
import { getSession, hashPassword, verifyPassword } from "@/lib/auth";
import { randomToken } from "@/lib/utils";

type Res = { ok: boolean; error?: string };

export async function updateBranding(input: {
  shopName: string;
  telegram: string;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  await db
    .update(users)
    .set({
      shopName: input.shopName.trim().slice(0, 90),
      telegram: input.telegram.trim().slice(0, 64),
    })
    .where(eq(users.id, s.uid));
  revalidatePath("/dashboard/branding");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function regenerateToken(): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  await db
    .update(users)
    .set({ subToken: randomToken(16) })
    .where(eq(users.id, s.uid));
  revalidatePath("/dashboard/branding");
  revalidatePath("/dashboard");
  return { ok: true };
}

export async function changePassword(input: {
  current: string;
  next: string;
}): Promise<Res> {
  const s = await getSession();
  if (!s) return { ok: false, error: "err.unauth" };
  const [u] = await db.select().from(users).where(eq(users.id, s.uid));
  if (!u) return { ok: false, error: "err.notFound" };
  if (input.next.length < 6) return { ok: false, error: "pf.tooShort" };
  const valid = await verifyPassword(input.current, u.passwordHash);
  if (!valid) return { ok: false, error: "pf.wrong" };
  await db
    .update(users)
    .set({ passwordHash: await hashPassword(input.next) })
    .where(eq(users.id, u.id));
  return { ok: true };
}
