"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  SESSION_COOKIE,
  hashPassword,
  signSession,
  verifyPassword,
} from "@/lib/auth";
import { randomToken } from "@/lib/utils";
import { createAndSendOtp, verifyOtp } from "@/lib/email";

type Res = { ok: boolean; error?: string; devCode?: string };

/* ---------- standard login with username/password ---------- */
export async function loginAction(input: {
  username: string;
  password: string;
}): Promise<Res> {
  const username = input.username.trim().toLowerCase();
  const [user] = await db.select().from(users).where(eq(users.username, username));
  if (!user) return { ok: false, error: "auth.err.invalid" };
  const valid = await verifyPassword(input.password, user.passwordHash);
  if (!valid) return { ok: false, error: "auth.err.invalid" };
  if (user.status === "banned") return { ok: false, error: "auth.err.banned" };

  const token = await signSession({
    uid: user.id,
    role: user.role as "admin" | "reseller",
    username: user.username,
  });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  });
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, user.id));
  return { ok: true };
}

/* ---------- Step 1: send OTP for registration ---------- */
export async function sendRegisterOtp(email: string): Promise<Res> {
  const e = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return { ok: false, error: "auth.err.emailBad" };

  // Check if email already registered
  const [exists] = await db.select().from(users).where(eq(users.email, e));
  if (exists) return { ok: false, error: "auth.err.emailUsed" };

  const result = await createAndSendOtp(e, "register");
  if (!result.ok) return { ok: false, error: "auth.err.emailSendFail" };
  return { ok: true, devCode: result.code }; // devCode only returned if SMTP not configured
}

/* ---------- Step 2: verify OTP & create account ---------- */
export async function registerAction(input: {
  username: string;
  password: string;
  email: string;
  code: string;
  shopName: string;
  telegram: string;
}): Promise<Res> {
  const username = input.username.trim().toLowerCase();
  const email = input.email.trim().toLowerCase();
  if (!/^[a-z0-9_.]{3,32}$/.test(username) || input.password.length < 3)
    return { ok: false, error: "auth.err.short" };
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return { ok: false, error: "auth.err.emailBad" };

  // Verify OTP
  const otpValid = await verifyOtp(email, input.code, "register");
  if (!otpValid) return { ok: false, error: "auth.err.otpBad" };

  const [existsUser] = await db.select().from(users).where(eq(users.username, username));
  if (existsUser) return { ok: false, error: "auth.err.exists" };

  const [existsEmail] = await db.select().from(users).where(eq(users.email, email));
  if (existsEmail) return { ok: false, error: "auth.err.emailUsed" };

  const passwordHash = await hashPassword(input.password);
  const [created] = await db
    .insert(users)
    .values({
      username,
      email,
      emailVerified: true,
      passwordHash,
      role: "reseller",
      shopName: input.shopName.trim().slice(0, 90) || username,
      telegram: input.telegram.trim().slice(0, 64),
      subToken: randomToken(16),
    })
    .returning();

  const token = await signSession({ uid: created.id, role: "reseller", username });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  });
  return { ok: true };
}

/* ---------- Quick login with email: send OTP ---------- */
export async function sendLoginOtp(email: string): Promise<Res> {
  const e = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return { ok: false, error: "auth.err.emailBad" };

  const [user] = await db.select().from(users).where(eq(users.email, e));
  if (!user) return { ok: false, error: "auth.err.emailNotFound" };
  if (user.status === "banned") return { ok: false, error: "auth.err.banned" };

  const result = await createAndSendOtp(e, "login");
  if (!result.ok) return { ok: false, error: "auth.err.emailSendFail" };
  return { ok: true, devCode: result.code };
}

/* ---------- Quick login with email: verify OTP ---------- */
export async function verifyLoginOtp(input: { email: string; code: string }): Promise<Res> {
  const email = input.email.trim().toLowerCase();
  const valid = await verifyOtp(email, input.code, "login");
  if (!valid) return { ok: false, error: "auth.err.otpBad" };

  const [user] = await db.select().from(users).where(eq(users.email, email));
  if (!user) return { ok: false, error: "auth.err.emailNotFound" };
  if (user.status === "banned") return { ok: false, error: "auth.err.banned" };

  const tok = await signSession({
    uid: user.id,
    role: user.role as "admin" | "reseller",
    username: user.username,
  });
  const store = await cookies();
  store.set(SESSION_COOKIE, tok, {
    httpOnly: true,
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7,
    path: "/",
  });
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, user.id));
  return { ok: true };
}

/* ---------- Password reset: send OTP ---------- */
export async function sendResetOtp(email: string): Promise<Res> {
  const e = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)) return { ok: false, error: "auth.err.emailBad" };

  const [user] = await db.select().from(users).where(eq(users.email, e));
  if (!user) return { ok: false, error: "auth.err.emailNotFound" };

  const result = await createAndSendOtp(e, "reset");
  if (!result.ok) return { ok: false, error: "auth.err.emailSendFail" };
  return { ok: true, devCode: result.code };
}

/* ---------- Password reset: verify OTP & set new password ---------- */
export async function resetPassword(input: {
  email: string;
  code: string;
  newPassword: string;
}): Promise<Res> {
  const email = input.email.trim().toLowerCase();
  if (input.newPassword.length < 6) return { ok: false, error: "pf.tooShort" };

  const valid = await verifyOtp(email, input.code, "reset");
  if (!valid) return { ok: false, error: "auth.err.otpBad" };

  const [user] = await db.select().from(users).where(eq(users.email, email));
  if (!user) return { ok: false, error: "auth.err.emailNotFound" };

  await db
    .update(users)
    .set({ passwordHash: await hashPassword(input.newPassword) })
    .where(eq(users.id, user.id));

  return { ok: true };
}

/* ---------- logout ---------- */
export async function logoutAction() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
  redirect("/");
}
