"use server";

import { eq } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { db } from "@/db";
import {
  inbounds,
  panels,
  paymentRequests,
  settings,
  transactions,
  users,
} from "@/db/schema";
import { requireAdmin, hashPassword } from "@/lib/auth";
import { detectPanel, syncPanel } from "@/lib/panel";
import { randomToken } from "@/lib/utils";

type Res = { ok: boolean; error?: string };

function revalidateAdmin() {
  revalidatePath("/dashboard/admin");
  revalidatePath("/dashboard/admin/panels");
  revalidatePath("/dashboard/admin/inbounds");
  revalidatePath("/dashboard/admin/users");
  revalidatePath("/dashboard/admin/payments");
  revalidatePath("/dashboard");
}

/* ---------------- panels ---------------- */

export async function addPanel(input: {
  name: string;
  baseUrl: string;
  username: string;
  password: string;
  type: "auto" | "demo";
  subHost: string;
  location: string;
}): Promise<Res> {
  await requireAdmin();
  if (!input.name.trim()) return { ok: false, error: "err.generic" };

  let panelType: string = input.type;
  if (input.type !== "demo") {
    const detected = await detectPanel(
      input.baseUrl.trim(),
      input.username.trim(),
      input.password
    );
    if (!detected) return { ok: false, error: "ap.detectFail" };
    panelType = detected.kind;
  }

  const [p] = await db
    .insert(panels)
    .values({
      name: input.name.trim().slice(0, 90),
      type: panelType,
      baseUrl: input.baseUrl.trim(),
      subHost: input.subHost.trim().slice(0, 140),
      apiUsername: input.username.trim(),
      apiPassword: input.password,
      location: (input.location.trim() || "WG").slice(0, 12),
      status: "online",
      lastSyncAt: new Date(),
    })
    .returning();

  if (p.type !== "demo") {
    const r = await syncPanel(p.id);
    if (!r.ok) return { ok: false, error: "ap.loginFail" };
  }
  revalidateAdmin();
  return { ok: true };
}

export async function syncPanelAction(id: number): Promise<Res> {
  await requireAdmin();
  await syncPanel(id);
  revalidateAdmin();
  return { ok: true };
}

export async function deletePanel(id: number): Promise<Res> {
  await requireAdmin();
  await db.delete(panels).where(eq(panels.id, id));
  revalidateAdmin();
  return { ok: true };
}

export async function togglePanelHidden(id: number): Promise<Res> {
  await requireAdmin();
  const [p] = await db.select().from(panels).where(eq(panels.id, id));
  if (!p) return { ok: false, error: "err.notFound" };
  await db.update(panels).set({ hidden: !p.hidden }).where(eq(panels.id, id));
  revalidateAdmin();
  return { ok: true };
}

/* ---------------- inbound pricing ---------------- */

export async function setInboundPricing(input: {
  id: number;
  pricePerGb: number;
  pricePerMonth: number;
  enabled: boolean;
}): Promise<Res> {
  await requireAdmin();
  await db
    .update(inbounds)
    .set({
      pricePerGb: Math.max(0, Math.round(input.pricePerGb)),
      pricePerMonth: Math.max(0, Math.round(input.pricePerMonth)),
      enabled: input.enabled,
    })
    .where(eq(inbounds.id, input.id));
  revalidateAdmin();
  revalidatePath("/dashboard/services");
  return { ok: true };
}

/* ---------------- users ---------------- */

export async function setUserStatus(input: {
  userId: number;
  status: "active" | "banned";
}): Promise<Res> {
  await requireAdmin();
  const [u] = await db.select().from(users).where(eq(users.id, input.userId));
  if (!u || u.role === "admin") return { ok: false, error: "err.forbidden" };
  await db.update(users).set({ status: input.status }).where(eq(users.id, u.id));
  revalidateAdmin();
  return { ok: true };
}

export async function adjustBalance(input: {
  userId: number;
  amount: number;
  reason: string;
}): Promise<Res> {
  await requireAdmin();
  const amount = Math.round(input.amount);
  if (!Number.isFinite(amount) || amount === 0) return { ok: false, error: "err.generic" };
  const [u] = await db.select().from(users).where(eq(users.id, input.userId));
  if (!u) return { ok: false, error: "err.notFound" };

  const nb = Math.max(0, u.balance + amount);
  await db.update(users).set({ balance: nb }).where(eq(users.id, u.id));
  await db.insert(transactions).values({
    userId: u.id,
    type: "adjust",
    amount,
    balanceAfter: nb,
    method: "admin",
    status: "completed",
    description: input.reason.trim().slice(0, 300),
  });
  revalidateAdmin();
  return { ok: true };
}

/* ---------------- payments ---------------- */

export async function reviewPayment(input: {
  id: number;
  approve: boolean;
  note: string;
}): Promise<Res> {
  const admin = await requireAdmin();
  const [req] = await db
    .select()
    .from(paymentRequests)
    .where(eq(paymentRequests.id, input.id));
  if (!req || req.status !== "pending") return { ok: false, error: "err.notFound" };

  const next = input.approve ? "approved" : "rejected";
  await db
    .update(paymentRequests)
    .set({ status: next, adminNote: input.note.trim().slice(0, 300), reviewedAt: new Date() })
    .where(eq(paymentRequests.id, req.id));

  if (input.approve) {
    const [u] = await db.select().from(users).where(eq(users.id, req.userId));
    if (u) {
      const nb = u.balance + req.amount;
      await db.update(users).set({ balance: nb }).where(eq(users.id, u.id));
      await db.insert(transactions).values({
        userId: u.id,
        type: "charge",
        amount: req.amount,
        balanceAfter: nb,
        method: "card",
        status: "completed",
        description: `card-to-card #${req.id}`,
      });
    }
  }
  /* mark the matching pending ledger row */
  const pendings = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, req.userId));
  const row = pendings
    .filter((t) => t.type === "charge" && t.status === "pending" && t.amount === req.amount)
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
  if (row) {
    if (input.approve) {
      await db.delete(transactions).where(eq(transactions.id, row.id));
    } else {
      await db
        .update(transactions)
        .set({ status: "rejected" })
        .where(eq(transactions.id, row.id));
    }
  }

  void admin;
  revalidateAdmin();
  return { ok: true };
}

/* ---------------- admins management ---------------- */

export async function addAdmin(input: {
  username: string;
  password: string;
  displayName: string;
}): Promise<Res> {
  await requireAdmin();
  const username = input.username.trim().toLowerCase();
  if (!/^[a-z0-9_.]{3,32}$/.test(username)) return { ok: false, error: "aa.usernameBad" };
  if (input.password.length < 6) return { ok: false, error: "pf.tooShort" };

  const [exists] = await db.select().from(users).where(eq(users.username, username));
  if (exists) return { ok: false, error: "auth.err.exists" };

  await db.insert(users).values({
    username,
    passwordHash: await hashPassword(input.password),
    role: "admin",
    shopName: input.displayName.trim().slice(0, 90) || username,
    subToken: randomToken(16),
  });
  revalidateAdmin();
  revalidatePath("/dashboard/admin/admins");
  return { ok: true };
}

export async function removeAdmin(id: number): Promise<Res> {
  const me = await requireAdmin();
  if (id === me.uid) return { ok: false, error: "aa.cannotSelf" };

  const admins = await db.select().from(users).where(eq(users.role, "admin"));
  if (admins.length <= 1) return { ok: false, error: "aa.cannotLast" };

  const [target] = await db.select().from(users).where(eq(users.id, id));
  if (!target || target.role !== "admin") return { ok: false, error: "err.notFound" };

  await db.delete(users).where(eq(users.id, id));
  revalidateAdmin();
  revalidatePath("/dashboard/admin/admins");
  return { ok: true };
}

/* ---------------- settings ---------------- */

export async function saveSettings(input: Record<string, string>): Promise<Res> {
  await requireAdmin();
  for (const [key, value] of Object.entries(input)) {
    await db
      .insert(settings)
      .values({ key, value: String(value).slice(0, 2000) })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value).slice(0, 2000) } });
  }
  revalidateAdmin();
  return { ok: true };
}
