import crypto from "crypto";

export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export const newUuid = () => crypto.randomUUID();
export const randomToken = (bytes = 20) =>
  crypto.randomBytes(bytes).toString("base64url");

export const clamp = (n: number, min: number, max: number) =>
  Math.min(max, Math.max(min, n));

export const DAY = 24 * 60 * 60 * 1000;

export function addDays(d: Date, days: number) {
  return new Date(d.getTime() + days * DAY);
}

export function daysLeft(expireAt: Date | string | number) {
  return Math.ceil((new Date(expireAt).getTime() - Date.now()) / DAY);
}

/* WireGuard-ish fake keypair (curve25519 base64, 32 bytes) */
export function genWireGuardKeys() {
  const priv = crypto.randomBytes(32).toString("base64");
  const pub = crypto.randomBytes(32).toString("base64");
  const octet = () => Math.floor(Math.random() * 254) + 1;
  return {
    privateKey: priv,
    publicKey: pub,
    address: `10.66.${octet()}.${octet()}/32`,
  };
}

export function gbToBytes(gb: number) {
  return Math.round(gb * 1024 * 1024 * 1024);
}

export const PROTOCOL_META: Record<
  string,
  { label: string; color: string; glow: string }
> = {
  vless: { label: "VLESS Reality", color: "#8B7CFF", glow: "rgba(139,124,255,.35)" },
  vmess: { label: "VMess", color: "#38BDF8", glow: "rgba(56,189,248,.3)" },
  trojan: { label: "Trojan", color: "#F472B6", glow: "rgba(244,114,182,.3)" },
  shadowsocks: { label: "Shadowsocks", color: "#34D399", glow: "rgba(52,211,153,.3)" },
  wireguard: { label: "WireGuard", color: "#FB923C", glow: "rgba(251,146,60,.3)" },
};

export function protocolLabel(p: string) {
  return PROTOCOL_META[p]?.label ?? p.toUpperCase();
}
