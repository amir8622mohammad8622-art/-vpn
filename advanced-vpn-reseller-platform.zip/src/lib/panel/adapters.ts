/**
 * Universal panel adapters — auto-detect & talk to ANY popular panel:
 *  - "xui"     : 3x-ui / x-ui (sanaei, alireza, vaxilu family)  → /login + /panel/api or /xui
 *  - "marzban" : Marzban                                        → /api/admin/token + /api/inbounds
 *  - "wgeasy"  : wg-easy (WireGuard UI)                         → /api/session + /api/wireguard
 *  - "demo"    : built-in simulator (no server needed)
 */

export type PanelKind = "demo" | "xui" | "marzban" | "wgeasy";

export type PanelCreds = { cookie?: string; token?: string };

export type RawInbound = {
  remoteId: number;
  remoteTag: string;
  remark: string;
  protocol: string;
  port: number;
  network: string;
  security: string;
  sni: string;
  path: string;
  hostHeader: string;
  pbk: string;
  sid: string;
  flow: string;
};

type FetchResult = { status: number; json: any; headers: Headers; text: string };

const TIMEOUT = 9000;

export async function tryFetch(url: string, init: RequestInit = {}): Promise<FetchResult> {
  const res = await fetch(url, {
    ...init,
    redirect: "manual",
    signal: AbortSignal.timeout(TIMEOUT),
  });
  const text = await res.text().catch(() => "");
  let json: any = null;
  try {
    json = JSON.parse(text);
  } catch {
    /* not json */
  }
  return { status: res.status, json, headers: res.headers, text };
}

const base = (u: string) => u.replace(/\/+$/, "");

/* ============== 3x-ui / x-ui family ============== */

export async function xuiLogin(url: string, username: string, password: string): Promise<string | null> {
  const r = await tryFetch(`${base(url)}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username, password }),
  });
  if (!r.json?.success) return null;
  const setCookie = r.headers.get("set-cookie") ?? "";
  const m = setCookie.match(/(3x-ui|session|x-ui)=([^;]+)/i) ?? setCookie.match(/([^=;\s]+=[^;]+)/);
  return m ? (m[0].includes("=") ? m[0] : `session=${m[0]}`) : null;
}

async function xuiGet(url: string, paths: string[], cookie: string) {
  for (const p of paths) {
    const r = await tryFetch(`${base(url)}${p}`, { headers: { Cookie: cookie } });
    if (r.json?.success && r.json.obj) return r.json.obj;
  }
  return null;
}

export async function xuiListInbounds(url: string, cookie: string): Promise<RawInbound[] | null> {
  const obj = await xuiGet(url, ["/panel/api/inbounds/list", "/xui/inbound/list"], cookie);
  if (!Array.isArray(obj)) return null;
  return obj.map((ib: any) => {
    const stream = ib.streamSettings ? JSON.parse(ib.streamSettings) : {};
    const reality = stream?.realitySettings?.settings ?? {};
    const ws = stream?.wsSettings ?? {};
    const settings = ib.settings ? JSON.parse(ib.settings) : {};
    void settings;
    return {
      remoteId: ib.id ?? 0,
      remoteTag: "",
      remark: ib.remark || `${ib.protocol}-${ib.port}`,
      protocol: String(ib.protocol ?? "vless"),
      port: ib.port ?? 443,
      network: String(stream?.network ?? "tcp"),
      security: String(stream?.security ?? "none"),
      sni: String(reality?.serverNames?.[0] ?? stream?.tlsSettings?.serverName ?? ""),
      path: String(ws?.path ?? ""),
      hostHeader: String(ws?.headers?.Host ?? ""),
      pbk: String(reality?.publicKey ?? ""),
      sid: String(reality?.shortIds?.[0] ?? ""),
      flow: String(stream?.network === "tcp" ? ib.settings?.flow ?? "" : ""),
    } as RawInbound;
  });
}

export async function xuiClientOp(
  url: string,
  cookie: string,
  op: "add" | "update" | "del",
  inboundRemoteId: number,
  client: Record<string, unknown>
): Promise<boolean> {
  const uuid = String(client.id);
  const settings = JSON.stringify({ clients: [client] });
  const attempts: Array<[string, string]> =
    op === "del"
      ? [
          [`/panel/api/inbounds/${inboundRemoteId}/delClient/${uuid}`, ""],
          [`/xui/inbound/delClient/${inboundRemoteId}/${uuid}`, ""],
        ]
      : op === "add"
        ? [
            ["/panel/api/inbounds/addClient", "panel"],
            ["/xui/inbound/addClient", "xui"],
          ]
        : [
            [`/panel/api/inbounds/updateClient/${uuid}`, "panel"],
            [`/xui/inbound/updateClient/${uuid}`, "xui"],
          ];

  for (const [path, style] of attempts) {
    try {
      const r = await tryFetch(`${base(url)}${path}`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Cookie: cookie },
        body: op === "del" ? undefined : JSON.stringify(
          style === "panel"
            ? { id: inboundRemoteId, settings }
            : { id: inboundRemoteId, settings, clients: [client] }
        ),
      });
      if (r.json?.success || r.status === 200) return true;
    } catch {
      /* try next */
    }
  }
  return false;
}

/* ============== Marzban ============== */

export async function marzbanLogin(url: string, username: string, password: string): Promise<string | null> {
  const r = await tryFetch(`${base(url)}/api/admin/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ username, password, grant_type: "password" }),
  });
  return r.json?.access_token ? String(r.json.access_token) : null;
}

export async function marzbanListInbounds(url: string, token: string): Promise<RawInbound[] | null> {
  const r = await tryFetch(`${base(url)}/api/inbounds`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const obj = r.json;
  if (!obj || typeof obj !== "object" || r.status !== 200) return null;
  const out: RawInbound[] = [];
  let i = 1;
  for (const [proto, arr] of Object.entries(obj)) {
    if (!Array.isArray(arr)) continue;
    for (const ib of arr as any[]) {
      out.push({
        remoteId: i,
        remoteTag: String(ib.tag ?? `${proto}-${i}`),
        remark: String(ib.tag ?? `${proto} inbound`),
        protocol: proto.toLowerCase(),
        port: 443,
        network: String(ib.network ?? "tcp"),
        security: String(ib.security ?? "none"),
        sni: String(ib.sni?.[0]?.host ?? ib.host?.[0]?.host ?? ""),
        path: String(ib.path ?? ""),
        hostHeader: String(ib.host?.[0]?.host ?? ""),
        pbk: "",
        sid: "",
        flow: String(ib.flow ?? ""),
      });
      i++;
    }
  }
  return out;
}

export async function marzbanUserOp(
  url: string,
  token: string,
  op: "add" | "update" | "del",
  payload: {
    username: string;
    protocol: string;
    tag: string;
    dataLimitBytes: number;
    expireUnix: number;
    status: "active" | "disabled";
  }
): Promise<boolean> {
  try {
    if (op === "del") {
      const r = await tryFetch(`${base(url)}/api/user/${encodeURIComponent(payload.username)}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });
      return r.status === 200;
    }
    const protoKey = payload.protocol === "wireguard" ? "wireguard" : payload.protocol;
    if (op === "add") {
      const r = await tryFetch(`${base(url)}/api/user`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          username: payload.username,
          status: "active",
          data_limit: payload.dataLimitBytes,
          expire: payload.expireUnix,
          inbounds: { [protoKey]: [payload.tag] },
          proxies: {},
        }),
      });
      return r.status === 200 || r.status === 201;
    }
    const r = await tryFetch(`${base(url)}/api/user/${encodeURIComponent(payload.username)}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({
        status: payload.status,
        data_limit: payload.dataLimitBytes,
        expire: payload.expireUnix,
        inbounds: { [protoKey]: [payload.tag] },
      }),
    });
    return r.status === 200;
  } catch {
    return false;
  }
}

/* ============== wg-easy ============== */

export async function wgEasyLogin(url: string, password: string): Promise<string | null> {
  const r = await tryFetch(`${base(url)}/api/session`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ password }),
  });
  if (!(r.status === 200 || r.status === 204)) return null;
  const setCookie = r.headers.get("set-cookie") ?? "";
  const m = setCookie.match(/connect\.sid=[^;]+/) ?? setCookie.match(/([^=;\s]+=[^;]+)/);
  return m ? m[0] : null;
}

export async function wgEasyClientOp(
  url: string,
  cookie: string,
  op: "create" | "enable" | "disable" | "del",
  name: string,
  clientId?: string
): Promise<{ ok: boolean; clientId?: string; address?: string; config?: string }> {
  const headers = { "Content-Type": "application/json", Cookie: cookie };
  try {
    if (op === "create") {
      const r = await tryFetch(`${base(url)}/api/wireguard/client`, {
        method: "POST",
        headers,
        body: JSON.stringify({ name }),
      });
      const cid = String(r.json?.id ?? "");
      if (!cid) return { ok: false };
      let config = "";
      try {
        const c = await tryFetch(`${base(url)}/api/wireguard/client/${cid}/configuration`, { headers: { Cookie: cookie } });
        if (c.text.includes("[Interface]")) config = c.text;
      } catch { /* optional */ }
      return {
        ok: true,
        clientId: cid,
        address: r.json?.address ? String(r.json.address) : undefined,
        config: config || undefined,
      };
    }
    const path =
      op === "del"
        ? `${base(url)}/api/wireguard/client/${clientId}`
        : `${base(url)}/api/wireguard/client/${clientId}/${op}`;
    const r = await tryFetch(path, { method: op === "del" ? "DELETE" : "POST", headers });
    return { ok: r.status === 200 || r.status === 204 };
  } catch {
    return { ok: false };
  }
}

/* ============== Auto-detection ============== */

/**
 * Probe the URL + credentials against every known panel flavour
 * and return the one that answers. Order: marzban → wgeasy → xui.
 */
export async function detectPanel(
  url: string,
  username: string,
  password: string
): Promise<{ kind: PanelKind; creds: PanelCreds } | null> {
  const clean = base(url);
  if (!/^https?:\/\//.test(clean)) return null;

  try {
    const token = await marzbanLogin(clean, username, password);
    if (token) return { kind: "marzban", creds: { token } };
  } catch { /* next */ }

  try {
    const cookie = await wgEasyLogin(clean, password);
    if (cookie) return { kind: "wgeasy", creds: { cookie } };
  } catch { /* next */ }

  try {
    const cookie = await xuiLogin(clean, username, password);
    if (cookie) return { kind: "xui", creds: { cookie } };
  } catch { /* next */ }

  return null;
}

/** Fetch inbounds using the detected panel kind. */
export async function fetchInbounds(
  kind: PanelKind,
  url: string,
  creds: PanelCreds,
  panelName: string
): Promise<RawInbound[] | null> {
  if (kind === "xui" && creds.cookie) return xuiListInbounds(url, creds.cookie);
  if (kind === "marzban" && creds.token) return marzbanListInbounds(url, creds.token);
  if (kind === "wgeasy") {
    return [
      {
        remoteId: 1,
        remoteTag: "main",
        remark: `WireGuard — ${panelName}`,
        protocol: "wireguard",
        port: 51820,
        network: "udp",
        security: "none",
        sni: "",
        path: "",
        hostHeader: "",
        pbk: "",
        sid: "",
        flow: "",
      },
    ];
  }
  return null;
}
