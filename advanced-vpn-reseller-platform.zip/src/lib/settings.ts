import { db } from "@/db";
import { settings } from "@/db/schema";

export type SiteSettings = {
  card_number: string;
  card_holder: string;
  min_charge: string;
  support_user: string;
  announcement: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  card_number: "6037 9971 0000 1234",
  card_holder: "hector Pay",
  min_charge: "50000",
  support_user: "@hector_support",
  announcement: "",
};

export async function getSiteSettings(): Promise<SiteSettings> {
  try {
    const rows = await db.select().from(settings);
    const map = new Map(rows.map((r) => [r.key, r.value]));
    return {
      card_number: map.get("card_number") || DEFAULT_SETTINGS.card_number,
      card_holder: map.get("card_holder") || DEFAULT_SETTINGS.card_holder,
      min_charge: map.get("min_charge") || DEFAULT_SETTINGS.min_charge,
      support_user: map.get("support_user") || DEFAULT_SETTINGS.support_user,
      announcement: map.get("announcement") ?? "",
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}
