"use client";

import React, { useMemo, useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  Cpu,
  Lock,
  Plus,
  Server,
  ShieldCheck,
  Signal,
  Users,
  Wallet,
} from "lucide-react";
import Link from "next/link";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, Field, Modal, PageTitle } from "@/components/ui";
import { createVpnUser } from "@/lib/actions/vpn";
import { cn, PROTOCOL_META } from "@/lib/utils";

export type ServiceInbound = {
  id: number;
  remark: string;
  protocol: string;
  port: number;
  network: string;
  security: string;
  pricePerGb: number;
  pricePerMonth: number;
  totalClients: number;
  panelName: string;
  location: string;
  panelStatus: string;
};

function calcCost(gb: number, days: number, pricePerGb: number, pricePerMonth: number) {
  const months = Math.ceil(days / 30);
  return pricePerMonth * months + Math.round(gb * pricePerGb);
}

export function ServicesView({
  inbounds,
  balance,
}: {
  inbounds: ServiceInbound[];
  balance: number;
}) {
  const { t, fmtToman, fmtNum } = useI18n();
  const { push } = useToast();
  const [sel, setSel] = useState<ServiceInbound | null>(null);
  const [pending, start] = useTransition();

  const [name, setName] = useState("");
  const [gb, setGb] = useState(30);
  const [days, setDays] = useState(30);
  const [ip, setIp] = useState(2);

  const cost = useMemo(
    () => (sel ? calcCost(gb, days, sel.pricePerGb, sel.pricePerMonth) : 0),
    [sel, gb, days]
  );
  const months = Math.ceil(days / 30);
  const insufficient = sel ? cost > balance : false;

  const openCreate = (ib: ServiceInbound) => {
    setSel(ib);
    setName("");
    setGb(30);
    setDays(30);
    setIp(2);
  };

  const submit = () => {
    if (!sel) return;
    start(async () => {
      const r = await createVpnUser({ inboundId: sel.id, name, gb, days, ipLimit: ip });
      if (!r.ok) {
        push("err", t(r.error ?? "err.generic"));
        return;
      }
      push("ok", t("svc.created"));
      setSel(null);
    });
  };

  const sliderStyle = (v: number, min: number, max: number) =>
    ({ "--fill": `${((v - min) / (max - min)) * 100}%` }) as React.CSSProperties;

  return (
    <div>
      <PageTitle title={t("svc.title")} sub={t("svc.sub")} />

      {inbounds.length === 0 ? (
        <Card>
          <Empty icon={<Server size={24} />} title={t("svc.noService")} />
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {inbounds.map((ib, i) => {
            const meta = PROTOCOL_META[ib.protocol] ?? PROTOCOL_META.vless;
            return (
              <motion.div
                key={ib.id}
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.06, duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              >
                <Card className="p-5 relative overflow-hidden group hover:-translate-y-1 transition-transform duration-300">
                  <div
                    className="absolute -top-14 -end-14 w-36 h-36 rounded-full blur-3xl opacity-40 group-hover:opacity-70 transition-opacity"
                    style={{ background: meta.glow }}
                  />
                  <div className="relative">
                    <div className="flex items-center justify-between">
                      <span
                        className="text-[11px] font-bold px-2.5 py-1 rounded-full border inline-flex items-center gap-1.5"
                        style={{
                          color: meta.color,
                          borderColor: `${meta.color}55`,
                          background: meta.glow,
                        }}
                      >
                        {meta.label}
                        <Lock size={10} />
                      </span>
                      <span className="inline-flex items-center gap-1 text-[10px] font-black tracking-wider border border-white/15 rounded-lg px-2 py-1 text-slate-300">
                        {ib.location}
                      </span>
                    </div>

                    <div className="mt-4 font-black text-[15px]">{ib.remark}</div>
                    <div className="mt-0.5 text-[11px] text-slate-500">{ib.panelName}</div>

                    <div className="mt-4 flex flex-wrap gap-1.5 text-[10.5px]">
                      <span className="glass rounded-lg px-2 py-1 text-slate-300 inline-flex items-center gap-1">
                        <Signal size={10} className="text-slate-500" />
                        {t("svc.port")} <b dir="ltr">{ib.port}</b>
                      </span>
                      <span className="glass rounded-lg px-2 py-1 text-slate-300 inline-flex items-center gap-1">
                        <Cpu size={10} className="text-slate-500" />
                        {ib.network}
                      </span>
                      <span className="glass rounded-lg px-2 py-1 text-slate-300 inline-flex items-center gap-1">
                        <ShieldCheck size={10} className="text-slate-500" />
                        {ib.security}
                      </span>
                      <span className="glass rounded-lg px-2 py-1 text-slate-300 inline-flex items-center gap-1">
                        <Users size={10} className="text-slate-500" />
                        {fmtNum(ib.totalClients)} {t("svc.clients")}
                      </span>
                    </div>

                    <div className="mt-5 flex items-end justify-between border-t border-white/8 pt-4">
                      <div>
                        <div className="text-[10.5px] text-slate-500">{t("svc.perGb")}</div>
                        <div className="font-black text-[15px] text-grad">{fmtToman(ib.pricePerGb)}</div>
                      </div>
                      <div className="text-end">
                        <div className="text-[10.5px] text-slate-500">{t("svc.monthly")}</div>
                        <div className="font-bold text-[13px]">{fmtToman(ib.pricePerMonth)}</div>
                      </div>
                    </div>

                    <Btn className="w-full mt-4" size="md" onClick={() => openCreate(ib)}>
                      <Plus size={15} />
                      {t("svc.createOn")}
                    </Btn>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* create modal */}
      <Modal open={!!sel} onClose={() => setSel(null)} title={t("svc.createTitle")} wide>
        {sel && (
          <div className="space-y-5">
            <div className="flex items-center gap-3 glass rounded-2xl p-3.5">
              <span
                className="w-10 h-10 rounded-xl border flex items-center justify-center"
                style={{
                  color: (PROTOCOL_META[sel.protocol] ?? PROTOCOL_META.vless).color,
                  borderColor: `${(PROTOCOL_META[sel.protocol] ?? PROTOCOL_META.vless).color}44`,
                  background: (PROTOCOL_META[sel.protocol] ?? PROTOCOL_META.vless).glow,
                }}
              >
                <Server size={17} />
              </span>
              <div className="flex-1">
                <div className="font-bold text-sm">{sel.remark}</div>
                <div className="text-[11px] text-slate-500 mt-0.5">{t("svc.createSub")}</div>
              </div>
              {sel.location && (
                <span className="text-[10px] font-black tracking-widest border border-white/15 rounded-lg px-2 py-1 text-slate-300">
                  {sel.location}
                </span>
              )}
            </div>

            <Field label={t("svc.nameLabel")}>
              <input
                className="field"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t("svc.namePh")}
                maxLength={60}
              />
            </Field>

            <div className="grid sm:grid-cols-2 gap-5">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-slate-400">{t("svc.dataLimit")}</span>
                  <span className="text-xs font-black text-[#f5c518]" dir="ltr">{gb} GB</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={500}
                  value={gb}
                  style={sliderStyle(gb, 1, 500)}
                  onChange={(e) => setGb(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-[10px] text-slate-600 mt-1.5" dir="ltr">
                  <span>1</span><span>500</span>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-medium text-slate-400">{t("svc.validity")}</span>
                  <span className="text-xs font-black text-[#f5c518]">
                    {fmtNum(days)} {t("c.days")}
                  </span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={365}
                  value={days}
                  style={sliderStyle(days, 1, 365)}
                  onChange={(e) => setDays(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-[10px] text-slate-600 mt-1.5" dir="ltr">
                  <span>1</span><span>365</span>
                </div>
              </div>
            </div>

            <Field label={t("svc.ipLimit")} hint={t("svc.ipHint")}>
              <div className="grid grid-cols-6 gap-1.5" dir="ltr">
                {[0, 1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setIp(n)}
                    className={cn(
                      "rounded-xl py-2 text-sm font-bold border transition-all",
                      ip === n
                        ? "border-[#d4a800] bg-[#d4a800]/20 text-white shadow-[0_0_18px_-4px_rgba(212,168,0,.7)]"
                        : "border-white/10 text-slate-400 hover:bg-white/6"
                    )}
                  >
                    {n === 0 ? "∞" : n}
                  </button>
                ))}
              </div>
            </Field>

            <div className="glass rounded-2xl p-4 space-y-2.5 text-[13px]">
              <div className="flex justify-between">
                <span className="text-slate-400">{t("svc.cost")}</span>
                <span className="font-black text-grad text-base">{fmtToman(cost)}</span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-500">
                <span>{t("svc.costDetail", { months: fmtNum(months), gb: fmtNum(gb) })}</span>
              </div>
              <div className="flex justify-between border-t border-white/8 pt-2.5">
                <span className="text-slate-400">{t("svc.balanceAfter")}</span>
                <span className={cn("font-bold", insufficient ? "text-red-300" : "text-emerald-300")}>
                  {fmtToman(balance - cost)}
                </span>
              </div>
            </div>

            {insufficient && (
              <Link
                href="/dashboard/wallet"
                className="flex items-center gap-2 text-xs text-red-300 bg-red-400/10 border border-red-400/25 rounded-xl px-3.5 py-2.5"
              >
                <Wallet size={14} />
                {t("svc.insufficient")}
              </Link>
            )}

            <div className="flex gap-2.5">
              <Btn
                className="flex-1"
                size="lg"
                loading={pending}
                disabled={insufficient || name.trim().length < 2}
                onClick={submit}
              >
                <Plus size={16} />
                {t("c.create")}
              </Btn>
              <Btn variant="ghost" size="lg" onClick={() => setSel(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}


