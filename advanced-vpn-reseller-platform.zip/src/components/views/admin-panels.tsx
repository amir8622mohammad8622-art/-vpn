"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  Boxes,
  Clock4,
  Eye,
  EyeOff,
  Globe2,
  KeyRound,
  Link2,
  Network,
  Plus,
  RefreshCw,
  Server,
  Trash2,
  Wand2,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, Field, Modal, PageTitle } from "@/components/ui";
import { addPanel, deletePanel, syncPanelAction, togglePanelHidden } from "@/lib/actions/admin";
import { cn } from "@/lib/utils";

type PanelRow = {
  id: number;
  name: string;
  type: string;
  baseUrl: string;
  subHost: string;
  location: string;
  status: string;
  hidden: boolean;
  apiUsername: string;
  lastSyncAt: string | null;
  inboundCount: number;
};

export function PanelsView({ panels }: { panels: PanelRow[] }) {
  const { t, fmtNum, fmtDate } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [adding, setAdding] = useState(false);
  const [delRow, setDelRow] = useState<PanelRow | null>(null);
  const [syncing, setSyncing] = useState<number | null>(null);

  const [form, setForm] = useState({
    name: "",
    baseUrl: "https://",
    username: "",
    password: "",
    type: "auto" as "auto" | "demo",
    subHost: "",
    location: "DE",
  });

  const submitAdd = () =>
    start(async () => {
      const r = await addPanel(form);
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      push("ok", t("ap.added"));
      setAdding(false);
      setForm({ name: "", baseUrl: "https://", username: "", password: "", type: "auto", subHost: "", location: "EU" });
    });

  const kindBadge = (type: string) =>
    type === "marzban" ? (
      <Badge tone="violet">Marzban</Badge>
    ) : type === "wgeasy" ? (
      <Badge tone="orange">WG-Easy</Badge>
    ) : type === "xui" ? (
      <Badge tone="sky">3x-ui / X-UI</Badge>
    ) : (
      <Badge tone="zinc">DEMO</Badge>
    );

  const doSync = (id: number) => {
    setSyncing(id);
    start(async () => {
      await syncPanelAction(id);
      push("ok", t("ap.synced"));
      setSyncing(null);
    });
  };

  const doDelete = () => {
    if (!delRow) return;
    start(async () => {
      await deletePanel(delRow.id);
      push("ok", t("ap.deleted"));
      setDelRow(null);
    });
  };

  return (
    <div>
      <PageTitle title={t("ap.title")} sub={t("ap.sub")}>
        <Btn onClick={() => setAdding(true)}>
          <Plus size={15} /> {t("ap.add")}
        </Btn>
      </PageTitle>

      <div className="mb-4 text-[12px] text-slate-500 flex items-center gap-2">
        <Network size={13} className="text-[#f5c518]" />
        {fmtNum(panels.length)} {t("ap.totalPanels")}
      </div>

      {panels.length === 0 ? (
        <Card>
          <Empty icon={<Server size={24} />} title={t("ap.add")}>
            <Btn size="sm" onClick={() => setAdding(true)}>
              <Plus size={14} /> {t("ap.add")}
            </Btn>
          </Empty>
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {panels.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05, duration: 0.45 }}
            >
              <Card className="p-5 relative overflow-hidden">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span
                      className={cn(
                        "w-11 h-11 rounded-2xl border flex items-center justify-center",
                        p.status === "online"
                          ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                          : "border-red-400/30 bg-red-400/10 text-red-300"
                      )}
                    >
                      <Server size={18} />
                    </span>
                    <div>
                      <div className="font-black text-[15px] flex items-center gap-2">
                        {p.name}
                        <span className="text-[9.5px] font-black tracking-widest border border-white/15 rounded-md px-1.5 py-0.5 text-slate-400">
                          {p.location}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono truncate max-w-48" dir="ltr">
                        {p.baseUrl || "demo://local"}
                      </div>
                    </div>
                  </div>
                    <div className="flex flex-col items-end gap-1.5">
                    <Badge tone={p.status === "online" ? "green" : "red"} pulse={p.status === "online"}>
                      {p.status === "online" ? t("ap.online") : t("ap.offline")}
                    </Badge>
                    <div className="flex gap-1.5">
                      {kindBadge(p.type)}
                      {p.hidden && <Badge tone="zinc">{t("ap.hidden")}</Badge>}
                    </div>
                  </div>
                </div>

                <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                  <div className="glass rounded-xl p-2.5">
                    <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                      <Boxes size={10} /> {t("ap.inbounds")}
                    </div>
                    <div className="font-black text-sm mt-0.5">{fmtNum(p.inboundCount)}</div>
                  </div>
                  <div className="glass rounded-xl p-2.5">
                    <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                      <KeyRound size={10} /> API
                    </div>
                    <div className="font-bold text-[11px] mt-1 font-mono truncate" dir="ltr">
                      {p.apiUsername || "—"}
                    </div>
                  </div>
                  <div className="glass rounded-xl p-2.5">
                    <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                      <Clock4 size={10} /> {t("ap.lastSync")}
                    </div>
                    <div className="font-bold text-[10.5px] mt-1">
                      {p.lastSyncAt ? fmtDate(p.lastSyncAt) : t("ap.never")}
                    </div>
                  </div>
                </div>

                {p.subHost && (
                  <div className="mt-3 flex items-center gap-2 text-[11px] text-slate-500">
                    <Link2 size={11} className="text-[#f5c518]" />
                    <span dir="ltr" className="font-mono">{p.subHost}</span>
                  </div>
                )}

                <div className="mt-4 flex gap-2">
                  <Btn size="sm" variant="soft" className="flex-1" loading={syncing === p.id} onClick={() => doSync(p.id)}>
                    <RefreshCw size={13} /> {t("ap.sync")}
                  </Btn>
                  <Btn
                    size="sm"
                    variant="ghost"
                    title={t("ap.toggleHidden")}
                    onClick={() =>
                      start(async () => {
                        await togglePanelHidden(p.id);
                      })
                    }
                  >
                    {p.hidden ? <EyeOff size={14} /> : <Eye size={14} />}
                  </Btn>
                  <Btn size="sm" variant="danger" onClick={() => setDelRow(p)}>
                    <Trash2 size={14} />
                  </Btn>
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* add modal */}
      <Modal open={adding} onClose={() => setAdding(false)} title={t("ap.add")} wide>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-2">
            {(["auto", "demo"] as const).map((tp) => (
              <button
                key={tp}
                type="button"
                onClick={() => setForm({ ...form, type: tp })}
                className={cn(
                  "rounded-2xl border p-4 text-start transition-all",
                  form.type === tp
                    ? "border-[#d4a800]/60 bg-[#d4a800]/12"
                    : "border-white/10 hover:bg-white/[.04]"
                )}
              >
                {tp === "auto" ? (
                  <Wand2 size={17} className={form.type === tp ? "text-[#f5c518]" : "text-slate-500"} />
                ) : (
                  <Globe2 size={17} className={form.type === tp ? "text-[#f5c518]" : "text-slate-500"} />
                )}
                <div className="mt-2 text-[13px] font-bold">{tp === "auto" ? t("ap.typeAuto") : t("ap.typeDemo")}</div>
                <div className="text-[10.5px] text-slate-500 mt-0.5 leading-4">
                  {tp === "auto" ? t("ap.typeAutoSub") : "demo://local"}
                </div>
              </button>
            ))}
          </div>

          {form.type === "auto" && (
            <div className="flex flex-wrap gap-1.5">
              {["3x-ui", "X-UI", "Marzban", "WG-Easy"].map((n) => (
                <span key={n} className="text-[10px] font-bold px-2 py-1 rounded-lg border border-white/10 text-slate-400">
                  {n}
                </span>
              ))}
              <span className="text-[10px] text-slate-500 self-center">{t("ap.detectHint")}</span>
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-4">
            <Field label={t("ap.name")}>
              <input className="field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder={t("ap.namePh")} />
            </Field>
            <Field label={t("ap.location")}>
              <input className="field" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} maxLength={8} />
            </Field>
          </div>

          {form.type === "auto" && (
            <>
              <Field label={t("ap.url")} hint="https://1.2.3.4:54321">
                <input className="field font-mono" dir="ltr" value={form.baseUrl} onChange={(e) => setForm({ ...form, baseUrl: e.target.value })} />
              </Field>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label={t("ap.user")} hint={t("ap.userHint")}>
                  <input className="field" dir="ltr" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoComplete="off" />
                </Field>
                <Field label={t("ap.pass")}>
                  <input className="field" dir="ltr" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="new-password" />
                </Field>
              </div>
            </>
          )}

          <Field label={t("ap.subHost")} hint="de-1.yourdomain.com">
            <input className="field font-mono" dir="ltr" value={form.subHost} onChange={(e) => setForm({ ...form, subHost: e.target.value })} />
          </Field>

          <div className="flex gap-2.5">
            <Btn className="flex-1" size="lg" loading={pending} disabled={!form.name.trim()} onClick={submitAdd}>
              <Plus size={16} /> {t("ap.add")}
            </Btn>
            <Btn variant="ghost" size="lg" onClick={() => setAdding(false)}>
              {t("c.cancel")}
            </Btn>
          </div>
        </div>
      </Modal>

      {/* delete modal */}
      <Modal open={!!delRow} onClose={() => setDelRow(null)} title={t("c.delete")}>
        {delRow && (
          <div className="space-y-4">
            <p className="text-sm text-slate-300 leading-7">{t("ap.del")}</p>
            <div className="flex gap-2.5">
              <Btn variant="danger" className="flex-1" loading={pending} onClick={doDelete}>
                <Trash2 size={14} /> {t("c.delete")}
              </Btn>
              <Btn variant="ghost" onClick={() => setDelRow(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
