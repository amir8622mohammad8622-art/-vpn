"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Headset,
  LifeBuoy,
  Lock,
  MessageSquarePlus,
  SendHorizonal,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, Field, Modal, PageTitle } from "@/components/ui";
import { closeTicket, createTicket, replyTicket } from "@/lib/actions/tickets";
import { cn } from "@/lib/utils";

export type TicketWithMsgs = {
  id: number;
  subject: string;
  status: string;
  createdAt: string;
  messages: { id: number; mine: boolean; body: string; createdAt: string }[];
};

export function TicketsView({
  tickets,
  supportUser,
}: {
  tickets: TicketWithMsgs[];
  supportUser: string;
}) {
  const { t, fa, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [active, setActive] = useState<TicketWithMsgs | null>(null);
  const [creating, setCreating] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState("");
  const BackIcon = fa ? ArrowRight : ArrowLeft;

  const activeFresh = tickets.find((x) => x.id === active?.id) ?? null;

  const submitNew = () =>
    start(async () => {
      const r = await createTicket({ subject, message });
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      push("ok", t("tk.sent"));
      setCreating(false);
      setSubject("");
      setMessage("");
    });

  const sendReply = () => {
    if (!activeFresh) return;
    start(async () => {
      const r = await replyTicket({ ticketId: activeFresh.id, body: reply });
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      setReply("");
      push("ok", t("tk.reply"));
    });
  };

  const close = () => {
    if (!activeFresh) return;
    start(async () => {
      await closeTicket(activeFresh.id);
      push("ok", t("tk.close"));
    });
  };

  const tone = (s: string): "amber" | "green" | "zinc" =>
    s === "open" ? "amber" : s === "answered" ? "green" : "zinc";

  return (
    <div>
      <PageTitle title={t("tk.title")} sub={`${t("tk.sub")} · ${supportUser}`}>
        <Btn onClick={() => setCreating(true)}>
          <MessageSquarePlus size={15} />
          {t("tk.new")}
        </Btn>
      </PageTitle>

      {tickets.length === 0 ? (
        <Card>
          <Empty icon={<LifeBuoy size={24} />} title={t("tk.empty")}>
            <Btn size="sm" onClick={() => setCreating(true)}>
              <MessageSquarePlus size={14} /> {t("tk.new")}
            </Btn>
          </Empty>
        </Card>
      ) : (
        <div className="grid lg:grid-cols-[320px_1fr] gap-4">
          {/* list */}
          <Card className={cn("p-3 space-y-1.5 h-fit max-h-[70vh] overflow-y-auto", activeFresh && "hidden lg:block")}>
            {tickets.map((tk) => (
              <button
                key={tk.id}
                onClick={() => setActive(tk)}
                className={cn(
                  "w-full text-start rounded-2xl px-3.5 py-3 transition-colors",
                  activeFresh?.id === tk.id ? "bg-[#d4a800]/15 border border-[#d4a800]/35" : "hover:bg-white/[.05] border border-transparent"
                )}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-[13px] font-bold truncate">{tk.subject}</span>
                  <Badge tone={tone(tk.status)}>{t(`tk.st.${tk.status}`)}</Badge>
                </div>
                <div className="text-[10.5px] text-slate-500 mt-1">
                  #{tk.id} · {fmtDateTime(tk.createdAt)}
                </div>
              </button>
            ))}
          </Card>

          {/* thread */}
          <Card className={cn("flex flex-col min-h-[420px] max-h-[70vh]", !activeFresh && "hidden lg:flex")}>
            {!activeFresh ? (
              <div className="flex-1 flex items-center justify-center">
                <Empty icon={<Headset size={24} />} title={t("tk.title")} />
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-white/8">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button onClick={() => setActive(null)} className="lg:hidden p-1.5 rounded-lg hover:bg-white/10 text-slate-400">
                      <BackIcon size={16} />
                    </button>
                    <div className="min-w-0">
                      <div className="font-bold text-sm truncate">{activeFresh.subject}</div>
                      <div className="text-[10.5px] text-slate-500">#{activeFresh.id}</div>
                    </div>
                  </div>
                  {activeFresh.status !== "closed" ? (
                    <Btn variant="danger" size="sm" loading={pending} onClick={close}>
                      <Lock size={12} /> {t("tk.close")}
                    </Btn>
                  ) : (
                    <Badge tone="zinc">{t("tk.st.closed")}</Badge>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto p-5 space-y-3">
                  {activeFresh.messages.map((m) => (
                    <motion.div
                      key={m.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn("flex", m.mine ? "justify-end" : "justify-start")}
                    >
                      <div
                        className={cn(
                          "max-w-[78%] rounded-2xl px-4 py-2.5 text-[13px] leading-6",
                          m.mine
                            ? "bg-gradient-to-l from-[#d4a800]/85 to-[#e8b800]/70 text-white rounded-es-md"
                            : "glass rounded-ee-md"
                        )}
                      >
                        <div className={cn("text-[9.5px] mb-1 opacity-70")}>{m.mine ? t("tk.you") : t("tk.support")}</div>
                        {m.body}
                        <div className="text-[9px] opacity-60 mt-1">{fmtDateTime(m.createdAt)}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-4 border-t border-white/8">
                  {activeFresh.status === "closed" ? (
                    <div className="text-center text-xs text-slate-500 py-2">{t("tk.closed")}</div>
                  ) : (
                    <div className="flex items-end gap-2">
                      <textarea
                        className="field flex-1 min-h-[44px] max-h-32 resize-none"
                        placeholder={t("tk.message")}
                        value={reply}
                        onChange={(e) => setReply(e.target.value)}
                      />
                      <Btn loading={pending} disabled={!reply.trim()} onClick={sendReply}>
                        <SendHorizonal size={15} className={fa ? "-scale-x-100" : ""} />
                      </Btn>
                    </div>
                  )}
                </div>
              </>
            )}
          </Card>
        </div>
      )}

      {/* new ticket modal */}
      <Modal open={creating} onClose={() => setCreating(false)} title={t("tk.new")}>
        <div className="space-y-4">
          <Field label={t("tk.subject")}>
            <input className="field" value={subject} onChange={(e) => setSubject(e.target.value)} maxLength={120} />
          </Field>
          <Field label={t("tk.message")}>
            <textarea
              className="field min-h-28 resize-none"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              maxLength={2000}
            />
          </Field>
          <Btn className="w-full" loading={pending} disabled={!subject.trim() || !message.trim()} onClick={submitNew}>
            <SendHorizonal size={15} className={fa ? "-scale-x-100" : ""} />
            {t("tk.send")}
          </Btn>
        </div>
      </Modal>
    </div>
  );
}
