"use client";

import React, { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Clock3,
  Download,
  Globe2,
  KeyRound,
  Pencil,
  Plus,
  QrCode,
  RotateCcw,
  Search,
  Server,
  Trash2,
  Users,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, CopyBtn, Empty, Field, Modal, PageTitle, Toggle, UsageBar } from "@/components/ui";
import {
  deleteVpnUser,
  renewVpnUser,
  resetUsage,
  toggleVpnUser,
} from "@/lib/actions/vpn";
import { cn, daysLeft, PROTOCOL_META } from "@/lib/utils";

export type VpnRow = {
  id: number;
  label: string;
  email: string;
  protocol: string;
  inboundRemark: string;
  panelName: string;
  location: string;
  usedGb: number;
  dataLimitGb: number;
  expireAt: string;
  ipLimit: number;
  status: string;
  pricePerGb: number;
  pricePerMonth: number;
  config: string;
  qr: string;
};

const statusTone: Record<string, "green" | "zinc" | "amber" | "red"> = {
  active: "green",
  disabled: "zinc",
  depleted: "amber",
  expired: "red",
};

export function UsersView({
  rows,
  balance,
  shop,
}: {
  rows: VpnRow[];
  balance: number;
  shop: string;
}) {
  const { t, fmtGb, fmtNum, fmtToman } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();

  const [q, setQ] = useState("");
  const [filter, setFilter] = useState("all");
  const [configRow, setConfigRow] = useState<VpnRow | null>(null);
  const [renewRow, setRenewRow] = useState<VpnRow | null>(null);
  const [delRow, setDelRow] = useState<VpnRow | null>(null);
  const [resetRow, setResetRow] = useState<VpnRow | null>(null);

  const [addGb, setAddGb] = useState(30);
  const [addDays, setAddDays] = useState(30);

  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          (filter === "all" || r.status === filter) &&
          (q === "" ||
            r.label.toLowerCase().includes(q.toLowerCase()) ||
            r.email.toLowerCase().includes(q.toLowerCase()))
      ),
    [rows, q, filter]
  );

  const renewCost = renewRow
    ? renewRow.pricePerMonth * Math.ceil(addDays / 30) + Math.round(addGb * renewRow.pricePerGb)
    : 0;
  const renewInsufficient = renewCost > balance;

  const act = (fn: () => Promise<{ ok: boolean; error?: string }>, okKey: string, close?: () => void) =>
    start(async () => {
      const r = await fn();
      if (!r.ok) {
        push("err", t(r.error ?? "err.generic"));
        return;
      }
      push("ok", t(okKey));
      close?.();
    });

  const chip = (v: string, label: string) => (
    <button
      key={v}
      onClick={() => setFilter(v)}
      className={cn(
        "rounded-full px-3 py-1 text-[11px] font-bold border transition-all",
        filter === v
          ? "border-[#d4a800]/60 bg-[#d4a800]/18 text-white"
          : "border-white/10 text-slate-400 hover:text-white"
      )}
    >
      {label}
    </button>
  );

  return (
    <div>
      <PageTitle title={t("mu.title")} sub={t("mu.sub")}>
        <Link
          href="/dashboard/services"
          className="inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_8px_26px_-8px_rgba(212,168,0,.7)] hover:-translate-y-0.5 transition-transform"
        >
          <Plus size={15} />
          {t("dash.quickCreate")}
        </Link>
      </PageTitle>

      {/* filters */}
      <div className="flex flex-wrap items-center gap-3 mb-5">
        <div className="relative flex-1 min-w-52 max-w-sm">
          <Search size={15} className="absolute top-1/2 -translate-y-1/2 start-3.5 text-slate-500" />
          <input
            className="field ps-10"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t("mu.searchPh")}
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          {chip("all", t("c.all"))}
          {chip("active", t("mu.st.active"))}
          {chip("disabled", t("mu.st.disabled"))}
          {chip("depleted", t("mu.st.depleted"))}
          {chip("expired", t("mu.st.expired"))}
        </div>
      </div>

      {rows.length === 0 ? (
        <Card>
          <Empty icon={<Users size={24} />} title={t("mu.noUsers")} sub={t("mu.noUsersSub")}>
            <Link
              href="/dashboard/services"
              className="inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800]"
            >
              <Plus size={15} /> {t("dash.quickCreate")}
            </Link>
          </Empty>
        </Card>
      ) : filtered.length === 0 ? (
        <Card>
          <Empty icon={<Search size={22} />} title={t("wal.noData")} />
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((r, i) => {
            const meta = PROTOCOL_META[r.protocol] ?? PROTOCOL_META.vless;
            const left = daysLeft(r.expireAt);
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.04, 0.4), duration: 0.45 }}
              >
                <Card className="p-4 sm:p-5">
                  <div className="flex flex-wrap items-center gap-x-5 gap-y-4">
                    {/* identity */}
                    <div className="flex items-center gap-3 min-w-52">
                      <span
                        className="w-11 h-11 rounded-2xl border flex items-center justify-center text-sm font-black shrink-0"
                        style={{
                          color: meta.color,
                          borderColor: `${meta.color}44`,
                          background: meta.glow,
                        }}
                      >
                        {r.label.slice(0, 2)}
                      </span>
                      <div className="min-w-0">
                        <div className="font-bold text-sm truncate max-w-44">{r.label}</div>
                        <div className="text-[10.5px] text-slate-500 font-mono truncate max-w-44" dir="ltr">
                          {r.email}
                        </div>
                        <div className="mt-1 flex items-center gap-1.5">
                          <span
                            className="text-[9.5px] px-1.5 py-0.5 rounded-md border"
                            style={{ color: meta.color, borderColor: `${meta.color}55` }}
                          >
                            {meta.label}
                          </span>
                          <Badge tone={statusTone[r.status] ?? "zinc"} pulse={r.status === "active"}>
                            {t(`mu.st.${r.status}`)}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {/* inbound */}
                    <div className="hidden md:block min-w-36">
                      <div className="text-[10.5px] text-slate-500 mb-1">{t("mu.col.inbound")}</div>
                      <div className="text-[12.5px] font-bold flex items-center gap-1.5">
                        <Server size={12} className="text-slate-500 shrink-0" />
                        <span className="truncate max-w-36">{r.inboundRemark}</span>
                      </div>
                      <div className="text-[10.5px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Globe2 size={10} />
                        {r.panelName} {r.location}
                      </div>
                    </div>

                    {/* usage */}
                    <div className="flex-1 min-w-40">
                      <div className="flex justify-between text-[10.5px] text-slate-500 mb-1.5">
                        <span>{t("mu.col.usage")}</span>
                        <span className="font-mono" dir="ltr">
                          {fmtGb(r.usedGb)} / {fmtGb(r.dataLimitGb)}
                        </span>
                      </div>
                      <UsageBar used={r.usedGb} total={r.dataLimitGb} />
                      <div className="mt-1.5 text-[10.5px] text-slate-500 flex items-center gap-1.5 flex-wrap">
                        <Clock3 size={10} />
                        {r.status === "expired" ? (
                          <span className="text-red-300">{t("mu.expiredTag")}</span>
                        ) : (
                          t("mu.daysLeft", { n: fmtNum(Math.max(0, left)) })
                        )}
                        <span className="text-slate-600">·</span>
                        <span>
                          {t("mu.col.ip")}: {r.ipLimit === 0 ? t("c.unlimited") : fmtNum(r.ipLimit)}
                        </span>
                      </div>
                    </div>

                    {/* actions */}
                    <div className="flex items-center gap-1.5 ms-auto">
                      <button
                        onClick={() => setConfigRow(r)}
                        title={t("mu.config")}
                        className="p-2.5 rounded-xl border border-[#38e1d4]/25 text-[#f5c518] bg-[#38e1d4]/8 hover:bg-[#38e1d4]/16 transition-colors"
                      >
                        <QrCode size={15} />
                      </button>
                      <button
                        onClick={() => {
                          setRenewRow(r);
                          setAddGb(30);
                          setAddDays(30);
                        }}
                        title={t("mu.renew")}
                        className="p-2.5 rounded-xl border border-[#d4a800]/30 text-[#f5c518] bg-[#d4a800]/10 hover:bg-[#d4a800]/20 transition-colors"
                      >
                        <Pencil size={15} />
                      </button>
                      <button
                        onClick={() => setResetRow(r)}
                        title={t("mu.reset")}
                        className="p-2.5 rounded-xl border border-amber-400/25 text-amber-300 bg-amber-400/8 hover:bg-amber-400/16 transition-colors"
                      >
                        <RotateCcw size={15} />
                      </button>
                      <div className="flex flex-col items-center px-1">
                        <Toggle
                          on={r.status !== "disabled"}
                          onChange={() => act(() => toggleVpnUser(r.id), "mu.toggled")}
                        />
                        <span className="text-[8.5px] text-slate-600 mt-1">
                          {r.status === "disabled" ? t("mu.enable") : t("mu.disable")}
                        </span>
                      </div>
                      <button
                        onClick={() => setDelRow(r)}
                        title={t("c.delete")}
                        className="p-2.5 rounded-xl border border-red-400/25 text-red-300 bg-red-400/8 hover:bg-red-400/18 transition-colors"
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* -------- config modal -------- */}
      <Modal
        open={!!configRow}
        onClose={() => setConfigRow(null)}
        title={configRow ? t("mu.configTitle", { name: configRow.label }) : ""}
      >
        {configRow && (
          <div className="space-y-4">
            <div className="flex justify-center">
              <div className="rounded-3xl bg-white p-3 shadow-[0_10px_40px_-10px_rgba(56,225,212,.5)]">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={configRow.qr} alt="QR" className="w-44 h-44 rounded-xl" />
              </div>
            </div>
            <div className="text-center text-[11px] text-slate-500">{t("mu.qr")}</div>
            <div className="rounded-2xl bg-black/45 border border-white/10 p-3 max-h-32 overflow-y-auto">
              <code className="text-[10px] text-[#ffe082] break-all font-mono leading-5" dir="ltr">
                {configRow.config}
              </code>
            </div>
            <div className="flex gap-2">
              <CopyBtn text={configRow.config} label={t("mu.copyConfig")} className="flex-1 justify-center py-2.5" />
              <button
                type="button"
                onClick={() => {
                  const blob = new Blob([configRow.config], { type: "text/plain" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a");
                  a.href = url;
                  a.download = `${configRow.label.replace(/\s+/g, "-")}.${
                    configRow.protocol === "wireguard" ? "conf" : "txt"
                  }`;
                  a.click();
                  URL.revokeObjectURL(url);
                }}
                title={t("mu.download")}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-[#d4a800]/35 text-[#f5c518] bg-[#d4a800]/10 hover:bg-[#d4a800]/20 px-3.5 py-2.5 text-xs font-bold transition-colors"
              >
                <Download size={14} />
              </button>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center gap-1.5 justify-center">
              <KeyRound size={11} /> {t("mu.individual")} ({shop})
            </div>
          </div>
        )}
      </Modal>

      {/* -------- renew modal -------- */}
      <Modal
        open={!!renewRow}
        onClose={() => setRenewRow(null)}
        title={renewRow ? t("mu.renewTitle", { name: renewRow.label }) : ""}
      >
        {renewRow && (
          <div className="space-y-5">
            <p className="text-xs text-slate-400 -mt-1">{t("mu.renewSub")}</p>
            <div className="grid grid-cols-2 gap-4">
              <Field label={t("mu.addGb")}>
                <input
                  type="number"
                  className="field"
                  dir="ltr"
                  min={0}
                  value={addGb}
                  onChange={(e) => setAddGb(Math.max(0, Number(e.target.value)))}
                />
              </Field>
              <Field label={t("mu.addDays")}>
                <input
                  type="number"
                  className="field"
                  dir="ltr"
                  min={0}
                  value={addDays}
                  onChange={(e) => setAddDays(Math.max(0, Number(e.target.value)))}
                />
              </Field>
            </div>
            <div className="glass rounded-2xl p-4 space-y-2 text-[13px]">
              <div className="flex justify-between">
                <span className="text-slate-400">{t("mu.renewCost")}</span>
                <span className="font-black text-grad">{fmtToman(renewCost)}</span>
              </div>
              <div className="flex justify-between border-t border-white/8 pt-2">
                <span className="text-slate-400">{t("svc.balanceAfter")}</span>
                <span className={cn("font-bold", renewInsufficient ? "text-red-300" : "text-emerald-300")}>
                  {fmtToman(balance - renewCost)}
                </span>
              </div>
            </div>
            {renewInsufficient && (
              <div className="text-xs text-red-300 bg-red-400/10 border border-red-400/25 rounded-xl px-3.5 py-2.5">
                {t("svc.insufficient")}
              </div>
            )}
            <div className="flex gap-2.5">
              <Btn
                className="flex-1"
                loading={pending}
                disabled={(addGb === 0 && addDays === 0) || renewInsufficient}
                onClick={() =>
                  act(
                    () => renewVpnUser({ id: renewRow.id, addGb, addDays }),
                    "mu.renewed",
                    () => setRenewRow(null)
                  )
                }
              >
                {t("mu.renew")}
              </Btn>
              <Btn variant="ghost" onClick={() => setRenewRow(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* -------- reset modal -------- */}
      <Modal
        open={!!resetRow}
        onClose={() => setResetRow(null)}
        title={t("mu.reset")}
      >
        {resetRow && (
          <div className="space-y-4">
            <div className="text-sm text-slate-300">
              {t("mu.resetCostHint", { gb: fmtGb(resetRow.usedGb) })}
            </div>
            <div className="glass rounded-2xl p-4 flex justify-between text-[13px]">
              <span className="text-slate-400">{t("svc.cost")}</span>
              <span className="font-black text-grad">
                {fmtToman(Math.round(resetRow.usedGb * resetRow.pricePerGb))}
              </span>
            </div>
            <div className="flex gap-2.5">
              <Btn
                className="flex-1"
                variant="soft"
                loading={pending}
                onClick={() => act(() => resetUsage(resetRow.id), "mu.resetOk", () => setResetRow(null))}
              >
                <RotateCcw size={15} />
                {t("mu.reset")}
              </Btn>
              <Btn variant="ghost" onClick={() => setResetRow(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* -------- delete modal -------- */}
      <Modal open={!!delRow} onClose={() => setDelRow(null)} title={t("mu.delTitle")}>
        {delRow && (
          <div className="space-y-4">
            <p className="text-sm text-slate-300 leading-7">
              {t("mu.delSub", { name: delRow.label })}
            </p>
            <div className="flex gap-2.5">
              <Btn
                variant="danger"
                className="flex-1"
                loading={pending}
                onClick={() => act(() => deleteVpnUser(delRow.id), "mu.deleted", () => setDelRow(null))}
              >
                <Trash2 size={15} />
                {t("c.delete")}
              </Btn>
              <Btn variant="ghost" onClick={() => setDelRow(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
