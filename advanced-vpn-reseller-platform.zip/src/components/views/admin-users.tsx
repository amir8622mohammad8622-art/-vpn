"use client";

import React, { useMemo, useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  Ban,
  CalendarClock,
  CircleOff,
  Eye,
  HandCoins,
  Search,
  ShieldCheck,
  UserCheck,
  UsersRound,
  Wallet,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, Field, Modal, PageTitle } from "@/components/ui";
import { adjustBalance, setUserStatus } from "@/lib/actions/admin";
import { cn } from "@/lib/utils";

type Row = {
  id: number;
  username: string;
  shopName: string;
  telegram: string;
  balance: number;
  totalSpent: number;
  status: string;
  role: string;
  vpnCount: number;
  createdAt: string;
  lastSeenAt: string | null;
};

export function AdminUsersView({ rows }: { rows: Row[] }) {
  const { t, fmtNum, fmtToman, fmtDate, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [q, setQ] = useState("");
  const [adjustRow, setAdjustRow] = useState<Row | null>(null);
  const [detailRow, setDetailRow] = useState<Row | null>(null);
  const [amount, setAmount] = useState("100000");
  const [reason, setReason] = useState("");

  const filtered = useMemo(
    () =>
      rows.filter(
        (r) =>
          q === "" ||
          r.username.toLowerCase().includes(q.toLowerCase()) ||
          r.shopName.toLowerCase().includes(q.toLowerCase())
      ),
    [rows, q]
  );

  const toggleBan = (r: Row) =>
    start(async () => {
      const res = await setUserStatus({
        userId: r.id,
        status: r.status === "banned" ? "active" : "banned",
      });
      push(res.ok ? "ok" : "err", t(res.ok ? (r.status === "banned" ? "au.unbanned" : "au.banned") : (res.error ?? "err.generic")));
    });

  const applyAdjust = () => {
    if (!adjustRow) return;
    start(async () => {
      const r = await adjustBalance({ userId: adjustRow.id, amount: Number(amount) || 0, reason });
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      push("ok", t("au.applied"));
      setAdjustRow(null);
      setAmount("100000");
      setReason("");
    });
  };

  return (
    <div>
      <PageTitle title={t("au.title")} sub={t("au.sub")} />

      <div className="relative max-w-sm mb-5">
        <Search size={15} className="absolute top-1/2 -translate-y-1/2 start-3.5 text-slate-500" />
        <input className="field ps-10" value={q} onChange={(e) => setQ(e.target.value)} placeholder={t("au.searchPh")} />
      </div>

      {filtered.length === 0 ? (
        <Card>
          <Empty icon={<UsersRound size={24} />} title={t("wal.noData")} />
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[760px]">
              <thead>
                <tr className="text-[10.5px] text-slate-500 border-b border-white/8">
                  <th className="text-start font-medium px-5 py-3.5">{t("au.col.user")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("au.col.balance")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("au.col.spent")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("au.col.vpn")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("au.col.joined")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("c.status")}</th>
                  <th className="text-start font-medium px-4 py-3.5">{t("c.actions")}</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((r, i) => (
                  <motion.tr
                    key={r.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: Math.min(i * 0.03, 0.3) }}
                    className="border-b border-white/5 table-row-hover"
                  >
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <span
                          className={cn(
                            "w-9 h-9 rounded-xl border flex items-center justify-center text-xs font-black shrink-0",
                            r.role === "admin"
                              ? "bg-[#d4a800]/20 border-[#d4a800]/40 text-[#ffe082]"
                              : "bg-gradient-to-br from-[#f472b6]/30 to-[#d4a800]/30 border-white/12"
                          )}
                        >
                          {(r.shopName || r.username).slice(0, 1).toUpperCase()}
                        </span>
                        <div className="min-w-0">
                          <div className="font-bold text-[13px] truncate max-w-40 flex items-center gap-1.5">
                            {r.shopName || r.username}
                            {r.role === "admin" && <ShieldCheck size={12} className="text-[#f5c518]" />}
                          </div>
                          <div className="text-[10.5px] text-slate-500" dir="ltr">
                            @{r.username} {r.telegram && `· ${r.telegram}`}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3.5 font-black text-[13px] whitespace-nowrap">{fmtToman(r.balance)}</td>
                    <td className="px-4 py-3.5 text-slate-400 text-[12px] whitespace-nowrap">{fmtToman(r.totalSpent)}</td>
                    <td className="px-4 py-3.5">
                      <Badge tone="sky">{fmtNum(r.vpnCount)}</Badge>
                    </td>
                    <td className="px-4 py-3.5 text-slate-500 text-[11.5px] whitespace-nowrap">{fmtDate(r.createdAt)}</td>
                    <td className="px-4 py-3.5">
                      {r.role === "admin" ? (
                        <Badge tone="violet">{t("au.adminRole")}</Badge>
                      ) : r.status === "banned" ? (
                        <Badge tone="red">{t("au.ban")}</Badge>
                      ) : (
                        <Badge tone="green" pulse>
                          {t("mu.st.active")}
                        </Badge>
                      )}
                    </td>
                    <td className="px-4 py-3.5">
                      {r.role !== "admin" && (
                        <div className="flex items-center gap-1.5">
                          <button
                            onClick={() => setDetailRow(r)}
                            title={t("c.view")}
                            className="p-2 rounded-xl border border-white/12 text-slate-300 hover:bg-white/8 transition-colors"
                          >
                            <Eye size={14} />
                          </button>
                          <button
                            onClick={() => {
                              setAdjustRow(r);
                              setAmount("100000");
                              setReason("");
                            }}
                            title={t("au.adjust")}
                            className="p-2 rounded-xl border border-[#38e1d4]/25 text-[#f5c518] bg-[#38e1d4]/8 hover:bg-[#38e1d4]/16 transition-colors"
                          >
                            <HandCoins size={14} />
                          </button>
                          <button
                            onClick={() => toggleBan(r)}
                            title={r.status === "banned" ? t("au.unban") : t("au.ban")}
                            className={cn(
                              "p-2 rounded-xl border transition-colors",
                              r.status === "banned"
                                ? "border-emerald-400/25 text-emerald-300 bg-emerald-400/8 hover:bg-emerald-400/16"
                                : "border-red-400/25 text-red-300 bg-red-400/8 hover:bg-red-400/16"
                            )}
                          >
                            {r.status === "banned" ? <UserCheck size={14} /> : <Ban size={14} />}
                          </button>
                        </div>
                      )}
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* adjust modal */}
      <Modal open={!!adjustRow} onClose={() => setAdjustRow(null)} title={t("au.adjust")}>
        {adjustRow && (
          <div className="space-y-4">
            <p className="text-xs text-slate-400">{t("au.adjustSub")}</p>
            <div className="glass rounded-2xl p-3.5 flex items-center justify-between text-[13px]">
              <span className="text-slate-400">{adjustRow.shopName || adjustRow.username}</span>
              <span className="font-black">{fmtToman(adjustRow.balance)}</span>
            </div>
            <Field label={t("au.amount")}>
              <input
                className="field font-mono"
                dir="ltr"
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </Field>
            <div className="flex flex-wrap gap-1.5">
              {[50000, 100000, 200000, -50000, -100000].map((v) => (
                <button
                  key={v}
                  onClick={() => setAmount(String(v))}
                  className="rounded-full px-3 py-1 text-[10.5px] font-bold border border-white/10 text-slate-400 hover:text-white hover:border-[#d4a800]/50 transition-all"
                >
                  {v > 0 ? "+" : ""}
                  {fmtNum(v)}
                </button>
              ))}
            </div>
            <Field label={t("au.reason")}>
              <input
                className="field"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder={t("au.reasonPh")}
                maxLength={200}
              />
            </Field>
            <div className="flex gap-2.5">
              <Btn className="flex-1" loading={pending} disabled={!Number(amount)} onClick={applyAdjust}>
                <Wallet size={14} /> {t("c.confirm")}
              </Btn>
              <Btn variant="ghost" onClick={() => setAdjustRow(null)}>
                {t("c.cancel")}
              </Btn>
            </div>
          </div>
        )}
      </Modal>

      {/* detail modal */}
      <Modal open={!!detailRow} onClose={() => setDetailRow(null)} title={t("au.detail")}>
        {detailRow && (
          <div className="space-y-3">
            <div className="flex items-center gap-3.5">
              <span className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#f472b6]/50 to-[#d4a800]/50 border border-white/15 flex items-center justify-center font-black text-xl">
                {(detailRow.shopName || detailRow.username).slice(0, 1).toUpperCase()}
              </span>
              <div>
                <div className="font-black">{detailRow.shopName || detailRow.username}</div>
                <div className="text-xs text-slate-500" dir="ltr">@{detailRow.username}</div>
              </div>
            </div>
            {(
              [
                [t("au.shop"), detailRow.shopName || t("c.none")],
                [t("auth.telegram"), detailRow.telegram || t("c.none")],
                [t("au.col.balance"), fmtToman(detailRow.balance)],
                [t("au.col.spent"), fmtToman(detailRow.totalSpent)],
                [t("au.col.vpn"), fmtNum(detailRow.vpnCount)],
                [t("au.col.joined"), fmtDateTime(detailRow.createdAt)],
                [t("au.lastSeen"), detailRow.lastSeenAt ? fmtDateTime(detailRow.lastSeenAt) : t("c.none")],
              ] as const
            ).map(([k, v], i) => (
              <div key={i} className="flex justify-between items-center glass rounded-xl px-3.5 py-2.5 text-[12.5px]">
                <span className="text-slate-500 flex items-center gap-2">{k}</span>
                <span className="font-bold">{v}</span>
              </div>
            ))}
            <div className="flex items-center gap-2 pt-1 text-[11px] text-slate-500">
              {detailRow.status === "banned" ? (
                <>
                  <CircleOff size={13} className="text-red-400" /> {t("au.ban")}
                </>
              ) : (
                <>
                  <CalendarClock size={13} className="text-emerald-400" /> {t("mu.st.active")}
                </>
              )}
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
