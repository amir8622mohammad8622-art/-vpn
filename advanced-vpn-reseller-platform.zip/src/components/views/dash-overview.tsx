"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Activity,
  ArrowUpLeft,
  ArrowDownLeft,
  Gauge,
  Link2,
  Plus,
  Server,
  Sparkles,
  Users,
  Wallet,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Badge, Card, CountUp, CopyBtn, UsageBar } from "@/components/ui";
import { cn } from "@/lib/utils";

type Tx = {
  id: number;
  type: string;
  amount: number;
  status: string;
  description: string;
  createdAt: string;
};

export function DashOverview({
  user,
  stats,
  txs,
  topUsers,
}: {
  user: {
    shopName: string;
    username: string;
    balance: number;
    totalSpent: number;
    subToken: string;
    status: string;
  };
  stats: { total: number; active: number; used: number; limit: number };
  txs: Tx[];
  topUsers: { id: number; label: string; usedGb: number; dataLimitGb: number; status: string }[];
}) {
  const { t, fmtToman, fmtGb, fmtDateTime } = useI18n();
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const subLink = `${origin}/api/sub/${user.subToken}`;

  const item = {
    hidden: { opacity: 0, y: 18 },
    show: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: { delay: i * 0.07, duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
    }),
  };

  return (
    <div>
      {/* header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-7">
        <div>
          <h1 className="text-2xl sm:text-[28px] font-black tracking-tight">
            {t("dash.welcome", { name: user.shopName || user.username })}
            <Sparkles size={20} className="inline-block ms-2 text-[#38e1d4] -mt-1" />
          </h1>
          <p className="text-sm text-slate-400 mt-1">{t("dash.welcomeSub")}</p>
        </div>
        <Link
          href="/dashboard/services"
          className="inline-flex items-center gap-2 rounded-2xl px-4.5 py-2.5 text-sm font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_8px_26px_-8px_rgba(212,168,0,.7)] hover:-translate-y-0.5 transition-transform"
        >
          <Plus size={16} />
          {t("dash.quickCreate")}
        </Link>
      </div>

      {user.balance < 30000 && (
        <motion.div variants={item} initial="hidden" animate="show" custom={0}>
          <Link
            href="/dashboard/wallet"
            className="mb-5 flex items-center gap-3 glass rounded-2xl px-4 py-3 border-[#f87171]/25 bg-red-400/[.05] hover:bg-red-400/[.09] transition-colors"
          >
            <Wallet size={16} className="text-red-300" />
            <span className="text-[13px] text-red-200">{t("dash.needCharge")}</span>
          </Link>
        </motion.div>
      )}

      {/* stat cards */}
      <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <motion.div variants={item} initial="hidden" animate="show" custom={1}>
          <Card glow className="p-5 relative overflow-hidden h-full">
            <div className="orb w-36 h-36 bg-[#d4a800]/30 -top-10 -end-10" />
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-7 h-7 rounded-xl bg-[#d4a800]/20 border border-[#d4a800]/35 flex items-center justify-center text-[#f5c518]">
                <Wallet size={14} />
              </span>
              {t("dash.balance")}
            </div>
            <div className="mt-3 text-[22px] font-black text-grad">
              <CountUp value={user.balance} format={(v) => fmtToman(v)} />
            </div>
            <Link
              href="/dashboard/wallet"
              className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-[#f5c518] hover:text-white transition-colors"
            >
              <Plus size={13} /> {t("dash.topUp")}
            </Link>
          </Card>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" custom={2}>
          <Card className="p-5 h-full">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-7 h-7 rounded-xl bg-[#38e1d4]/15 border border-[#38e1d4]/30 flex items-center justify-center text-[#f5c518]">
                <Users size={14} />
              </span>
              {t("dash.myUsersCount")}
            </div>
            <div className="mt-3 text-[22px] font-black">
              <CountUp value={stats.total} format={(v) => String(Math.round(v))} />
            </div>
            <div className="mt-3">
              <Badge tone="green" pulse>
                {stats.active} {t("dash.activeCount")}
              </Badge>
            </div>
          </Card>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" custom={3}>
          <Card className="p-5 h-full">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-7 h-7 rounded-xl bg-sky-400/15 border border-sky-400/30 flex items-center justify-center text-sky-300">
                <Gauge size={14} />
              </span>
              {t("dash.traffic")}
            </div>
            <div className="mt-3 text-[22px] font-black">
              <CountUp value={stats.used} format={(v) => fmtGb(v)} />
            </div>
            <div className="mt-3 space-y-1.5">
              <UsageBar used={stats.used} total={Math.max(stats.limit, 0.1)} />
              <div className="text-[10.5px] text-slate-500">
                {t("dash.of")} {fmtGb(stats.limit)}
              </div>
            </div>
          </Card>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" custom={4}>
          <Card className="p-5 h-full">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span className="w-7 h-7 rounded-xl bg-[#f472b6]/15 border border-[#f472b6]/30 flex items-center justify-center text-[#f9a8d4]">
                <Activity size={14} />
              </span>
              {t("dash.spent")}
            </div>
            <div className="mt-3 text-[22px] font-black">
              <CountUp value={user.totalSpent} format={(v) => fmtToman(v)} />
            </div>
            <div className="mt-3 text-[10.5px] text-slate-500">
              {t("au.col.spent")} · {t("dash.activeCount")}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* sub link + quick actions */}
      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-4 mt-4">
        <motion.div variants={item} initial="hidden" animate="show" custom={5}>
          <Card glow className="p-5 h-full">
            <div className="flex items-start gap-3">
              <span className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#d4a800]/30 to-[#38e1d4]/20 border border-[#d4a800]/40 flex items-center justify-center text-[#f5c518]">
                <Link2 size={17} />
              </span>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-sm">{t("dash.subLink")}</div>
                <div className="text-xs text-slate-400 mt-0.5">{t("dash.subLinkSub")}</div>
                <div className="mt-3 flex items-center gap-2">
                  <code
                    className="flex-1 truncate rounded-xl bg-black/40 border border-white/10 px-3 py-2 text-[11.5px] text-[#ffe082] font-mono"
                    dir="ltr"
                  >
                    {subLink}
                  </code>
                  <CopyBtn text={subLink} />
                </div>
              </div>
            </div>
            <div className="mt-4">
              <Link
                href="/dashboard/branding"
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#f5c518] hover:text-white transition-colors"
              >
                {t("dash.quickBrand")} <ArrowUpLeft size={13} />
              </Link>
            </div>
          </Card>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" custom={6}>
          <Card className="p-5 h-full">
            <div className="font-bold text-sm mb-3.5">{t("dash.quick")}</div>
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { href: "/dashboard/services", icon: <Plus size={16} />, l: t("dash.quickCreate"), c: "#d4a800" },
                { href: "/dashboard/wallet", icon: <Wallet size={16} />, l: t("dash.quickTopup"), c: "#38e1d4" },
                { href: "/dashboard/branding", icon: <Link2 size={16} />, l: t("dash.quickBrand"), c: "#f472b6" },
                { href: "/dashboard/users", icon: <Users size={16} />, l: t("nav.myUsers"), c: "#38bdf8" },
              ].map((q, i) => (
                <Link
                  key={i}
                  href={q.href}
                  className="group glass rounded-2xl p-3.5 hover:-translate-y-0.5 transition-transform"
                >
                  <span
                    className="w-8 h-8 rounded-xl flex items-center justify-center border mb-2"
                    style={{ color: q.c, borderColor: `${q.c}44`, background: `${q.c}18` }}
                  >
                    {q.icon}
                  </span>
                  <span className="block text-[11.5px] font-bold text-slate-300 group-hover:text-white transition-colors leading-4">
                    {q.l}
                  </span>
                </Link>
              ))}
            </div>
          </Card>
        </motion.div>
      </div>

      {/* recent tx + top users */}
      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        <motion.div variants={item} initial="hidden" animate="show" custom={7}>
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="font-bold text-sm">{t("dash.recentTx")}</div>
              <Link href="/dashboard/wallet" className="text-[11px] text-[#f5c518] hover:text-white transition-colors">
                {t("dash.viewAll")}
              </Link>
            </div>
            {txs.length === 0 ? (
              <div className="py-8 text-center text-sm text-slate-500">{t("dash.noTx")}</div>
            ) : (
              <div className="space-y-2">
                {txs.map((x) => (
                  <div key={x.id} className="flex items-center gap-3 rounded-xl px-2.5 py-2 table-row-hover">
                    <span
                      className={cn(
                        "w-8 h-8 rounded-xl flex items-center justify-center border shrink-0",
                        x.amount >= 0
                          ? "text-emerald-300 border-emerald-400/25 bg-emerald-400/10"
                          : "text-[#f9a8d4] border-[#f472b6]/25 bg-[#f472b6]/10"
                      )}
                    >
                      {x.amount >= 0 ? <ArrowDownLeft size={14} /> : <ArrowUpLeft size={14} />}
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[12.5px] font-bold truncate">
                        {t(`wal.tx.${x.type}`)}
                        {x.status === "pending" && (
                          <span className="ms-2 text-[10px] text-amber-300 font-medium">({t("wal.st.pending")})</span>
                        )}
                        {x.status === "rejected" && (
                          <span className="ms-2 text-[10px] text-red-300 font-medium">({t("wal.st.rejected")})</span>
                        )}
                      </div>
                      <div className="text-[10.5px] text-slate-500 truncate">
                        {x.description} · {fmtDateTime(x.createdAt)}
                      </div>
                    </div>
                    <div
                      className={cn(
                        "text-[12.5px] font-black font-mono",
                        x.amount >= 0 ? "text-emerald-300" : "text-slate-300"
                      )}
                      dir="ltr"
                    >
                      {x.amount >= 0 ? "+" : ""}
                      {x.amount.toLocaleString()}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </motion.div>

        <motion.div variants={item} initial="hidden" animate="show" custom={8}>
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="font-bold text-sm">{t("dash.usageTitle")}</div>
              <Link href="/dashboard/users" className="text-[11px] text-[#f5c518] hover:text-white transition-colors">
                {t("dash.viewAll")}
              </Link>
            </div>
            {topUsers.length === 0 ? (
              <div className="py-8 text-center">
                <Server size={22} className="mx-auto text-slate-600 mb-2" />
                <div className="text-sm text-slate-500">{t("mu.noUsers")}</div>
              </div>
            ) : (
              <div className="space-y-3">
                {topUsers.map((u) => (
                  <div key={u.id} className="space-y-1.5">
                    <div className="flex items-center justify-between text-[12px]">
                      <span className="font-bold truncate max-w-[60%]">{u.label}</span>
                      <span className="text-slate-500 font-mono" dir="ltr">
                        {fmtGb(u.usedGb)} / {fmtGb(u.dataLimitGb)}
                      </span>
                    </div>
                    <UsageBar used={u.usedGb} total={u.dataLimitGb} />
                  </div>
                ))}
              </div>
            )}
          </Card>
        </motion.div>
      </div>

    </div>
  );
}
