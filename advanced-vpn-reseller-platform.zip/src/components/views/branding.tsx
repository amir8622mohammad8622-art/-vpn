"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  CheckCircle2,
  Link2,
  QrCode,
  RefreshCcw,
  Rocket,
  Save,
  ShieldCheck,
  Smartphone,
  Sparkles,
  Store,
  TriangleAlert,
  Zap,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, CopyBtn, Field, Modal, PageTitle, UsageBar } from "@/components/ui";
import { regenerateToken, updateBranding } from "@/lib/actions/profile";

export function BrandingView({
  shopName,
  telegram,
  link,
  qr,
  stats,
}: {
  shopName: string;
  telegram: string;
  link: string;
  qr: string;
  stats: { users: number; usedGb: number; totalGb: number; expireAt: string | null };
}) {
  const { t, fmtGb, fmtNum, fmtDate } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [shop, setShop] = useState(shopName);
  const [tg, setTg] = useState(telegram);
  const [confirmRegen, setConfirmRegen] = useState(false);

  const save = () =>
    start(async () => {
      const r = await updateBranding({ shopName: shop, telegram: tg });
      push(r.ok ? "ok" : "err", t(r.ok ? "br.saved" : (r.error ?? "err.generic")));
    });

  const regen = () =>
    start(async () => {
      const r = await regenerateToken();
      push(r.ok ? "ok" : "err", t(r.ok ? "br.regenOk" : (r.error ?? "err.generic")));
      setConfirmRegen(false);
    });

  return (
    <div>
      <PageTitle title={t("br.title")} sub={t("br.sub")} />

      <div className="grid lg:grid-cols-[1.1fr_1fr] gap-4">
        {/* left: shop + link */}
        <div className="space-y-4">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <Card className="p-6">
              <div className="font-bold text-sm mb-4 flex items-center gap-2">
                <Store size={15} className="text-[#f5c518]" />
                {t("br.shop")}
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label={t("br.shop")}>
                  <input
                    className="field"
                    value={shop}
                    onChange={(e) => setShop(e.target.value)}
                    placeholder={t("br.shopPh")}
                    maxLength={80}
                  />
                </Field>
                <Field label={`${t("auth.telegram")} (${t("c.optional")})`}>
                  <input
                    className="field"
                    dir="ltr"
                    value={tg}
                    onChange={(e) => setTg(e.target.value)}
                    placeholder="@username"
                    maxLength={64}
                  />
                </Field>
              </div>
              <Btn className="mt-4" loading={pending} onClick={save}>
                <Save size={15} />
                {t("c.save")}
              </Btn>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.07 }}>
            <Card glow className="p-6 relative overflow-hidden">
              <div className="orb w-40 h-40 bg-[#38e1d4]/14 -bottom-16 -start-12" />
              <div className="relative">
                <div className="font-bold text-sm mb-1 flex items-center gap-2">
                  <Link2 size={15} className="text-[#f5c518]" />
                  {t("br.yourLink")}
                </div>
                <p className="text-[11px] text-slate-500 mb-3.5">{t("dash.subLinkSub")}</p>
                <div className="flex items-center gap-2">
                  <code
                    className="flex-1 truncate rounded-xl bg-black/45 border border-white/10 px-3.5 py-3 text-[12px] text-[#ffe082] font-mono"
                    dir="ltr"
                  >
                    {link}
                  </code>
                  <CopyBtn text={link} />
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-2.5">
                  <Btn variant="danger" size="sm" onClick={() => setConfirmRegen(true)}>
                    <RefreshCcw size={13} />
                    {t("br.regen")}
                  </Btn>
                  <Badge tone="amber">{t("br.regenWarn")}</Badge>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-2 text-[11px]">
                  <div className="glass rounded-xl p-2.5 flex items-center gap-2">
                    <QrCode size={13} className="text-[#f5c518]" />
                    {t("br.singbox")}
                    <CopyBtn text={link} className="ms-auto !px-2 !py-1 !text-[10px]" />
                  </div>
                  <div className="glass rounded-xl p-2.5 flex items-center gap-2">
                    <QrCode size={13} className="text-[#38e1d4]" />
                    {t("br.base64")}
                    <CopyBtn text={`${link}?b64=1`} className="ms-auto !px-2 !py-1 !text-[10px]" />
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>

          {/* how it works */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
            <Card className="p-6">
              <div className="font-bold text-sm mb-4 flex items-center gap-2">
                <Sparkles size={15} className="text-[#ffd166]" />
                {t("br.howTitle")}
              </div>
              <div className="space-y-3">
                {[t("br.how1"), t("br.how2"), t("br.how3")].map((s, i) => (
                  <div key={i} className="flex gap-3">
                    <span className="w-6 h-6 rounded-lg bg-[#d4a800]/15 border border-[#d4a800]/35 text-[#f5c518] text-[10.5px] font-black flex items-center justify-center shrink-0 mt-0.5">
                      {fmtNum(i + 1)}
                    </span>
                    <p className="text-[12.5px] leading-6 text-slate-400">{s}</p>
                  </div>
                ))}
              </div>
            </Card>
          </motion.div>
        </div>

        {/* right: QR + client preview */}
        <div className="space-y-4">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
            <Card className="p-6 flex flex-col items-center">
              <div className="font-bold text-sm mb-4 self-start flex items-center gap-2">
                <QrCode size={15} className="text-[#f5c518]" />
                {t("br.qr")}
              </div>
              {qr && (
                <div className="rounded-[26px] bg-white p-4 shadow-[0_16px_50px_-14px_rgba(56,225,212,.55)]">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={qr} alt="Sub link QR" className="w-52 h-52 rounded-2xl" />
                </div>
              )}
            </Card>
          </motion.div>

          {/* client preview */}
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <Card className="p-6">
              <div className="font-bold text-sm mb-1 flex items-center gap-2">
                <Smartphone size={15} className="text-[#f5c518]" />
                {t("br.preview")}
              </div>
              <p className="text-[11px] text-slate-500 mb-4">{t("br.previewSub")}</p>

              {/* fake phone */}
              <div className="mx-auto max-w-[290px] rounded-[30px] border border-white/12 bg-[#101830] p-3 shadow-2xl">
                <div className="rounded-[22px] bg-[#151f3d] overflow-hidden">
                  <div className="px-4 py-3 bg-gradient-to-l from-[#d4a800]/30 to-transparent border-b border-white/8 flex items-center justify-between">
                    <span className="font-black text-[13px] text-grad">{shop || t("brand.name")}</span>
                    <Badge tone="green" pulse>Live</Badge>
                  </div>
                  <div className="p-3.5 space-y-3">
                    <div>
                      <div className="flex justify-between text-[9.5px] text-slate-500 mb-1">
                        <span>{t("br.trafficInfo")}</span>
                        <span dir="ltr">{fmtGb(stats.usedGb)} / {fmtGb(stats.totalGb)}</span>
                      </div>
                      <UsageBar used={stats.usedGb} total={Math.max(stats.totalGb, 0.1)} />
                    </div>
                    <div className="flex justify-between text-[9.5px] text-slate-500">
                      <span>{t("br.validity")}</span>
                      <span>{stats.expireAt ? fmtDate(stats.expireAt) : t("c.none")}</span>
                    </div>
                    <div className="space-y-1.5 pt-1">
                      {[Rocket, Zap, ShieldCheck].map((Icon, i) => (
                        <div key={i} className="flex items-center gap-2 rounded-xl bg-white/[.04] border border-white/8 px-2.5 py-2">
                          <Icon size={13} className="text-[#f5c518]" />
                          <div className="min-w-0 flex-1">
                            <div className="text-[9.5px] font-bold truncate">
                              {["Monthly Pro", "Gaming LowPing", "Family Share"][i]} | {shop || t("brand.name")}
                            </div>
                            <div className="text-[8px] text-slate-500" dir="ltr">
                              {["vless://", "trojan://", "wg://"][i]}
                            </div>
                          </div>
                          <CheckCircle2 size={11} className="text-emerald-400" />
                        </div>
                      ))}
                    </div>
                    <div className="text-center text-[8.5px] text-slate-600 pt-1">
                      {fmtNum(stats.users)} {t("dash.myUsersCount")}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>
        </div>
      </div>

      {/* regen confirm */}
      <Modal open={confirmRegen} onClose={() => setConfirmRegen(false)} title={t("br.regen")}>
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <TriangleAlert size={18} className="text-[#ffd166] shrink-0 mt-0.5" />
            <p className="text-sm text-slate-300 leading-7">{t("br.regenWarn")}</p>
          </div>
          <div className="flex gap-2.5">
            <Btn variant="danger" className="flex-1" loading={pending} onClick={regen}>
              <RefreshCcw size={14} />
              {t("br.regen")}
            </Btn>
            <Btn variant="ghost" onClick={() => setConfirmRegen(false)}>
              {t("c.cancel")}
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
