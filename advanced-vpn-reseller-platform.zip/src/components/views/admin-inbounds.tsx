"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import { Boxes, Lock, Save, Server, Users } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Btn, Card, Empty, PageTitle, Toggle } from "@/components/ui";
import { setInboundPricing } from "@/lib/actions/admin";
import { cn, PROTOCOL_META } from "@/lib/utils";

type Row = {
  id: number;
  remark: string;
  protocol: string;
  port: number;
  network: string;
  security: string;
  pricePerGb: number;
  pricePerMonth: number;
  enabled: boolean;
  totalClients: number;
  panelName: string;
  location: string;
};

export function AdminInboundsView({ rows }: { rows: Row[] }) {
  const { t, fmtNum } = useI18n();
  const { push } = useToast();
  const [pendingId, setPendingId] = useState<number | null>(null);
  const [, start] = useTransition();
  const [drafts, setDrafts] = useState<Record<number, { gb: string; month: string; on: boolean }>>(
    Object.fromEntries(rows.map((r) => [r.id, { gb: String(r.pricePerGb), month: String(r.pricePerMonth), on: r.enabled }]))
  );

  const save = (id: number) => {
    const d = drafts[id];
    setPendingId(id);
    start(async () => {
      const r = await setInboundPricing({
        id,
        pricePerGb: Number(d.gb) || 0,
        pricePerMonth: Number(d.month) || 0,
        enabled: d.on,
      });
      push(r.ok ? "ok" : "err", t(r.ok ? "ai.saved" : (r.error ?? "err.generic")));
      setPendingId(null);
    });
  };

  return (
    <div>
      <PageTitle title={t("ai.title")} sub={t("ai.sub")} />

      {rows.length === 0 ? (
        <Card>
          <Empty icon={<Boxes size={24} />} title={t("wal.noData")} />
        </Card>
      ) : (
        <div className="space-y-3">
          {rows.map((r, i) => {
            const meta = PROTOCOL_META[r.protocol] ?? PROTOCOL_META.vless;
            const d = drafts[r.id];
            const dirty =
              Number(d.gb) !== r.pricePerGb || Number(d.month) !== r.pricePerMonth || d.on !== r.enabled;
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(i * 0.04, 0.35), duration: 0.4 }}
              >
                <Card className="p-4 sm:p-5">
                  <div className="flex flex-wrap items-center gap-x-5 gap-y-4">
                    <div className="flex items-center gap-3 min-w-56">
                      <span
                        className="w-11 h-11 rounded-2xl border flex items-center justify-center shrink-0"
                        style={{ color: meta.color, borderColor: `${meta.color}44`, background: meta.glow }}
                      >
                        <Server size={17} />
                      </span>
                      <div className="min-w-0">
                        <div className="font-bold text-sm flex items-center gap-2">
                          <span className="truncate max-w-52">{r.remark}</span>
                          <span className="text-base">{r.location}</span>
                        </div>
                        <div className="text-[10.5px] text-slate-500">{r.panelName}</div>
                        <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                          <span
                            className="text-[9.5px] px-1.5 py-0.5 rounded-md border inline-flex items-center gap-1"
                            style={{ color: meta.color, borderColor: `${meta.color}55` }}
                          >
                            {meta.label} <Lock size={8} />
                          </span>
                          <span className="text-[9.5px] text-slate-500" dir="ltr">
                            :{r.port} · {r.network}/{r.security}
                          </span>
                          <span className="text-[9.5px] text-slate-500 inline-flex items-center gap-1">
                            <Users size={9} /> {fmtNum(r.totalClients)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-end gap-3 flex-1 flex-wrap">
                      <div className="w-32">
                        <div className="text-[10.5px] text-slate-500 mb-1.5">{t("svc.perGb")} ({t("c.toman")})</div>
                        <input
                          className="field !py-2 !text-[13px] font-mono"
                          dir="ltr"
                          type="number"
                          min={0}
                          value={d.gb}
                          onChange={(e) => setDrafts({ ...drafts, [r.id]: { ...d, gb: e.target.value } })}
                        />
                      </div>
                      <div className="w-32">
                        <div className="text-[10.5px] text-slate-500 mb-1.5">{t("svc.monthly")} ({t("c.toman")})</div>
                        <input
                          className="field !py-2 !text-[13px] font-mono"
                          dir="ltr"
                          type="number"
                          min={0}
                          value={d.month}
                          onChange={(e) => setDrafts({ ...drafts, [r.id]: { ...d, month: e.target.value } })}
                        />
                      </div>
                      <div className="flex flex-col items-center gap-1.5 ms-1">
                        <span className="text-[9.5px] text-slate-500">{t("ai.visible")}</span>
                        <Toggle
                          on={d.on}
                          onChange={(v) => {
                            setDrafts({ ...drafts, [r.id]: { ...d, on: v } });
                          }}
                        />
                      </div>
                    </div>

                    <Btn
                      size="sm"
                      variant={dirty ? "primary" : "ghost"}
                      loading={pendingId === r.id}
                      disabled={!dirty}
                      onClick={() => save(r.id)}
                      className={cn(!dirty && "opacity-40")}
                    >
                      <Save size={13} /> {t("ai.save")}
                    </Btn>
                  </div>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
