"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import { CalendarClock, KeyRound, ShieldCheck, Trash2, UserPlus } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Field, PageTitle } from "@/components/ui";
import { addAdmin, removeAdmin } from "@/lib/actions/admin";
import { cn } from "@/lib/utils";

type Row = {
  id: number;
  username: string;
  shopName: string;
  telegram: string;
  createdAt: string;
  lastSeenAt: string | null;
};

export function AdminsView({ rows, meId }: { rows: Row[]; meId: number }) {
  const { t, fmtDate, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [form, setForm] = useState({ username: "", password: "", displayName: "" });

  const submit = () =>
    start(async () => {
      const r = await addAdmin(form);
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      push("ok", t("aa.created"));
      setForm({ username: "", password: "", displayName: "" });
    });

  const remove = (id: number) =>
    start(async () => {
      const r = await removeAdmin(id);
      push(r.ok ? "ok" : "err", t(r.ok ? "aa.removed" : (r.error ?? "err.generic")));
    });

  return (
    <div>
      <PageTitle title={t("aa.title")} sub={t("aa.sub")} />

      <div className="grid lg:grid-cols-[380px_1fr] gap-4 items-start">
        {/* add admin */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <Card glow className="p-5 relative overflow-hidden">
            <div className="orb w-36 h-36 bg-[#d4a800]/25 -top-12 -end-12" />
            <div className="relative">
              <div className="font-bold text-sm mb-4 flex items-center gap-2">
                <UserPlus size={15} className="text-[#f5c518]" />
                {t("aa.add")}
              </div>
              <div className="space-y-3.5">
                <Field label={t("auth.username")}>
                  <input
                    className="field font-mono"
                    dir="ltr"
                    value={form.username}
                    onChange={(e) => setForm({ ...form, username: e.target.value })}
                    placeholder="new_admin"
                    autoComplete="off"
                  />
                </Field>
                <Field label={t("aa.displayName")}>
                  <input
                    className="field"
                    value={form.displayName}
                    onChange={(e) => setForm({ ...form, displayName: e.target.value })}
                    placeholder={t("aa.displayNamePh")}
                    maxLength={80}
                  />
                </Field>
                <Field label={t("auth.password")} hint={t("pf.tooShort")}>
                  <input
                    className="field"
                    dir="ltr"
                    type="password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="••••••••"
                    autoComplete="new-password"
                  />
                </Field>
                <Btn
                  className="w-full"
                  loading={pending}
                  disabled={form.username.trim().length < 3 || form.password.length < 6}
                  onClick={submit}
                >
                  <ShieldCheck size={15} />
                  {t("aa.add")}
                </Btn>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* admins list */}
        <div className="space-y-3">
          {rows.map((r, i) => {
            const mine = r.id === meId;
            const lastOne = rows.length <= 1;
            return (
              <motion.div
                key={r.id}
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05, duration: 0.4 }}
              >
                <Card className="p-4 sm:p-5 flex flex-wrap items-center gap-4">
                  <span
                    className={cn(
                      "w-12 h-12 rounded-2xl border flex items-center justify-center font-black text-lg shrink-0",
                      mine
                        ? "bg-[#d4a800]/20 border-[#d4a800]/45 text-[#ffe082]"
                        : "bg-white/[.05] border-white/12 text-slate-300"
                    )}
                  >
                    {(r.shopName || r.username).slice(0, 1).toUpperCase()}
                  </span>
                  <div className="flex-1 min-w-40">
                    <div className="font-bold text-sm flex items-center gap-2">
                      {r.shopName || r.username}
                      <Badge tone="violet">
                        <ShieldCheck size={10} /> {t("au.adminRole")}
                      </Badge>
                      {mine && <Badge tone="green">{t("aa.you")}</Badge>}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5" dir="ltr">
                      @{r.username} {r.telegram && ` · ${r.telegram}`}
                    </div>
                    <div className="text-[10px] text-slate-600 mt-1 flex items-center gap-3">
                      <span className="inline-flex items-center gap-1">
                        <CalendarClock size={10} /> {fmtDate(r.createdAt)}
                      </span>
                      {r.lastSeenAt && <span>{t("au.lastSeen")}: {fmtDateTime(r.lastSeenAt)}</span>}
                    </div>
                  </div>
                  {!mine && (
                    <Btn
                      variant="danger"
                      size="sm"
                      loading={pending}
                      disabled={lastOne}
                      onClick={() => remove(r.id)}
                    >
                      <Trash2 size={13} /> {t("aa.remove")}
                    </Btn>
                  )}
                </Card>
              </motion.div>
            );
          })}
          <div className="glass rounded-2xl p-4 flex items-start gap-2.5 text-[11.5px] text-slate-500 leading-6">
            <KeyRound size={14} className="text-[#ffd166] shrink-0 mt-0.5" />
            {t("aa.note")}
          </div>
        </div>
      </div>
    </div>
  );
}
