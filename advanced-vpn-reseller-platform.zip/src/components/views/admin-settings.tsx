"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import { CreditCard, Megaphone, Save, Settings2, Wrench } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Btn, Card, Field, PageTitle } from "@/components/ui";
import { saveSettings } from "@/lib/actions/admin";
import type { SiteSettings } from "@/lib/settings";

export function AdminSettingsView({ initial }: { initial: SiteSettings }) {
  const { t } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [form, setForm] = useState(initial);

  const save = () =>
    start(async () => {
      const r = await saveSettings({
        card_number: form.card_number,
        card_holder: form.card_holder,
        min_charge: form.min_charge,
        support_user: form.support_user,
        announcement: form.announcement,
      });
      push(r.ok ? "ok" : "err", t(r.ok ? "as.saved" : (r.error ?? "err.generic")));
    });

  return (
    <div>
      <PageTitle title={t("as.title")} sub={t("as.sub")} />

      <div className="grid lg:grid-cols-2 gap-4 max-w-5xl">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-6">
            <div className="font-bold text-sm mb-5 flex items-center gap-2">
              <CreditCard size={15} className="text-[#f5c518]" />
              {t("as.payment")}
            </div>
            <div className="space-y-4">
              <Field label={t("as.cardNumber")}>
                <input
                  className="field font-mono"
                  dir="ltr"
                  value={form.card_number}
                  onChange={(e) => setForm({ ...form, card_number: e.target.value })}
                  maxLength={40}
                />
              </Field>
              <Field label={t("as.cardHolder")}>
                <input
                  className="field"
                  value={form.card_holder}
                  onChange={(e) => setForm({ ...form, card_holder: e.target.value })}
                  maxLength={80}
                />
              </Field>
              <Field label={t("as.minCharge")}>
                <input
                  className="field font-mono"
                  dir="ltr"
                  type="number"
                  min={0}
                  value={form.min_charge}
                  onChange={(e) => setForm({ ...form, min_charge: e.target.value })}
                />
              </Field>
            </div>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.07 }}>
          <Card className="p-6">
            <div className="font-bold text-sm mb-5 flex items-center gap-2">
              <Settings2 size={15} className="text-[#f5c518]" />
              {t("as.general")}
            </div>
            <div className="space-y-4">
              <Field label={t("as.support")}>
                <input
                  className="field font-mono"
                  dir="ltr"
                  value={form.support_user}
                  onChange={(e) => setForm({ ...form, support_user: e.target.value })}
                  maxLength={80}
                />
              </Field>
              <Field label={t("as.announce")}>
                <textarea
                  className="field min-h-28 resize-none"
                  value={form.announcement}
                  onChange={(e) => setForm({ ...form, announcement: e.target.value })}
                  placeholder={t("as.announcePh")}
                  maxLength={500}
                />
              </Field>
              <div className="glass rounded-2xl p-4 flex items-start gap-2.5 text-[11.5px] text-slate-500 leading-6">
                <Megaphone size={14} className="text-[#ffd166] shrink-0 mt-0.5" />
                {t("as.announce")}
                <Wrench size={12} className="opacity-0" />
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      <div className="mt-5 max-w-5xl">
        <Btn size="lg" loading={pending} onClick={save}>
          <Save size={16} />
          {t("c.save")}
        </Btn>
      </div>
    </div>
  );
}
