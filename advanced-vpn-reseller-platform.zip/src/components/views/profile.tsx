"use client";

import React, { useState, useTransition } from "react";
import { motion } from "framer-motion";
import { CalendarClock, KeyRound, ShieldCheck, Store, User as UserIcon } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Field, PageTitle } from "@/components/ui";
import { changePassword, updateBranding } from "@/lib/actions/profile";

export function ProfileView({
  user,
}: {
  user: {
    username: string;
    shopName: string;
    telegram: string;
    balance: number;
    totalSpent: number;
    role: string;
    createdAt: string;
  };
}) {
  const { t, fmtToman, fmtDate } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [pass, setPass] = useState({ current: "", next: "", next2: "" });
  const [shop, setShop] = useState(user.shopName);
  const [tg, setTg] = useState(user.telegram);

  const saveInfo = () =>
    start(async () => {
      const r = await updateBranding({ shopName: shop, telegram: tg });
      push(r.ok ? "ok" : "err", t(r.ok ? "br.saved" : (r.error ?? "err.generic")));
    });

  const submitPass = () => {
    if (pass.next !== pass.next2) return push("err", t("pf.mismatch"));
    start(async () => {
      const r = await changePassword({ current: pass.current, next: pass.next });
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      push("ok", t("pf.changed"));
      setPass({ current: "", next: "", next2: "" });
    });
  };

  return (
    <div>
      <PageTitle title={t("pf.title")} sub={t("pf.sub")} />

      <div className="grid lg:grid-cols-2 gap-4">
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
          <Card glow className="p-6 relative overflow-hidden">
            <div className="orb w-40 h-40 bg-[#d4a800]/22 -top-14 -end-14" />
            <div className="relative flex items-center gap-4">
              <span className="w-16 h-16 rounded-3xl bg-gradient-to-br from-[#f472b6]/70 to-[#d4a800]/70 border border-white/15 flex items-center justify-center font-black text-2xl">
                {(user.shopName || user.username).slice(0, 1).toUpperCase()}
              </span>
              <div>
                <div className="font-black text-lg">{user.shopName || user.username}</div>
                <div className="text-xs text-slate-500" dir="ltr">@{user.username}</div>
                <div className="mt-1.5">
                  <Badge tone={user.role === "admin" ? "violet" : "green"}>
                    {user.role === "admin" ? t("au.adminRole") : t("au.userRole")}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="relative grid grid-cols-2 gap-3 mt-6">
              <div className="glass rounded-2xl p-3.5">
                <div className="text-[10.5px] text-slate-500 flex items-center gap-1.5">
                  <CalendarClock size={11} /> {t("pf.memberSince")}
                </div>
                <div className="text-[13px] font-bold mt-1">{fmtDate(user.createdAt)}</div>
              </div>
              <div className="glass rounded-2xl p-3.5">
                <div className="text-[10.5px] text-slate-500">{t("dash.balance")}</div>
                <div className="text-[13px] font-bold mt-1 text-grad">{fmtToman(user.balance)}</div>
              </div>
            </div>

            <div className="relative mt-6 space-y-4">
              <div className="font-bold text-sm flex items-center gap-2">
                <Store size={14} className="text-[#f5c518]" />
                {t("pf.info")}
              </div>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label={t("br.shop")}>
                  <input className="field" value={shop} onChange={(e) => setShop(e.target.value)} maxLength={80} />
                </Field>
                <Field label={t("auth.telegram")}>
                  <input className="field" dir="ltr" value={tg} onChange={(e) => setTg(e.target.value)} maxLength={64} placeholder="@username" />
                </Field>
              </div>
              <Btn size="sm" loading={pending} onClick={saveInfo}>
                {t("pf.updateInfo")}
              </Btn>
            </div>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
          <Card className="p-6">
            <div className="font-bold text-sm mb-5 flex items-center gap-2">
              <KeyRound size={15} className="text-[#38e1d4]" />
              {t("pf.changePass")}
            </div>
            <div className="space-y-4">
              <Field label={t("pf.current")}>
                <input
                  type="password"
                  className="field"
                  dir="ltr"
                  value={pass.current}
                  onChange={(e) => setPass({ ...pass, current: e.target.value })}
                  autoComplete="current-password"
                />
              </Field>
              <div className="grid sm:grid-cols-2 gap-4">
                <Field label={t("pf.new")}>
                  <input
                    type="password"
                    className="field"
                    dir="ltr"
                    value={pass.next}
                    onChange={(e) => setPass({ ...pass, next: e.target.value })}
                    autoComplete="new-password"
                  />
                </Field>
                <Field label={t("pf.new2")}>
                  <input
                    type="password"
                    className="field"
                    dir="ltr"
                    value={pass.next2}
                    onChange={(e) => setPass({ ...pass, next2: e.target.value })}
                    autoComplete="new-password"
                  />
                </Field>
              </div>
              <Btn
                loading={pending}
                disabled={!pass.current || pass.next.length < 6}
                onClick={submitPass}
              >
                <ShieldCheck size={15} />
                {t("pf.changePass")}
              </Btn>
              <div className="glass rounded-2xl p-4 text-[11.5px] text-slate-500 leading-6 flex gap-2">
                <UserIcon size={14} className="shrink-0 mt-0.5 text-slate-400" />
                {t("pf.tooShort")}
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
