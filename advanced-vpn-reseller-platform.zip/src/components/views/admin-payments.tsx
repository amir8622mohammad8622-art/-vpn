"use client";

import React, { useMemo, useState, useTransition } from "react";
import { motion } from "framer-motion";
import { Banknote, CheckCircle2, Hourglass, XCircle, ZoomIn } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, Field, Modal, PageTitle } from "@/components/ui";
import { reviewPayment } from "@/lib/actions/admin";
import { cn } from "@/lib/utils";

type Row = {
  id: number;
  username: string;
  shop: string;
  amount: number;
  status: string;
  receiptPath: string;
  adminNote: string;
  createdAt: string;
};

export function AdminPaymentsView({ rows }: { rows: Row[] }) {
  const { t, fmtNum, fmtToman, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [filter, setFilter] = useState("pending");
  const [img, setImg] = useState<string | null>(null);
  const [rejectRow, setRejectRow] = useState<Row | null>(null);
  const [note, setNote] = useState("");

  const filtered = useMemo(
    () => rows.filter((r) => filter === "all" || r.status === filter),
    [rows, filter]
  );
  const pendingCount = rows.filter((r) => r.status === "pending").length;

  const approve = (id: number) =>
    start(async () => {
      const r = await reviewPayment({ id, approve: true, note: "" });
      push(r.ok ? "ok" : "err", t(r.ok ? "apr.approved" : (r.error ?? "err.generic")));
    });

  const reject = () => {
    if (!rejectRow) return;
    start(async () => {
      const r = await reviewPayment({ id: rejectRow.id, approve: false, note });
      push(r.ok ? "ok" : "err", t(r.ok ? "apr.rejected" : (r.error ?? "err.generic")));
      setRejectRow(null);
      setNote("");
    });
  };

  const chip = (v: string, label: string) => (
    <button
      key={v}
      onClick={() => setFilter(v)}
      className={cn(
        "rounded-full px-3 py-1 text-[11px] font-bold border transition-all",
        filter === v
          ? "border-[#d4a800]/60 bg-[#d4a800]/18 text-white"
          : "border-white/10 text-slate-400 hover:text-white"
      )}
    >
      {label}
    </button>
  );

  return (
    <div>
      <PageTitle title={t("apr.title")} sub={t("apr.sub")}>
        {pendingCount > 0 && (
          <Badge tone="amber" pulse>
            <Hourglass size={11} /> {fmtNum(pendingCount)}
          </Badge>
        )}
      </PageTitle>

      <div className="flex flex-wrap gap-1.5 mb-5">
        {chip("pending", t("wal.st.pending"))}
        {chip("approved", t("wal.st.approved"))}
        {chip("rejected", t("wal.st.rejected"))}
        {chip("all", t("c.all"))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <Empty icon={<Banknote size={24} />} title={t("apr.empty")} />
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((r, i) => (
            <motion.div
              key={r.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: Math.min(i * 0.05, 0.4), duration: 0.4 }}
            >
              <Card className="p-4 sm:p-5">
                <div className="flex flex-wrap items-center gap-4">
                  <span
                    className={cn(
                      "w-11 h-11 rounded-2xl border flex items-center justify-center shrink-0",
                      r.status === "pending"
                        ? "border-[#f0b429]/30 bg-[#f0b429]/10 text-[#ffd166]"
                        : r.status === "approved"
                          ? "border-emerald-400/30 bg-emerald-400/10 text-emerald-300"
                          : "border-red-400/30 bg-red-400/10 text-red-300"
                    )}
                  >
                    <Banknote size={17} />
                  </span>

                  <div className="min-w-40 flex-1">
                    <div className="font-bold text-sm flex items-center gap-2">
                      {r.shop || r.username}
                      <span className="text-[10.5px] text-slate-500 font-normal" dir="ltr">@{r.username}</span>
                    </div>
                    <div className="text-[10.5px] text-slate-500 mt-0.5">
                      #{r.id} · {fmtDateTime(r.createdAt)}
                    </div>
                    {r.adminNote && r.status === "rejected" && (
                      <div className="text-[10.5px] text-red-300/80 mt-0.5">{r.adminNote}</div>
                    )}
                  </div>

                  <div className="text-lg font-black text-grad" dir="ltr">
                    +{fmtToman(r.amount)}
                  </div>

                  {r.receiptPath && (
                    <button
                      onClick={() => setImg(r.receiptPath)}
                      className="inline-flex items-center gap-1.5 rounded-xl border border-[#38e1d4]/25 text-[#f5c518] bg-[#38e1d4]/8 hover:bg-[#38e1d4]/16 px-3 py-2 text-[11px] font-bold transition-colors"
                    >
                      <ZoomIn size={13} /> {t("apr.receipt")}
                    </button>
                  )}

                  {r.status === "pending" ? (
                    <div className="flex gap-2">
                      <Btn size="sm" loading={pending} onClick={() => approve(r.id)}>
                        <CheckCircle2 size={13} /> {t("apr.approve")}
                      </Btn>
                      <Btn size="sm" variant="danger" onClick={() => setRejectRow(r)}>
                        <XCircle size={13} /> {t("apr.reject")}
                      </Btn>
                    </div>
                  ) : (
                    <Badge tone={r.status === "approved" ? "green" : "red"}>
                      {r.status === "approved" ? <CheckCircle2 size={11} /> : <XCircle size={11} />}
                      {t(`wal.st.${r.status}`)}
                    </Badge>
                  )}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* image viewer */}
      <Modal open={!!img} onClose={() => setImg(null)} title={t("apr.receipt")}>
        {img && (
          <div className="flex justify-center">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={img} alt="receipt" className="max-h-[62vh] rounded-2xl border border-white/10" />
          </div>
        )}
      </Modal>

      {/* reject modal */}
      <Modal open={!!rejectRow} onClose={() => setRejectRow(null)} title={t("apr.reject")}>
        <div className="space-y-4">
          <Field label={t("au.reason")}>
            <textarea
              className="field min-h-20 resize-none"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder={t("apr.rejectPh")}
              maxLength={300}
            />
          </Field>
          <div className="flex gap-2.5">
            <Btn variant="danger" className="flex-1" loading={pending} onClick={reject}>
              <XCircle size={14} /> {t("apr.reject")}
            </Btn>
            <Btn variant="ghost" onClick={() => setRejectRow(null)}>
              {t("c.cancel")}
            </Btn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
