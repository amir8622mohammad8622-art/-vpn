"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Activity,
  ArrowUpLeft,
  Banknote,
  CircleDollarSign,
  Clock4,
  Server,
  UserPlus,
  Users,
  UsersRound,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { Badge, Card, CountUp, PageTitle } from "@/components/ui";
import { cn } from "@/lib/utils";

type Stats = {
  resellers: number;
  vpnUsers: number;
  vpnActive: number;
  revenue: number;
  pendingCount: number;
  pendingSum: number;
  panelsOnline: number;
  panelsTotal: number;
  trafficSold: number;
  weekly: number[];
};

export function AdminOverview({
  stats,
  latestPayments,
  latestUsers,
}: {
  stats: Stats;
  latestPayments: { id: number; username: string; shop: string; amount: number; status: string; createdAt: string }[];
  latestUsers: { id: number; username: string; shopName: string; balance: number; status: string; createdAt: string }[];
}) {
  const { t, fmtToman, fmtNum, fmtGb, fmtDateTime } = useI18n();

  const cards = [
    {
      l: t("admin.revenue"),
      v: <CountUp value={stats.revenue} format={(x) => fmtToman(x)} />,
      icon: <CircleDollarSign size={16} />,
      c: "#d4a800",
      grad: true,
    },
    {
      l: t("admin.pendingPay"),
      v: (
        <>
          <CountUp value={stats.pendingCount} format={(x) => fmtNum(x)} />
          <span className="block text-[11px] font-bold text-amber-300/90 mt-0.5">{fmtToman(stats.pendingSum)}</span>
        </>
      ),
      icon: <Clock4 size={16} />,
      c: "#f0b429",
      href: "/dashboard/admin/payments",
    },
    {
      l: t("admin.resellers"),
      v: <CountUp value={stats.resellers} format={(x) => fmtNum(x)} />,
      icon: <UsersRound size={16} />,
      c: "#38e1d4",
      href: "/dashboard/admin/users",
    },
    {
      l: t("admin.vpnUsers"),
      v: (
        <>
          <CountUp value={stats.vpnUsers} format={(x) => fmtNum(x)} />
          <span className="block text-[11px] font-bold text-emerald-300/90 mt-0.5">
            {fmtNum(stats.vpnActive)} {t("dash.activeCount")}
          </span>
        </>
      ),
      icon: <Users size={16} />,
      c: "#38bdf8",
    },
    {
      l: t("admin.panelsOnline"),
      v: (
        <span dir="ltr">
          {fmtNum(stats.panelsOnline)} / {fmtNum(stats.panelsTotal)}
        </span>
      ),
      icon: <Server size={16} />,
      c: "#f472b6",
      href: "/dashboard/admin/panels",
    },
    {
      l: t("admin.trafficSold"),
      v: <CountUp value={stats.trafficSold} format={(x) => fmtGb(x)} />,
      icon: <Activity size={16} />,
      c: "#fb923c",
    },
  ];

  const max = Math.max(...stats.weekly, 1);

  return (
    <div>
      <PageTitle title={t("admin.title")} sub={t("admin.sub")} />

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {cards.map((c, i) => {
          const inner = (
            <Card glow={c.grad} className="p-5 h-full relative overflow-hidden hover:-translate-y-1 transition-transform">
              {c.grad && <div className="orb w-44 h-44 bg-[#d4a800]/26 -top-16 -end-16" />}
              <div className="relative">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span
                    className="w-8 h-8 rounded-xl border flex items-center justify-center"
                    style={{ color: c.c, borderColor: `${c.c}44`, background: `${c.c}16` }}
                  >
                    {c.icon}
                  </span>
                  {c.l}
                  {c.href && <ArrowUpLeft size={12} className="text-slate-600" />}
                </div>
                <div className={cn("mt-3 text-[21px] font-black", c.grad && "text-grad")}>{c.v}</div>
              </div>
            </Card>
          );
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05, duration: 0.45 }}
            >
              {c.href ? <Link href={c.href}>{inner}</Link> : inner}
            </motion.div>
          );
        })}
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mt-4">
        {/* weekly chart */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
          <Card className="p-5">
            <div className="flex items-center justify-between mb-5">
              <div className="font-bold text-sm">{t("admin.thisWeek")}</div>
              <Badge tone="violet">
                <Banknote size={11} /> {fmtToman(stats.weekly.reduce((a, b) => a + b, 0))}
              </Badge>
            </div>
            <div className="flex items-end gap-2 h-36" dir="ltr">
              {stats.weekly.map((v, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                  <motion.div
                    initial={{ height: 4 }}
                    animate={{ height: `${Math.max(4, (v / max) * 100)}%` }}
                    transition={{ delay: 0.35 + i * 0.06, duration: 0.5, ease: "easeOut" }}
                    className="w-full rounded-xl bg-gradient-to-t from-[#d4a800]/30 to-[#38e1d4] relative group"
                    title={fmtToman(v)}
                  >
                    <span className="absolute -top-7 left-1/2 -translate-x-1/2 text-[9px] font-bold bg-black/80 border border-white/10 rounded-lg px-1.5 py-0.5 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                      {fmtNum(v)}
                    </span>
                  </motion.div>
                  <span className="text-[9px] text-slate-600">{["-6", "-5", "-4", "-3", "-2", "-1", "•"][i]}</span>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* latest payments */}
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.36 }}>
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="font-bold text-sm">{t("admin.latestPayments")}</div>
              <Link href="/dashboard/admin/payments" className="text-[11px] text-[#f5c518] hover:text-white">
                {t("dash.viewAll")}
              </Link>
            </div>
            {latestPayments.length === 0 ? (
              <div className="py-6 text-center text-sm text-slate-500">{t("apr.empty")}</div>
            ) : (
              <div className="space-y-2">
                {latestPayments.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-xl px-2.5 py-2 table-row-hover">
                    <span className="w-8 h-8 rounded-xl bg-[#f0b429]/12 border border-[#f0b429]/25 text-[#ffd166] flex items-center justify-center shrink-0">
                      <Banknote size={14} />
                    </span>
                    <div className="flex-1 min-w-0">
                      <div className="text-[12.5px] font-bold truncate">
                        {p.shop || p.username}
                        <span className="text-slate-500 font-normal"> @{p.username}</span>
                      </div>
                      <div className="text-[10.5px] text-slate-500">{fmtDateTime(p.createdAt)}</div>
                    </div>
                    <div className="text-[12px] font-black" dir="ltr">{fmtNum(p.amount)}</div>
                    <Badge tone={p.status === "pending" ? "amber" : p.status === "approved" ? "green" : "red"}>
                      {t(`wal.st.${p.status}`)}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </motion.div>
      </div>

      {/* newest users */}
      <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.42 }} className="mt-4">
        <Card className="p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="font-bold text-sm">{t("admin.latestUsers")}</div>
            <Link href="/dashboard/admin/users" className="text-[11px] text-[#f5c518] hover:text-white">
              {t("dash.viewAll")}
            </Link>
          </div>
          {latestUsers.length === 0 ? (
            <div className="py-6 text-center text-sm text-slate-500 flex items-center justify-center gap-2">
              <UserPlus size={16} /> {t("wal.noData")}
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
              {latestUsers.map((u) => (
                <Link
                  key={u.id}
                  href="/dashboard/admin/users"
                  className="glass rounded-2xl p-3.5 hover:-translate-y-0.5 transition-transform"
                >
                  <div className="flex items-center justify-between">
                    <span className="w-8 h-8 rounded-xl bg-gradient-to-br from-[#f472b6]/50 to-[#d4a800]/50 border border-white/12 flex items-center justify-center text-xs font-black">
                      {(u.shopName || u.username).slice(0, 1).toUpperCase()}
                    </span>
                    {u.status === "banned" && <Badge tone="red">{t("au.ban")}</Badge>}
                  </div>
                  <div className="mt-2.5 text-[12.5px] font-bold truncate">{u.shopName || u.username}</div>
                  <div className="text-[10px] text-slate-500">{fmtToman(u.balance)}</div>
                </Link>
              ))}
            </div>
          )}
        </Card>
      </motion.div>
    </div>
  );
}
