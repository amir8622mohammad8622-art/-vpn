"use client";

import React, { useRef, useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  ArrowDownLeft,
  ArrowUpLeft,
  BadgeCheck,
  Banknote,
  CheckCircle2,
  CloudUpload,
  CreditCard,
  Hourglass,
  Landmark,
  ReceiptText,
  Wallet as WalletIcon,
  XCircle,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, CopyBtn, CountUp, Empty, Field, PageTitle } from "@/components/ui";
import { requestTopUp } from "@/lib/actions/wallet";
import { cn } from "@/lib/utils";

type Req = {
  id: number;
  amount: number;
  status: string;
  adminNote: string;
  receiptPath: string;
  createdAt: string;
};
type Tx = {
  id: number;
  type: string;
  amount: number;
  status: string;
  description: string;
  createdAt: string;
};

export function WalletView({
  balance,
  settings,
  requests,
  txs,
}: {
  balance: number;
  settings: { cardNumber: string; cardHolder: string; minCharge: number };
  requests: Req[];
  txs: Tx[];
}) {
  const { t, fmtToman, fmtNum, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [amount, setAmount] = useState(200000);
  const [receipt, setReceipt] = useState<{ path: string; preview: string } | null>(null);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const pick = async (f: File | null) => {
    if (!f) return;
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", f);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = (await res.json()) as { ok: boolean; path?: string; error?: string };
      if (!data.ok || !data.path) {
        push("err", t(data.error ?? "err.upload"));
        return;
      }
      setReceipt({ path: data.path, preview: URL.createObjectURL(f) });
    } catch {
      push("err", t("err.upload"));
    } finally {
      setUploading(false);
    }
  };

  const submit = () => {
    if (!receipt) {
      push("err", t("wal.receiptNeeded"));
      return;
    }
    if (amount < settings.minCharge) {
      push("err", t("wal.minCharge", { n: fmtNum(settings.minCharge) }));
      return;
    }
    start(async () => {
      const r = await requestTopUp({ amount, receiptPath: receipt.path });
      if (!r.ok) {
        push("err", t(r.error ?? "err.generic"));
        return;
      }
      push("ok", t("wal.sent"));
      setReceipt(null);
      setAmount(200000);
      if (fileRef.current) fileRef.current.value = "";
    });
  };

  const reqBadge = (st: string) =>
    st === "approved" ? (
      <Badge tone="green">
        <CheckCircle2 size={11} /> {t("wal.st.approved")}
      </Badge>
    ) : st === "rejected" ? (
      <Badge tone="red">
        <XCircle size={11} /> {t("wal.st.rejected")}
      </Badge>
    ) : (
      <Badge tone="amber" pulse>
        <Hourglass size={11} /> {t("wal.st.pending")}
      </Badge>
    );

  return (
    <div>
      <PageTitle title={t("wal.title")} sub={t("wal.sub")} />

      <div className="grid lg:grid-cols-[1fr_1.2fr] gap-4">
        {/* balance + topup */}
        <div className="space-y-4">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}>
            <Card glow className="p-6 relative overflow-hidden">
              <div className="orb w-44 h-44 bg-[#d4a800]/28 -top-14 -end-14" />
              <div className="orb w-32 h-32 bg-[#38e1d4]/16 -bottom-12 -start-10" />
              <div className="relative">
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span className="w-8 h-8 rounded-xl bg-[#d4a800]/20 border border-[#d4a800]/35 flex items-center justify-center text-[#f5c518]">
                    <WalletIcon size={15} />
                  </span>
                  {t("wal.balance")}
                </div>
                <div className="mt-3 text-3xl font-black text-grad">
                  <CountUp value={balance} format={(v) => fmtToman(v)} />
                </div>
                <div className="mt-2 flex items-center gap-2 text-[11px] text-slate-500">
                  <Landmark size={11} />
                  {t("wal.minCharge", { n: fmtNum(settings.minCharge) })}
                </div>
              </div>
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.08 }}>
            <Card className="p-5">
              <div className="font-bold text-sm mb-1 flex items-center gap-2">
                <CreditCard size={15} className="text-[#38e1d4]" />
                {t("wal.topUpTitle")}
              </div>
              <p className="text-[11.5px] text-slate-400 leading-6 mb-4">{t("wal.topUpSub")}</p>

              {/* card box */}
              <div className="rounded-2xl border border-[#38e1d4]/25 bg-gradient-to-bl from-[#38e1d4]/[.07] to-transparent p-4 mb-4">
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <div className="text-[10px] text-slate-500">{t("wal.cardNumber")}</div>
                    <div className="font-mono font-black text-[15px] tracking-wider mt-0.5" dir="ltr">
                      {settings.cardNumber}
                    </div>
                    <div className="text-[10.5px] text-slate-400 mt-1">
                      {t("wal.cardHolder")}: <b>{settings.cardHolder}</b>
                    </div>
                  </div>
                  <CopyBtn text={settings.cardNumber.replace(/\s/g, "")} />
                </div>
              </div>

              <Field label={t("wal.amount")}>
                <input
                  type="number"
                  className="field font-mono"
                  dir="ltr"
                  value={amount}
                  min={0}
                  step={10000}
                  onChange={(e) => setAmount(Math.max(0, Number(e.target.value)))}
                />
              </Field>
              <div className="flex flex-wrap gap-1.5 mt-2 mb-4">
                {[100000, 200000, 500000, 1000000].map((v) => (
                  <button
                    key={v}
                    onClick={() => setAmount(v)}
                    className={cn(
                      "rounded-full px-3 py-1 text-[10.5px] font-bold border transition-all",
                      amount === v
                        ? "border-[#d4a800]/60 bg-[#d4a800]/18 text-white"
                        : "border-white/10 text-slate-400 hover:text-white"
                    )}
                  >
                    {fmtToman(v)}
                  </button>
                ))}
              </div>

              <Field label={t("wal.receipt")} hint={t("wal.receiptHint")}>
                <input
                  ref={fileRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => pick(e.target.files?.[0] ?? null)}
                />
                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className={cn(
                    "w-full rounded-2xl border-2 border-dashed p-5 flex flex-col items-center justify-center gap-2 transition-colors",
                    receipt
                      ? "border-emerald-400/40 bg-emerald-400/[.06]"
                      : "border-white/15 hover:border-[#d4a800]/50 hover:bg-[#d4a800]/[.05]"
                  )}
                >
                  {uploading ? (
                    <span className="text-xs text-slate-400">{t("c.loading")}</span>
                  ) : receipt ? (
                    <>
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={receipt.preview} alt="receipt" className="h-24 rounded-xl object-cover" />
                      <Badge tone="green">
                        <BadgeCheck size={11} /> {t("wal.receipt")}
                      </Badge>
                    </>
                  ) : (
                    <>
                      <CloudUpload size={22} className="text-[#f5c518]" />
                      <span className="text-[11.5px] text-slate-400">{t("wal.receiptHint")}</span>
                    </>
                  )}
                </button>
              </Field>

              <Btn className="w-full mt-4" size="lg" loading={pending} onClick={submit}>
                <Banknote size={16} />
                {t("wal.send")}
              </Btn>
            </Card>
          </motion.div>
        </div>

        {/* requests + history */}
        <div className="space-y-4">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.12 }}>
            <Card className="p-5">
              <div className="font-bold text-sm mb-4 flex items-center gap-2">
                <ReceiptText size={15} className="text-[#f5c518]" />
                {t("wal.requests")}
              </div>
              {requests.length === 0 ? (
                <div className="py-6 text-center text-sm text-slate-500">{t("wal.noData")}</div>
              ) : (
                <div className="space-y-2.5">
                  {requests.map((r) => (
                    <div key={r.id} className="glass rounded-2xl p-3.5 flex items-center gap-3 flex-wrap">
                      <div className="flex-1 min-w-32">
                        <div className="font-black text-sm">{fmtToman(r.amount)}</div>
                        <div className="text-[10.5px] text-slate-500 mt-0.5">{fmtDateTime(r.createdAt)}</div>
                        {r.adminNote && stNotEq(r.status, "pending") && (
                          <div className="text-[10.5px] text-slate-400 mt-1">
                            {t("wal.adminNote")}: {r.adminNote}
                          </div>
                        )}
                      </div>
                      {r.receiptPath && (
                        <a
                          href={r.receiptPath}
                          target="_blank"
                          rel="noreferrer"
                          className="text-[11px] text-[#f5c518] hover:text-white transition-colors"
                        >
                          {t("wal.receiptView")}
                        </a>
                      )}
                      {reqBadge(r.status)}
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.16 }}>
            <Card className="p-5">
              <div className="font-bold text-sm mb-4">{t("wal.history")}</div>
              {txs.length === 0 ? (
                <Empty icon={<ReceiptText size={22} />} title={t("wal.noData")} />
              ) : (
                <div className="space-y-1.5 max-h-[440px] overflow-y-auto pe-1">
                  {txs.map((x) => (
                    <div key={x.id} className="flex items-center gap-3 rounded-xl px-2.5 py-2.5 table-row-hover">
                      <span
                        className={cn(
                          "w-8 h-8 rounded-xl flex items-center justify-center border shrink-0",
                          x.amount >= 0
                            ? "text-emerald-300 border-emerald-400/25 bg-emerald-400/10"
                            : "text-[#f9a8d4] border-[#f472b6]/25 bg-[#f472b6]/10"
                        )}
                      >
                        {x.amount >= 0 ? <ArrowDownLeft size={14} /> : <ArrowUpLeft size={14} />}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="text-[12.5px] font-bold truncate flex items-center gap-2">
                          {t(`wal.tx.${x.type}`)}
                          {x.status !== "completed" && (
                            <span className={cn("text-[9.5px]", x.status === "pending" ? "text-amber-300" : "text-red-300")}>
                              ({t(`wal.st.${x.status}`)})
                            </span>
                          )}
                        </div>
                        <div className="text-[10.5px] text-slate-500 truncate">
                          {x.description || t("c.none")} · {fmtDateTime(x.createdAt)}
                        </div>
                      </div>
                      <div
                        className={cn("text-[12.5px] font-black font-mono shrink-0", x.amount >= 0 ? "text-emerald-300" : "text-slate-300")}
                        dir="ltr"
                      >
                        {x.amount >= 0 ? "+" : ""}
                        {x.amount.toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

function stNotEq(a: string, b: string) {
  return a !== b;
}
