"use client";

import React, { useMemo, useState, useTransition } from "react";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  Headset,
  LifeBuoy,
  Lock,
  MessagesSquare,
  SendHorizonal,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { Badge, Btn, Card, Empty, PageTitle } from "@/components/ui";
import { closeTicket, replyTicket } from "@/lib/actions/tickets";
import { cn } from "@/lib/utils";

export type AdminTicketRow = {
  id: number;
  subject: string;
  status: string;
  username: string;
  shopName: string;
  createdAt: string;
  messages: { id: number; mine: boolean; body: string; createdAt: string }[];
};

export function AdminTicketsView({ tickets }: { tickets: AdminTicketRow[] }) {
  const { t, fa, fmtNum, fmtDateTime } = useI18n();
  const { push } = useToast();
  const [pending, start] = useTransition();
  const [active, setActive] = useState<AdminTicketRow | null>(null);
  const [filter, setFilter] = useState("open");
  const [reply, setReply] = useState("");
  const BackIcon = fa ? ArrowRight : ArrowLeft;

  const activeFresh = tickets.find((x) => x.id === active?.id) ?? null;

  const filtered = useMemo(
    () => tickets.filter((tk) => filter === "all" || tk.status === filter),
    [tickets, filter]
  );

  const tone = (s: string): "amber" | "green" | "zinc" =>
    s === "open" ? "amber" : s === "answered" ? "green" : "zinc";

  const sendReply = () => {
    if (!activeFresh) return;
    start(async () => {
      const r = await replyTicket({ ticketId: activeFresh.id, body: reply });
      if (!r.ok) return push("err", t(r.error ?? "err.generic"));
      setReply("");
      push("ok", t("tk.reply"));
    });
  };

  const close = () => {
    if (!activeFresh) return;
    start(async () => {
      await closeTicket(activeFresh.id);
      push("ok", t("tk.close"));
    });
  };

  const chip = (v: string, label: string) => (
    <button
      key={v}
      onClick={() => setFilter(v)}
      className={cn(
        "rounded-full px-3 py-1 text-[11px] font-bold border transition-all",
        filter === v
          ? "border-[#d4a800]/60 bg-[#d4a800]/18 text-white"
          : "border-white/10 text-slate-400 hover:text-white"
      )}
    >
      {label}
    </button>
  );

  return (
    <div>
      <PageTitle title={t("tk.adminTitle")} sub={t("tk.adminSub")} />

      <div className="flex flex-wrap gap-1.5 mb-5">
        {chip("open", `${t("tk.st.open")} (${fmtNum(tickets.filter((x) => x.status === "open").length)})`)}
        {chip("answered", t("tk.st.answered"))}
        {chip("closed", t("tk.st.closed"))}
        {chip("all", t("c.all"))}
      </div>

      {tickets.length === 0 ? (
        <Card>
          <Empty icon={<LifeBuoy size={24} />} title={t("tk.empty")} />
        </Card>
      ) : (
        <div className="grid lg:grid-cols-[340px_1fr] gap-4">
          {/* list */}
          <Card className={cn("p-3 space-y-1.5 h-fit max-h-[72vh] overflow-y-auto", activeFresh && "hidden lg:block")}>
            {filtered.length === 0 ? (
              <div className="py-10 text-center text-sm text-slate-500">{t("tk.noResult")}</div>
            ) : (
              filtered.map((tk) => (
                <button
                  key={tk.id}
                  onClick={() => setActive(tk)}
                  className={cn(
                    "w-full text-start rounded-2xl px-3.5 py-3 transition-colors",
                    activeFresh?.id === tk.id
                      ? "bg-[#d4a800]/15 border border-[#d4a800]/35"
                      : "hover:bg-white/[.05] border border-transparent"
                  )}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[13px] font-bold truncate">{tk.subject}</span>
                    <Badge tone={tone(tk.status)} pulse={tk.status === "open"}>
                      {t(`tk.st.${tk.status}`)}
                    </Badge>
                  </div>
                  <div className="mt-1 flex items-center gap-2 text-[10.5px] text-slate-500">
                    <span className="font-bold text-[#f5c518]">{tk.shopName || tk.username}</span>
                    <span dir="ltr">@{tk.username}</span>
                    <span className="text-slate-600">·</span>
                    <span className="inline-flex items-center gap-1">
                      <MessagesSquare size={9} /> {fmtNum(tk.messages.length)}
                    </span>
                    <span className="ms-auto">{fmtDateTime(tk.createdAt)}</span>
                  </div>
                </button>
              ))
            )}
          </Card>

          {/* thread */}
          <Card className={cn("flex flex-col min-h-[420px] max-h-[72vh]", !activeFresh && "hidden lg:flex")}>
            {!activeFresh ? (
              <div className="flex-1 flex items-center justify-center">
                <Empty icon={<Headset size={24} />} title={t("tk.adminTitle")} />
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-white/8">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      onClick={() => setActive(null)}
                      className="lg:hidden p-1.5 rounded-lg hover:bg-white/10 text-slate-400"
                    >
                      <BackIcon size={16} />
                    </button>
                    <div className="min-w-0">
                      <div className="font-bold text-sm truncate">{activeFresh.subject}</div>
                      <div className="text-[10.5px] text-slate-500">
                        #{activeFresh.id} · {activeFresh.shopName || activeFresh.username}{" "}
                        <span dir="ltr">@{activeFresh.username}</span>
                      </div>
                    </div>
                  </div>
                  {activeFresh.status !== "closed" ? (
                    <Btn variant="danger" size="sm" loading={pending} onClick={close}>
                      <Lock size={12} /> {t("tk.close")}
                    </Btn>
                  ) : (
                    <Badge tone="zinc">{t("tk.st.closed")}</Badge>
                  )}
                </div>

                <div className="flex-1 overflow-y-auto p-5 space-y-3">
                  {activeFresh.messages.map((m) => (
                    <motion.div
                      key={m.id}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={cn("flex", m.mine ? "justify-end" : "justify-start")}
                    >
                      <div
                        className={cn(
                          "max-w-[78%] rounded-2xl px-4 py-2.5 text-[13px] leading-6",
                          m.mine
                            ? "bg-gradient-to-l from-[#d4a800]/85 to-[#e8b800]/70 text-white rounded-es-md"
                            : "glass rounded-ee-md"
                        )}
                      >
                        <div className="text-[9.5px] mb-1 opacity-70">
                          {m.mine ? t("tk.support") : t("tk.userSide")}
                        </div>
                        {m.body}
                        <div className="text-[9px] opacity-60 mt-1">{fmtDateTime(m.createdAt)}</div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                <div className="p-4 border-t border-white/8">
                  {activeFresh.status === "closed" ? (
                    <div className="text-center text-xs text-slate-500 py-2">{t("tk.closed")}</div>
                  ) : (
                    <div className="flex items-end gap-2">
                      <textarea
                        className="field flex-1 min-h-[44px] max-h-32 resize-none"
                        placeholder={t("tk.message")}
                        value={reply}
                        onChange={(e) => setReply(e.target.value)}
                      />
                      <Btn loading={pending} disabled={!reply.trim()} onClick={sendReply}>
                        <SendHorizonal size={15} className={fa ? "-scale-x-100" : ""} />
                      </Btn>
                    </div>
                  )}
                </div>
              </>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
