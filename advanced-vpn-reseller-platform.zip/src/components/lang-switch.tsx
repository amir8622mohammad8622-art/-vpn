"use client";

import { Languages } from "lucide-react";
import { useI18n, type Lang } from "@/lib/i18n";
import { cn } from "@/lib/utils";

export function LangSwitch({ compact }: { compact?: boolean }) {
  const { lang, setLang } = useI18n();
  const opt = (l: Lang, label: string) => (
    <button
      key={l}
      onClick={() => setLang(l)}
      className={cn(
        "px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all",
        lang === l
          ? "bg-gradient-to-l from-[#d4a800] to-[#e8b800] text-white shadow-[0_4px_14px_-2px_rgba(212,168,0,.6)]"
          : "text-slate-400 hover:text-white"
      )}
    >
      {label}
    </button>
  );
  return (
    <div
      className="inline-flex items-center gap-1 glass rounded-xl p-1"
      title="فارسی / English"
    >
      {!compact && <Languages size={13} className="text-slate-500 ms-1.5" />}
      {opt("fa", "فا")}
      {opt("en", "EN")}
    </div>
  );
}
