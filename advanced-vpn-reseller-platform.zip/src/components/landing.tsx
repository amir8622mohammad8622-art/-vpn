"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity,
  ArrowLeft,
  ArrowRight,
  Blocks,
  CreditCard,
  Gauge,
  Globe2,
  KeyRound,
  Layers,
  Link2,
  Lock,
  MessageCircleQuestion,
  Minus,
  Network,
  Plus,
  QrCode,
  Server,
  ShieldCheck,
  Sparkles,
  Wallet,
  Zap,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { LangSwitch } from "./lang-switch";
import { cn, PROTOCOL_META } from "@/lib/utils";

export type LivePrice = {
  protocol: string;
  remark: string;
  port: number;
  pricePerGb: number;
  pricePerMonth: number;
  location: string;
};

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: (i = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, delay: i * 0.08, ease: [0.22, 1, 0.36, 1] as const },
  }),
};

function Kicker({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 text-xs font-bold text-[#f5c518] tracking-wide">
      <span className="w-6 h-6 rounded-lg bg-[#d4a800]/15 border border-[#d4a800]/30 flex items-center justify-center">
        {icon}
      </span>
      {children}
    </span>
  );
}

function Arrow({ className }: { className?: string }) {
  const { fa } = useI18n();
  const Icon = fa ? ArrowLeft : ArrowRight;
  return <Icon size={16} className={className} />;
}

/* ------------------------------------------------------------------ */

export function Landing({
  loggedIn,
  livePricing,
}: {
  loggedIn: boolean;
  livePricing: LivePrice[];
}) {
  const { t, fa } = useI18n();
  const [scrolled, setScrolled] = useState(false);
  const [faqOpen, setFaqOpen] = useState<number>(0);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    fn();
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const features = [
    { icon: <Network size={22} />, t: t("land.f1t"), d: t("land.f1d"), big: true },
    { icon: <Link2 size={22} />, t: t("land.f2t"), d: t("land.f2d"), big: true },
    { icon: <Layers size={22} />, t: t("land.f3t"), d: t("land.f3d") },
    { icon: <Wallet size={22} />, t: t("land.f4t"), d: t("land.f4d") },
    { icon: <Gauge size={22} />, t: t("land.f5t"), d: t("land.f5d") },
    { icon: <ShieldCheck size={22} />, t: t("land.f6t"), d: t("land.f6d") },
  ];

  const steps = [
    { n: "01", t: t("land.h1t"), d: t("land.h1d"), icon: <CreditCard size={20} /> },
    { n: "02", t: t("land.h2t"), d: t("land.h2d"), icon: <Server size={20} /> },
    { n: "03", t: t("land.h3t"), d: t("land.h3d"), icon: <QrCode size={20} /> },
  ];

  const faqs = [
    [t("land.q1"), t("land.a1")],
    [t("land.q2"), t("land.a2")],
    [t("land.q3"), t("land.a3")],
    [t("land.q4"), t("land.a4")],
  ];

  const protocols = ["VLESS Reality", "VMess WS", "Trojan TLS", "Shadowsocks 2022", "WireGuard", "Hysteria 2", "API 3x-ui", "IP Limit", "Brand Link"];

  return (
    <div className="relative overflow-clip">
      {/* backdrop */}
      <div className="absolute inset-0 bg-grid" />
      <div className="orb w-[560px] h-[560px] bg-[#d4a800]/22 -top-40 start-[-120px]" />
      <div className="orb w-[460px] h-[460px] bg-[#38e1d4]/12 top-[30vh] end-[-140px]" />
      <div className="orb w-[380px] h-[380px] bg-[#f472b6]/10 top-[130vh] start-[20%]" />

      {/* ============ NAV ============ */}
      <header
        className={cn(
          "fixed top-0 inset-x-0 z-50 transition-all duration-300",
          scrolled ? "glass-deep border-b border-white/5 py-3" : "bg-transparent py-5"
        )}
      >
        <div className="mx-auto max-w-6xl px-4 sm:px-6 flex items-center justify-between gap-3">
          <Link href="/" className="flex items-center gap-2.5 group">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/logo-sm.png" alt="هکتور" width={36} height={36} className="rounded-xl group-hover:rotate-12 transition-transform" />
            <span className="font-black text-lg tracking-tight text-grad">
              {t("brand.name")}
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm text-slate-300">
            <a href="#features" className="link-fade hover:text-white transition-colors">{t("land.featKicker")}</a>
            <a href="#how" className="link-fade hover:text-white transition-colors">{t("land.howKicker")}</a>
            <a href="#pricing" className="link-fade hover:text-white transition-colors">{t("land.priceKicker")}</a>
            <a href="#faq" className="link-fade hover:text-white transition-colors">{t("land.faqKicker")}</a>
          </nav>

          <div className="flex items-center gap-2.5">
            <LangSwitch />
            <Link
              href={loggedIn ? "/dashboard" : "/login"}
              className="inline-flex items-center gap-1.5 text-sm font-bold rounded-2xl px-4 py-2 text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_8px_24px_-6px_rgba(212,168,0,.6)] hover:-translate-y-0.5 transition-transform"
            >
              {loggedIn ? t("land.open") : t("land.login")}
              <Arrow />
            </Link>
          </div>
        </div>
      </header>

      {/* ============ HERO ============ */}
      <section className="relative pt-32 sm:pt-40 pb-16 sm:pb-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 grid lg:grid-cols-[1.05fr_.95fr] gap-12 items-center">
          <div>
            <motion.span
              variants={fadeUp}
              initial="hidden"
              animate="show"
              className="inline-flex items-center gap-2 rounded-full glass px-3.5 py-1.5 text-xs font-medium text-[#c9c1ff]"
            >
              <Sparkles size={13} className="text-[#38e1d4]" />
              {t("land.badge")}
            </motion.span>

            <motion.h1
              variants={fadeUp}
              custom={1}
              initial="hidden"
              animate="show"
              className="mt-5 font-black leading-[1.12] text-[clamp(2rem,5.4vw,3.9rem)] tracking-tight"
            >
              {t("land.h1a")}{" "}
              <span className="text-grad whitespace-nowrap">{t("land.h1b")}</span>
            </motion.h1>

            <motion.p
              variants={fadeUp}
              custom={2}
              initial="hidden"
              animate="show"
              className="mt-5 text-slate-400 text-[15px] sm:text-base leading-8 max-w-xl"
            >
              {t("land.sub")}
            </motion.p>

            <motion.div
              variants={fadeUp}
              custom={3}
              initial="hidden"
              animate="show"
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <Link
                href={loggedIn ? "/dashboard" : "/register"}
                className="group inline-flex items-center gap-2 rounded-2xl px-6 py-3.5 font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_14px_40px_-8px_rgba(212,168,0,.7)] hover:-translate-y-0.5 hover:shadow-[0_18px_50px_-6px_rgba(212,168,0,.8)] transition-all"
              >
                {t("land.cta1")}
                <Arrow className="group-hover:-translate-x-1 rtl:group-hover:-translate-x-1 ltr:group-hover:translate-x-1 transition-transform" />
              </Link>
              {!loggedIn && (
                <Link
                  href="/login"
                  className="inline-flex items-center gap-2 rounded-2xl px-6 py-3.5 font-bold glass text-slate-200 hover:bg-white/8 transition-colors"
                >
                  <KeyRound size={16} className="text-[#38e1d4]" />
                  {t("land.cta2")}
                </Link>
              )}
            </motion.div>

            <motion.div
              variants={fadeUp}
              custom={4}
              initial="hidden"
              animate="show"
              className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-[12px] text-slate-400"
            >
              {[Globe2, CreditCard, Link2].map((Icon, i) => (
                <span key={i} className="inline-flex items-center gap-1.5">
                  <Icon size={13} className="text-[#38e1d4]" />
                  {t(`land.trust${i + 1}`)}
                </span>
              ))}
            </motion.div>
          </div>

          {/* Hero visual */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
            className="relative hidden lg:block"
          >
            <div className="relative rounded-[28px] overflow-hidden edge-glow">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/hero.jpg"
                alt="hector VPN"
                className="w-full aspect-square object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0a0f1e] via-transparent to-transparent" />
            </div>

            {/* floating cards */}
            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="show"
              custom={5}
              className="absolute -bottom-6 -start-8 glass-deep edge-glow rounded-2xl p-4 w-56 animate-float"
            >
              <div className="flex items-center gap-2 text-[11px] text-slate-400">
                <Wallet size={13} className="text-[#38e1d4]" />
                {t("dash.balance")}
              </div>
              <div className="mt-1.5 text-lg font-black text-grad">۴۵۰٬۰۰۰ {fa ? "تومان" : "Toman"}</div>
              <div className="mt-2 h-1.5 rounded-full bg-white/8 overflow-hidden">
                <div className="h-full w-2/3 rounded-full bg-gradient-to-l from-[#d4a800] to-[#38e1d4]" />
              </div>
            </motion.div>

            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="show"
              custom={6}
              className="absolute -top-5 -end-4 glass-deep edge-glow rounded-2xl p-3.5 w-48 animate-float-slow"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-400">{t("land.t1badge")}</span>
                <span className="flex items-center gap-1 text-[10px] text-emerald-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse-soft" />
                  Live
                </span>
              </div>
              <div className="mt-1.5 text-[12px] font-bold truncate">star-shop.hector/sub/9xk…</div>
              <div className="mt-2 flex gap-1">
                {Object.keys(PROTOCOL_META)
                  .slice(0, 3)
                  .map((p) => (
                    <span
                      key={p}
                      className="text-[9px] px-1.5 py-0.5 rounded-md border"
                      style={{
                        color: PROTOCOL_META[p].color,
                        borderColor: `${PROTOCOL_META[p].color}55`,
                        background: `${PROTOCOL_META[p].glow}`,
                      }}
                    >
                      {p.toUpperCase()}
                    </span>
                  ))}
              </div>
            </motion.div>

            <motion.div
              variants={fadeUp}
              initial="hidden"
              animate="show"
              custom={7}
              className="absolute top-1/2 -start-10 glass-deep edge-glow rounded-2xl px-3.5 py-2.5 flex items-center gap-2 animate-float"
            >
              <Lock size={14} className="text-[#f472b6]" />
              <span className="text-[11px] text-slate-300">{t("svc.locked")}</span>
            </motion.div>
          </motion.div>
        </div>

        {/* stats strip */}
        <motion.div
          variants={fadeUp}
          custom={5}
          initial="hidden"
          animate="show"
          className="mx-auto max-w-6xl px-4 sm:px-6 mt-16"
        >
          <div className="glass rounded-3xl px-6 py-5 grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              ["۵+", "land.stat1"],
              ["۹۹.۹٪", "land.stat2"],
              ["۱۲+", "land.stat3"],
              ["۱۰۰٪", "land.stat4"],
            ].map(([v, k], i) => (
              <div key={i} className="text-center">
                <div className="text-2xl font-black text-grad">{fa ? v : v.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))}</div>
                <div className="text-[11px] text-slate-400 mt-1">{t(k)}</div>
              </div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* ============ MARQUEE ============ */}
      <div className="relative py-5 border-y border-white/5 bg-white/[.015] overflow-hidden">
        <div className="flex gap-10 w-max animate-marquee" style={{ direction: "ltr" }}>
          {[...protocols, ...protocols].map((p, i) => (
            <span key={i} className="flex items-center gap-2.5 text-sm text-slate-400 whitespace-nowrap">
              <Zap size={13} className="text-[#d4a800]" />
              {p}
            </span>
          ))}
        </div>
      </div>

      {/* ============ FEATURES ============ */}
      <section id="features" className="relative py-24 scroll-mt-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="max-w-2xl"
          >
            <Kicker icon={<Blocks size={13} />}>{t("land.featKicker")}</Kicker>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black tracking-tight">{t("land.featTitle")}</h2>
            <p className="mt-3 text-slate-400">{t("land.featSub")}</p>
          </motion.div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {features.map((f, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-60px" }}
                custom={i}
                className={cn(
                  "group relative glass rounded-3xl p-6 overflow-hidden hover:-translate-y-1.5 transition-transform duration-300",
                  f.big && "sm:col-span-2"
                )}
              >
                <div className="absolute -top-16 -end-16 w-40 h-40 rounded-full bg-[#d4a800]/12 blur-3xl group-hover:bg-[#38e1d4]/15 transition-colors duration-500" />
                <div className="relative">
                  <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#d4a800]/25 to-[#38e1d4]/15 border border-[#d4a800]/30 text-[#f5c518] flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                    {f.icon}
                  </div>
                  <h3 className="mt-4 font-bold text-[15px]">{f.t}</h3>
                  <p className="mt-2 text-[13px] leading-6 text-slate-400">{f.d}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ HOW ============ */}
      <section id="how" className="relative py-24 scroll-mt-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="text-center max-w-2xl mx-auto"
          >
            <Kicker icon={<Activity size={13} />}>{t("land.howKicker")}</Kicker>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black tracking-tight">{t("land.howTitle")}</h2>
          </motion.div>

          <div className="mt-12 grid md:grid-cols-3 gap-4 relative">
            <div className="hidden md:block absolute top-10 inset-x-24 h-px bg-gradient-to-l from-transparent via-[#d4a800]/40 to-transparent" />
            {steps.map((s, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-60px" }}
                custom={i * 1.5}
                className="relative glass rounded-3xl p-6 text-center hover:-translate-y-1.5 transition-transform duration-300"
              >
                <div className="mx-auto w-14 h-14 rounded-3xl bg-gradient-to-br from-[#d4a800] to-[#e8b800] text-white flex items-center justify-center shadow-[0_10px_30px_-8px_rgba(212,168,0,.7)] relative z-10">
                  {s.icon}
                </div>
                <div className="mt-4 text-[11px] font-black text-[#38e1d4] tracking-[.2em]">{fa ? s.n : s.n}</div>
                <h3 className="mt-2 font-bold">{s.t}</h3>
                <p className="mt-2 text-[13px] leading-6 text-slate-400">{s.d}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ============ PRICING ============ */}
      <section id="pricing" className="relative py-24 scroll-mt-24">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="max-w-2xl"
          >
            <Kicker icon={<CreditCard size={13} />}>{t("land.priceKicker")}</Kicker>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black tracking-tight">{t("land.priceTitle")}</h2>
            <p className="mt-3 text-slate-400">{t("land.priceSub")}</p>
          </motion.div>

          <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {(livePricing.length ? livePricing : DEMO_PRICING).map((p, i) => {
              const meta = PROTOCOL_META[p.protocol] ?? PROTOCOL_META.vless;
              return (
                <motion.div
                  key={i}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true, margin: "-60px" }}
                  custom={i}
                  className="relative glass edge-glow rounded-3xl p-6 hover:-translate-y-1.5 transition-transform duration-300"
                >
                  <div className="flex items-center justify-between">
                    <span
                      className="text-[11px] font-bold px-2.5 py-1 rounded-full border"
                      style={{ color: meta.color, borderColor: `${meta.color}55`, background: meta.glow }}
                    >
                      {meta.label}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-black tracking-wider border border-white/15 rounded-lg px-2 py-1 text-slate-300">
                      <Globe2 size={10} className="text-[#38e1d4]" />
                      {p.location}
                    </span>
                  </div>
                  <div className="mt-4 font-bold text-[15px]">{p.remark}</div>
                  <div className="mt-1 text-xs text-slate-500 flex items-center gap-1.5">
                    <Lock size={11} /> {t("svc.locked")} · {t("svc.port")} {p.port}
                  </div>
                  <div className="mt-5 flex items-end justify-between">
                    <div>
                      <div className="text-[11px] text-slate-400">{t("svc.perGb")}</div>
                      <div className="text-xl font-black text-grad">
                        {fa
                          ? `${p.pricePerGb.toLocaleString("fa-IR")} ${t("c.toman")}`
                          : `${p.pricePerGb.toLocaleString()} ${t("c.toman")}`}
                      </div>
                    </div>
                    <div className="text-end">
                      <div className="text-[11px] text-slate-400">{t("svc.monthly")}</div>
                      <div className="font-bold text-sm">
                        {fa ? p.pricePerMonth.toLocaleString("fa-IR") : p.pricePerMonth.toLocaleString()}
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ============ FAQ ============ */}
      <section id="faq" className="relative py-24 scroll-mt-24">
        <div className="mx-auto max-w-3xl px-4 sm:px-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="text-center"
          >
            <Kicker icon={<MessageCircleQuestion size={13} />}>{t("land.faqKicker")}</Kicker>
            <h2 className="mt-3 text-3xl sm:text-4xl font-black tracking-tight">{t("land.faqTitle")}</h2>
          </motion.div>

          <div className="mt-10 space-y-3">
            {faqs.map(([q, a], i) => {
              const open = faqOpen === i;
              return (
                <motion.div
                  key={i}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="show"
                  viewport={{ once: true, margin: "-40px" }}
                  custom={i}
                  className="glass rounded-2xl overflow-hidden"
                >
                  <button
                    onClick={() => setFaqOpen(open ? -1 : i)}
                    className="w-full flex items-center justify-between gap-4 px-5 py-4 text-start"
                  >
                    <span className="font-bold text-sm">{q}</span>
                    <span className="shrink-0 w-7 h-7 rounded-xl bg-white/6 flex items-center justify-center text-[#f5c518]">
                      {open ? <Minus size={14} /> : <Plus size={14} />}
                    </span>
                  </button>
                  <AnimatePresence initial={false}>
                    {open && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                      >
                        <p className="px-5 pb-5 text-[13px] leading-7 text-slate-400">{a}</p>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ============ FINAL CTA ============ */}
      <section className="relative py-24">
        <div className="mx-auto max-w-4xl px-4 sm:px-6">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-80px" }}
            className="relative glass-deep edge-glow rounded-[32px] p-10 sm:p-14 text-center overflow-hidden"
          >
            <div className="orb w-72 h-72 bg-[#d4a800]/30 -top-24 -start-16" />
            <div className="orb w-72 h-72 bg-[#38e1d4]/18 -bottom-28 -end-16" />
            <div className="relative">
              <ShieldCheck size={34} className="mx-auto text-[#38e1d4]" />
              <h2 className="mt-5 text-2xl sm:text-4xl font-black tracking-tight text-grad">{t("land.finalCta")}</h2>
              <p className="mt-3 text-slate-400">{t("land.finalSub")}</p>
              <Link
                href={loggedIn ? "/dashboard" : "/register"}
                className="mt-7 inline-flex items-center gap-2 rounded-2xl px-7 py-4 font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_16px_44px_-10px_rgba(212,168,0,.8)] hover:-translate-y-1 transition-transform"
              >
                {t("land.cta1")}
                <Arrow />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ============ FOOTER ============ */}
      <footer className="relative border-t border-white/5 py-10">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/images/logo-sm.png" alt="هکتور" width={32} height={32} className="rounded-lg" />
            <span className="font-black text-grad">{t("brand.name")}</span>
            <span className="text-xs text-slate-500">{t("brand.tag")}</span>
          </div>
          <div className="text-xs text-slate-500">
            <span>{t("land.footer")}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

const DEMO_PRICING: LivePrice[] = [
  { protocol: "vless", remark: "Germany 01 — Reality", port: 443, pricePerGb: 4500, pricePerMonth: 12000, location: "DE" },
  { protocol: "trojan", remark: "Netherlands — TLS WS", port: 8443, pricePerGb: 3800, pricePerMonth: 10000, location: "NL" },
  { protocol: "wireguard", remark: "Turkey — WireGuard", port: 51820, pricePerGb: 3200, pricePerMonth: 9000, location: "TR" },
];
