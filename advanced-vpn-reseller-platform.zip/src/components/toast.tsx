"use client";

import React, { createContext, useCallback, useContext, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CheckCircle2, AlertTriangle, Info } from "lucide-react";
import { cn } from "@/lib/utils";

type Toast = { id: number; msg: string; kind: "ok" | "err" | "info" };

const Ctx = createContext<{ push: (kind: Toast["kind"], msg: string) => void } | null>(
  null
);

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);

  const push = useCallback((kind: Toast["kind"], msg: string) => {
    const id = Date.now() + Math.random();
    setItems((arr) => [...arr.slice(-3), { id, msg, kind }]);
    setTimeout(() => setItems((arr) => arr.filter((t) => t.id !== id)), 3600);
  }, []);

  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div className="fixed bottom-4 inset-x-0 z-[200] flex flex-col items-center gap-2 pointer-events-none px-4">
        <AnimatePresence>
          {items.map((t) => (
            <motion.div
              key={t.id}
              initial={{ y: 26, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 12, opacity: 0, scale: 0.95 }}
              transition={{ type: "spring", damping: 24, stiffness: 380 }}
              className={cn(
                "glass-deep edge-glow rounded-2xl px-4 py-2.5 text-sm flex items-center gap-2.5 shadow-2xl pointer-events-auto",
                t.kind === "ok" && "text-emerald-200",
                t.kind === "err" && "text-red-200",
                t.kind === "info" && "text-slate-200"
              )}
            >
              {t.kind === "ok" && <CheckCircle2 size={16} className="text-emerald-400" />}
              {t.kind === "err" && <AlertTriangle size={16} className="text-red-400" />}
              {t.kind === "info" && <Info size={16} className="text-sky-400" />}
              {t.msg}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(Ctx);
  if (!ctx) return { push: () => {} };
  return ctx;
}
