"use client";

import React, { useEffect, useState } from "react";
import { AnimatePresence, animate, motion, useMotionValue } from "framer-motion";
import { Check, Copy, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { useI18n } from "@/lib/i18n";

/* ---------------------------------------------------------------- */
/* Button                                                            */
/* ---------------------------------------------------------------- */
type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "ghost" | "danger" | "soft";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
};

export function Btn({
  variant = "primary",
  size = "md",
  loading,
  className,
  children,
  disabled,
  ...rest
}: BtnProps) {
  const base =
    "relative inline-flex items-center justify-center gap-2 rounded-2xl font-medium transition-all duration-200 select-none disabled:opacity-50 disabled:pointer-events-none active:scale-[.97]";
  const variants = {
    primary:
      "text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_8px_30px_-6px_rgba(212,168,0,.55)] hover:shadow-[0_10px_40px_-4px_rgba(212,168,0,.7)] hover:-translate-y-0.5 overflow-hidden",
    ghost:
      "glass text-slate-200 hover:bg-white/[.08] hover:-translate-y-0.5",
    soft: "bg-[#d4a800]/15 text-[#b7adff] border border-[#d4a800]/30 hover:bg-[#d4a800]/25",
    danger:
      "bg-red-500/12 text-red-300 border border-red-400/25 hover:bg-red-500/22",
  };
  const sizes = {
    sm: "text-xs px-3 py-1.5",
    md: "text-sm px-4.5 py-2.5",
    lg: "text-base px-6 py-3.5",
  };
  return (
    <button
      className={cn(base, variants[variant], sizes[size], className)}
      disabled={disabled || loading}
      {...rest}
    >
      {variant === "primary" && (
        <span className="absolute inset-0 shimmer pointer-events-none" />
      )}
      {loading && <Loader2 size={15} className="animate-spin" />}
      {children}
    </button>
  );
}

/* ---------------------------------------------------------------- */
/* Card                                                              */
/* ---------------------------------------------------------------- */
export function Card({
  className,
  children,
  glow,
}: {
  className?: string;
  children: React.ReactNode;
  glow?: boolean;
}) {
  return (
    <div className={cn("glass rounded-3xl", glow && "edge-glow", className)}>
      {children}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Badge                                                             */
/* ---------------------------------------------------------------- */
const TONES: Record<string, string> = {
  green: "text-emerald-300 bg-emerald-400/10 border-emerald-400/20",
  amber: "text-amber-300 bg-amber-400/10 border-amber-400/20",
  red: "text-red-300 bg-red-400/10 border-red-400/20",
  violet: "text-[#ffe082] bg-[#d4a800]/12 border-[#d4a800]/30",
  sky: "text-sky-300 bg-sky-400/10 border-sky-400/20",
  zinc: "text-slate-400 bg-white/5 border-white/10",
  orange: "text-orange-300 bg-orange-400/10 border-orange-400/25",
};

export function Badge({
  tone = "zinc",
  children,
  pulse,
  className,
}: {
  tone?: keyof typeof TONES;
  children: React.ReactNode;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-[11px] font-medium whitespace-nowrap",
        TONES[tone],
        pulse && "animate-pulse-soft",
        className
      )}
    >
      {children}
    </span>
  );
}

/* ---------------------------------------------------------------- */
/* Modal                                                             */
/* ---------------------------------------------------------------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  children: React.ReactNode;
  wide?: boolean;
}) {
  const { t } = useI18n();
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center p-3 sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ y: 40, opacity: 0, scale: 0.97 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: 30, opacity: 0, scale: 0.97 }}
            transition={{ type: "spring", damping: 26, stiffness: 320 }}
            className={cn(
              "relative glass-deep edge-glow rounded-3xl w-full p-6 max-h-[88vh] overflow-y-auto",
              wide ? "max-w-2xl" : "max-w-md"
            )}
          >
            <div className="flex items-center justify-between mb-4 gap-4">
              <div className="font-bold text-base">{title}</div>
              <button
                onClick={onClose}
                aria-label={t("c.close")}
                className="p-1.5 rounded-xl hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
              >
                <X size={17} />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ---------------------------------------------------------------- */
/* Field                                                             */
/* ---------------------------------------------------------------- */
export function Field({
  label,
  hint,
  children,
  className,
}: {
  label: React.ReactNode;
  hint?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <label className={cn("block", className)}>
      <span className="block text-xs font-medium text-slate-400 mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-[11px] text-slate-500 mt-1">{hint}</span>}
    </label>
  );
}

/* ---------------------------------------------------------------- */
/* CopyButton                                                        */
/* ---------------------------------------------------------------- */
export function CopyBtn({
  text,
  className,
  label,
}: {
  text: string;
  className?: string;
  label?: string;
}) {
  const [ok, setOk] = useState(false);
  const { t } = useI18n();
  return (
    <button
      type="button"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
        } catch {
          const ta = document.createElement("textarea");
          ta.value = text;
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          ta.remove();
        }
        setOk(true);
        setTimeout(() => setOk(false), 1600);
      }}
      className={cn(
        "inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs transition-all",
        ok
          ? "border-emerald-400/40 text-emerald-300 bg-emerald-400/10"
          : "border-white/12 text-slate-300 hover:bg-white/8",
        className
      )}
    >
      {ok ? <Check size={13} /> : <Copy size={13} />}
      {ok ? t("c.copied") : label ?? t("c.copy")}
    </button>
  );
}

/* ---------------------------------------------------------------- */
/* CountUp                                                           */
/* ---------------------------------------------------------------- */
export function CountUp({
  value,
  format,
  className,
}: {
  value: number;
  format?: (n: number) => string;
  className?: string;
}) {
  const mv = useMotionValue(0);
  const [out, setOut] = useState("0");
  useEffect(() => {
    const controls = animate(mv, value, { duration: 1.2, ease: [0.22, 1, 0.36, 1] });
    const unsub = mv.on("change", (v) =>
      setOut(format ? format(v) : String(Math.round(v)))
    );
    return () => {
      controls.stop();
      unsub();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return <span className={className}>{out}</span>;
}

/* ---------------------------------------------------------------- */
/* Progress bar                                                      */
/* ---------------------------------------------------------------- */
export function UsageBar({ used, total }: { used: number; total: number }) {
  const pct = total > 0 ? Math.min(100, (used / total) * 100) : 0;
  const tone =
    pct >= 90
      ? "from-red-500 to-orange-400"
      : pct >= 70
        ? "from-amber-400 to-yellow-300"
        : "from-[#d4a800] to-[#38e1d4]";
  return (
    <div className="h-1.5 w-full rounded-full bg-white/8 overflow-hidden">
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: `${pct}%` }}
        transition={{ duration: 0.9, ease: "easeOut" }}
        className={cn("h-full rounded-full bg-gradient-to-l", tone)}
      />
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Section title                                                     */
/* ---------------------------------------------------------------- */
export function PageTitle({
  title,
  sub,
  children,
}: {
  title: string;
  sub?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-3 mb-6">
      <div>
        <h1 className="text-xl sm:text-2xl font-black tracking-tight">{title}</h1>
        {sub && <p className="text-sm text-slate-400 mt-1">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Empty state                                                       */
/* ---------------------------------------------------------------- */
export function Empty({
  icon,
  title,
  sub,
  children,
}: {
  icon?: React.ReactNode;
  title: string;
  sub?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-14 text-center">
      <div className="w-14 h-14 rounded-3xl glass flex items-center justify-center text-[#d4a800] mb-4">
        {icon}
      </div>
      <div className="font-bold">{title}</div>
      {sub && <p className="text-sm text-slate-400 mt-1 max-w-xs">{sub}</p>}
      {children && <div className="mt-4">{children}</div>}
    </div>
  );
}

/* ---------------------------------------------------------------- */
/* Toggle                                                            */
/* ---------------------------------------------------------------- */
export function Toggle({
  on,
  onChange,
  disabled,
}: {
  on: boolean;
  onChange: (v: boolean) => void;
  disabled?: boolean;
}) {
  return (
    <span
      role="switch"
      aria-checked={on}
      className={cn("switch", disabled && "opacity-40 pointer-events-none")}
      data-on={on}
      onClick={() => onChange(!on)}
    />
  );
}
