"use client";

import React, { useState, useTransition } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import {
  Boxes,
  Headset,
  LifeBuoy,
  LayoutDashboard,
  Link2,
  LogOut,
  Megaphone,
  Menu,
  Network,
  ReceiptText,
  Server,
  Settings2,
  ShieldCheck,
  ShieldPlus,
  UserCog,
  Users,
  UsersRound,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { LangSwitch } from "./lang-switch";
import { logoutAction } from "@/lib/actions/auth";
import { cn } from "@/lib/utils";

type ShellUser = {
  username: string;
  shopName: string;
  balance: number;
  role: "admin" | "reseller";
};

type Item = {
  href: string;
  key: string;
  icon: React.ReactNode;
  exact?: boolean;
  badge?: number;
};

export function Shell({
  user,
  announcement,
  badges,
  children,
}: {
  user: ShellUser;
  announcement: string;
  badges: { payments: number; tickets: number };
  children: React.ReactNode;
}) {
  const { t, fmtToman, fmtNum } = useI18n();
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [, start] = useTransition();

  /* detect devices: small phones get compact spacing, tablets get tighter sidebar-free layout */
  const [compact, setCompact] = useState(false);
  React.useEffect(() => {
    const mq = window.matchMedia("(max-width: 399px)");
    const apply = () => setCompact(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  const isAdmin = user.role === "admin";

  const mainItems: Item[] = [
    { href: "/dashboard", key: "nav.overview", icon: <LayoutDashboard size={17} />, exact: true },
    { href: "/dashboard/services", key: "nav.services", icon: <Server size={17} /> },
    { href: "/dashboard/users", key: "nav.myUsers", icon: <Users size={17} /> },
    { href: "/dashboard/wallet", key: "nav.wallet", icon: <Wallet size={17} /> },
    { href: "/dashboard/branding", key: "nav.branding", icon: <Link2 size={17} /> },
    { href: "/dashboard/tickets", key: "nav.tickets", icon: <LifeBuoy size={17} /> },
    { href: "/dashboard/profile", key: "nav.profile", icon: <UserCog size={17} /> },
  ];

  const adminItems: Item[] = [
    { href: "/dashboard/admin", key: "nav.admin", icon: <ShieldCheck size={17} />, exact: true },
    { href: "/dashboard/admin/panels", key: "nav.adminPanels", icon: <Network size={17} /> },
    { href: "/dashboard/admin/inbounds", key: "nav.adminInbounds", icon: <Boxes size={17} /> },
    { href: "/dashboard/admin/users", key: "nav.adminUsers", icon: <UsersRound size={17} /> },
    { href: "/dashboard/admin/payments", key: "nav.adminPayments", icon: <ReceiptText size={17} />, badge: badges.payments },
    { href: "/dashboard/admin/tickets", key: "nav.adminTickets", icon: <Headset size={17} />, badge: badges.tickets },
    { href: "/dashboard/admin/admins", key: "nav.adminAdmins", icon: <ShieldPlus size={17} /> },
    { href: "/dashboard/admin/settings", key: "nav.adminSettings", icon: <Settings2 size={17} /> },
  ];

  const isActive = (it: Item) =>
    it.exact ? pathname === it.href : pathname.startsWith(it.href);

  const NavItem = ({ it }: { it: Item }) => {
    const active = isActive(it);
    return (
      <Link
        href={it.href}
        onClick={() => setOpen(false)}
        className={cn(
          "relative flex items-center gap-3 rounded-2xl px-3.5 py-2.5 text-[13.5px] transition-all duration-200",
          active
            ? "text-white"
            : "text-slate-400 hover:text-white hover:bg-white/[.05]"
        )}
      >
        {active && (
          <motion.span
            layoutId="nav-pill"
            className="absolute inset-0 rounded-2xl bg-gradient-to-l from-[#d4a800]/85 to-[#e8b800]/70 shadow-[0_8px_24px_-8px_rgba(212,168,0,.8)]"
            transition={{ type: "spring", damping: 28, stiffness: 320 }}
          />
        )}
        <span className="relative z-10">{it.icon}</span>
        <span className="relative z-10 font-medium flex-1">{t(it.key)}</span>
        {!!it.badge && it.badge > 0 && (
          <span className="relative z-10 min-w-5 h-5 px-1 rounded-full bg-[#ffd166] text-[#3d2f00] text-[10px] font-black flex items-center justify-center animate-pulse-soft">
            {fmtNum(it.badge)}
          </span>
        )}
      </Link>
    );
  };

  const sidebar = (
    <div className="flex flex-col h-full">
      <Link href="/" className="flex items-center gap-2.5 px-2 py-1" onClick={() => setOpen(false)}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src="/images/logo-sm.png" alt="هکتور" width={36} height={36} className="rounded-xl" />
        <span className="font-black text-lg text-grad">{t("brand.name")}</span>
        <span className="text-[10px] text-slate-500 border border-white/10 rounded-lg px-1.5 py-0.5">
          {isAdmin ? t("shell.adminPanel") : t("shell.panel")}
        </span>
      </Link>

      <nav className="mt-7 space-y-1 flex-1 overflow-y-auto pb-2 pe-1">
        {mainItems.map((it) => (
          <NavItem key={it.href} it={it} />
        ))}
        {isAdmin && (
          <>
            <div className="px-3 pt-5 pb-1.5 text-[10px] font-bold uppercase tracking-[.18em] text-slate-500">
              {t("nav.admin")}
            </div>
            {adminItems.map((it) => (
              <NavItem key={it.href} it={it} />
            ))}
          </>
        )}
      </nav>

      <div className="glass rounded-2xl p-3.5 flex items-center gap-3">
        <span className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#f472b6]/60 to-[#d4a800]/60 border border-white/15 flex items-center justify-center font-black text-sm">
          {(user.shopName || user.username).slice(0, 1).toUpperCase()}
        </span>
        <div className="min-w-0 flex-1">
          <div className="text-[13px] font-bold truncate">{user.shopName || user.username}</div>
          <div className="text-[10.5px] text-slate-500 truncate" dir="ltr">@{user.username}</div>
        </div>
        <button
          onClick={() =>
            start(async () => {
              await logoutAction();
              router.refresh();
            })
          }
          title={t("nav.logout")}
          className="p-2 rounded-xl text-slate-400 hover:text-red-300 hover:bg-red-400/10 transition-colors"
        >
          <LogOut size={15} />
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen relative">
      <div className="absolute inset-0 bg-grid pointer-events-none" />
      <div className="orb w-[420px] h-[420px] bg-[#d4a800]/12 -top-32 end-[10%] pointer-events-none" />

      {/* desktop sidebar */}
      <aside className="hidden lg:block fixed top-0 bottom-0 start-0 w-72 z-40 p-4">
        <div className="glass-deep rounded-[26px] h-full p-4 edge-glow">{sidebar}</div>
      </aside>

      {/* mobile drawer */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[90] lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ x: 320 }}
              animate={{ x: 0 }}
              exit={{ x: 320 }}
              transition={{ type: "spring", damping: 30, stiffness: 300 }}
              className="absolute top-0 bottom-0 end-0 w-80 max-w-[85vw] bg-[#0e1428] border-s border-white/10 p-4"
            >
              <div className="flex justify-end mb-2">
                <button onClick={() => setOpen(false)} className="p-2 rounded-xl hover:bg-white/10 text-slate-400">
                  <X size={17} />
                </button>
              </div>
              {sidebar}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* main column */}
      <div className="relative z-10 lg:ps-72">
        {/* topbar */}
        <header className={cn("sticky top-0 z-30 pt-4", compact ? "px-2.5" : "px-4 sm:px-6")}>
          <div className="glass rounded-2xl px-4 py-2.5 flex items-center gap-3">
            <button
              onClick={() => setOpen(true)}
              className="lg:hidden p-2 rounded-xl hover:bg-white/10 text-slate-300"
            >
              <Menu size={18} />
            </button>
            <div className="flex-1" />
            <Link
              href="/dashboard/wallet"
              className="inline-flex items-center gap-2 rounded-xl border border-[#38e1d4]/25 bg-[#38e1d4]/8 px-3 py-1.5 text-xs font-bold text-[#f5c518] hover:bg-[#38e1d4]/15 transition-colors"
            >
              <Wallet size={13} />
              {fmtToman(user.balance)}
            </Link>
            <LangSwitch />
          </div>
        </header>

        {announcement && (
          <div className={cn("mt-4", compact ? "px-2.5" : "px-4 sm:px-6")}>
            <div className="glass rounded-2xl px-4 py-3 flex items-start gap-3 border-[#f0b429]/30 bg-[#f0b429]/[.06]">
              <Megaphone size={16} className="text-[#ffd166] shrink-0 mt-0.5" />
              <div>
                <div className="text-[11px] font-bold text-[#ffd166]">{t("dash.announce")}</div>
                <div className="text-[13px] text-slate-200 mt-0.5 leading-6">{announcement}</div>
              </div>
            </div>
          </div>
        )}

        <main className={cn("py-6 pb-20 max-w-[1400px]", compact ? "px-2.5" : "px-4 sm:px-6")}>
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
          >
            {children}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
