"use client";

import React, { useState, useTransition } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  AtSign,
  KeyRound,
  Mail,
  ShieldCheck,
  Store,
  User as UserIcon,
} from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { useToast } from "@/components/toast";
import { LangSwitch } from "@/components/lang-switch";
import { Btn, Field } from "@/components/ui";
import {
  loginAction,
  registerAction,
  sendRegisterOtp,
  sendLoginOtp,
  verifyLoginOtp,
  sendResetOtp,
  resetPassword,
} from "@/lib/actions/auth";
import { cn } from "@/lib/utils";

function Shell({ children }: { children: React.ReactNode }) {
  const { t, fa } = useI18n();
  const Back = fa ? ArrowRight : ArrowLeft;
  return (
    <div className="min-h-screen relative overflow-clip flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-grid" />
      <div className="orb w-[480px] h-[480px] bg-[#d4a800]/15 -top-32 start-[-120px]" />
      <div className="orb w-[420px] h-[420px] bg-[#f5c518]/8 bottom-[-120px] end-[-100px]" />

      <div className="fixed top-0 inset-x-0 z-50 px-4 sm:px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5">
          <Image src="/images/logo-sm.png" alt="هکتور" width={36} height={36} className="rounded-xl" />
          <span className="font-black text-lg text-grad">{t("brand.name")}</span>
        </Link>
        <div className="flex items-center gap-3">
          <Link href="/" className="hidden sm:inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors">
            <Back size={13} /> {t("c.back")}
          </Link>
          <LangSwitch />
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 w-full max-w-md"
      >
        {children}
      </motion.div>
    </div>
  );
}

/* ===================== LOGIN ===================== */
export function LoginForm() {
  const { t } = useI18n();
  const { push } = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [form, setForm] = useState({ username: "", password: "" });
  const [err, setErr] = useState("");
  const [mode, setMode] = useState<"login" | "email" | "emailCode" | "reset" | "resetCode">("login");
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const [newPass, setNewPass] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    start(async () => {
      const r = await loginAction(form);
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      push("ok", t("land.open"));
      router.refresh();
      router.push("/dashboard");
    });
  };

  const sendQuickCode = () => {
    setErr(""); setDevCode("");
    start(async () => {
      const r = await sendLoginOtp(email);
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      if (r.devCode) setDevCode(r.devCode);
      push("ok", t("auth.codeSent"));
      setMode("emailCode");
    });
  };

  const verifyQuickCode = () => {
    setErr("");
    start(async () => {
      const r = await verifyLoginOtp({ email, code });
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      push("ok", t("land.open"));
      router.refresh();
      router.push("/dashboard");
    });
  };

  const sendReset = () => {
    setErr(""); setDevCode("");
    start(async () => {
      const r = await sendResetOtp(email);
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      if (r.devCode) setDevCode(r.devCode);
      push("ok", t("auth.codeSent"));
      setMode("resetCode");
    });
  };

  const doReset = () => {
    setErr("");
    start(async () => {
      const r = await resetPassword({ email, code, newPassword: newPass });
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      push("ok", t("auth.resetOk"));
      setMode("login");
    });
  };

  const ErrBox = () =>
    err ? (
      <div className="text-xs text-red-300 bg-red-400/10 border border-red-400/20 rounded-xl px-3.5 py-2.5">{err}</div>
    ) : devCode ? (
      <div className="text-xs text-amber-200 bg-amber-400/10 border border-amber-400/20 rounded-xl px-3.5 py-2.5 font-mono text-center">
        {t("auth.devCodeHint")}: <b className="text-lg tracking-[6px]">{devCode}</b>
      </div>
    ) : null;

  return (
    <Shell>
      <div className="glass-deep edge-glow rounded-[28px] p-7 sm:p-8">
        <div className="flex justify-center mb-5">
          <Image src="/images/logo.png" alt="هکتور" width={80} height={80} className="rounded-2xl" />
        </div>

        {mode === "login" && (
          <>
            <h1 className="text-2xl font-black text-center">{t("auth.loginTitle")}</h1>
            <p className="text-sm text-slate-400 mt-1.5 text-center">{t("auth.loginSub")}</p>

            <form onSubmit={submit} className="mt-6 space-y-4">
              <Field label={t("auth.username")}>
                <div className="relative">
                  <UserIcon size={15} className="absolute top-1/2 -translate-y-1/2 start-3.5 text-slate-500" />
                  <input className="field ps-10" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} autoComplete="username" dir="ltr" placeholder="username" required />
                </div>
              </Field>
              <Field label={t("auth.password")}>
                <div className="relative">
                  <KeyRound size={15} className="absolute top-1/2 -translate-y-1/2 start-3.5 text-slate-500" />
                  <input className="field ps-10" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} autoComplete="current-password" dir="ltr" placeholder="••••••••" required />
                </div>
              </Field>
              <ErrBox />
              <Btn loading={pending} className="w-full" size="lg">{t("auth.loginBtn")}</Btn>
            </form>

            <div className="mt-4 text-center">
              <button onClick={() => { setMode("reset"); setErr(""); setDevCode(""); }} className="text-xs text-[#f5c518] hover:text-white transition-colors">
                {t("auth.forgotPass")}
              </button>
            </div>

            <div className="mt-5 pt-5 border-t border-white/8">
              <button
                onClick={() => { setMode("email"); setErr(""); setDevCode(""); }}
                className="w-full glass rounded-2xl p-4 flex items-center gap-3 hover:bg-white/[.05] transition-colors group"
              >
                <span className="w-10 h-10 rounded-xl bg-[#d4a800]/15 border border-[#d4a800]/30 flex items-center justify-center text-[#f5c518] group-hover:scale-110 transition-transform">
                  <Mail size={18} />
                </span>
                <div className="text-start">
                  <div className="text-[13px] font-bold">{t("auth.quickLogin")}</div>
                  <div className="text-[10.5px] text-slate-500">{t("auth.quickLoginSub")}</div>
                </div>
              </button>
            </div>

            <Link href="/register" className="mt-5 block text-center text-xs text-slate-400 hover:text-white transition-colors">
              {t("auth.noAccount")}
            </Link>
          </>
        )}

        {mode === "email" && (
          <>
            <h1 className="text-xl font-black text-center">{t("auth.quickLogin")}</h1>
            <p className="text-sm text-slate-400 mt-1.5 text-center">{t("auth.quickLoginSub")}</p>
            <div className="mt-6 space-y-4">
              <Field label={t("auth.email")}>
                <input className="field font-mono" dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("auth.emailPh")} />
              </Field>
              <ErrBox />
              <Btn loading={pending} className="w-full" size="lg" onClick={sendQuickCode} disabled={!email.includes("@")}>
                <Mail size={15} /> {t("auth.sendCode")}
              </Btn>
              <button onClick={() => setMode("login")} className="w-full text-center text-xs text-slate-400 hover:text-white">{t("c.back")}</button>
            </div>
          </>
        )}

        {mode === "emailCode" && (
          <>
            <h1 className="text-xl font-black text-center">{t("auth.quickLogin")}</h1>
            <p className="text-sm text-[#f5c518] mt-1.5 text-center">{t("auth.codeSent")}</p>
            <div className="mt-6 space-y-4">
              <Field label={t("auth.code")}>
                <input className="field font-mono text-center text-xl tracking-[8px]" dir="ltr" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} placeholder="••••••" autoFocus />
              </Field>
              <ErrBox />
              <Btn loading={pending} className="w-full" size="lg" onClick={verifyQuickCode} disabled={code.length < 6}>
                <ShieldCheck size={15} /> {t("auth.loginBtn")}
              </Btn>
              <button onClick={() => { setMode("email"); setCode(""); setErr(""); setDevCode(""); }} className="w-full text-center text-xs text-slate-400 hover:text-white">{t("c.back")}</button>
            </div>
          </>
        )}

        {mode === "reset" && (
          <>
            <h1 className="text-xl font-black text-center">{t("auth.resetTitle")}</h1>
            <p className="text-sm text-slate-400 mt-1.5 text-center">{t("auth.resetSub")}</p>
            <div className="mt-6 space-y-4">
              <Field label={t("auth.email")}>
                <input className="field font-mono" dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("auth.emailPh")} />
              </Field>
              <ErrBox />
              <Btn loading={pending} className="w-full" size="lg" onClick={sendReset} disabled={!email.includes("@")}>
                <Mail size={15} /> {t("auth.sendCode")}
              </Btn>
              <button onClick={() => setMode("login")} className="w-full text-center text-xs text-slate-400 hover:text-white">{t("c.back")}</button>
            </div>
          </>
        )}

        {mode === "resetCode" && (
          <>
            <h1 className="text-xl font-black text-center">{t("auth.resetTitle")}</h1>
            <p className="text-sm text-[#f5c518] mt-1.5 text-center">{t("auth.codeSent")}</p>
            <div className="mt-6 space-y-4">
              <Field label={t("auth.code")}>
                <input className="field font-mono text-center text-xl tracking-[8px]" dir="ltr" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} placeholder="••••••" autoFocus />
              </Field>
              <Field label={t("auth.newPass")}>
                <input className="field" dir="ltr" type="password" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="••••••••" autoComplete="new-password" />
              </Field>
              <ErrBox />
              <Btn loading={pending} className="w-full" size="lg" onClick={doReset} disabled={code.length < 6 || newPass.length < 6}>
                <KeyRound size={15} /> {t("auth.resetBtn")}
              </Btn>
              <button onClick={() => { setMode("reset"); setCode(""); setErr(""); setDevCode(""); }} className="w-full text-center text-xs text-slate-400 hover:text-white">{t("c.back")}</button>
            </div>
          </>
        )}
      </div>
    </Shell>
  );
}

/* ===================== REGISTER ===================== */
export function RegisterForm() {
  const { t, fa } = useI18n();
  const { push } = useToast();
  const router = useRouter();
  const [pending, start] = useTransition();
  const [step, setStep] = useState<1 | 2>(1);
  const [email, setEmail] = useState("");
  const [code, setCode] = useState("");
  const [devCode, setDevCode] = useState("");
  const [form, setForm] = useState({ username: "", password: "", shopName: "", telegram: "" });
  const [err, setErr] = useState("");

  const sendCode = () => {
    setErr(""); setDevCode("");
    start(async () => {
      const r = await sendRegisterOtp(email);
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      if (r.devCode) setDevCode(r.devCode);
      push("ok", t("auth.codeSent"));
      setStep(2);
    });
  };

  const submitReg = (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    start(async () => {
      const r = await registerAction({ ...form, email, code });
      if (!r.ok) { setErr(t(r.error ?? "err.generic")); return; }
      push("ok", t("auth.registerTitle"));
      router.refresh();
      router.push("/dashboard");
    });
  };

  const icon = (node: React.ReactNode) => (
    <span className="absolute top-1/2 -translate-y-1/2 start-3.5 text-slate-500">{node}</span>
  );

  const ErrBox = () =>
    err ? (
      <div className="text-xs text-red-300 bg-red-400/10 border border-red-400/20 rounded-xl px-3.5 py-2.5">{err}</div>
    ) : devCode ? (
      <div className="text-xs text-amber-200 bg-amber-400/10 border border-amber-400/20 rounded-xl px-3.5 py-2.5 font-mono text-center">
        {t("auth.devCodeHint")}: <b className="text-lg tracking-[6px]">{devCode}</b>
      </div>
    ) : null;

  return (
    <Shell>
      <div className="glass-deep edge-glow rounded-[28px] p-7 sm:p-8">
        <div className="flex justify-center mb-5">
          <Image src="/images/logo.png" alt="هکتور" width={80} height={80} className="rounded-2xl" />
        </div>
        <h1 className="text-2xl font-black text-center">{t("auth.registerTitle")}</h1>
        <p className="text-sm text-slate-400 mt-1.5 text-center">{t("auth.registerSub")}</p>

        {step === 1 && (
          <div className="mt-6 space-y-4">
            <Field label={`${t("auth.email")} *`}>
              <div className="relative">
                {icon(<Mail size={15} />)}
                <input className="field ps-10 font-mono" dir="ltr" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder={t("auth.emailPh")} required />
              </div>
            </Field>
            <ErrBox />
            <Btn loading={pending} className="w-full" size="lg" onClick={sendCode} disabled={!email.includes("@")}>
              <Mail size={15} /> {t("auth.sendCode")}
            </Btn>
            <Link href="/login" className="block text-center text-xs text-slate-400 hover:text-white transition-colors">
              {t("auth.haveAccount")}
            </Link>
          </div>
        )}

        {step === 2 && (
          <form onSubmit={submitReg} className="mt-6 space-y-4">
            <Field label={t("auth.code")}>
              <input className="field font-mono text-center text-xl tracking-[8px]" dir="ltr" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} placeholder="••••••" autoFocus />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label={t("auth.username")}>
                <div className="relative">{icon(<UserIcon size={15} />)}
                  <input className="field ps-10" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} dir="ltr" placeholder="username" required />
                </div>
              </Field>
              <Field label={t("auth.password")}>
                <div className="relative">{icon(<KeyRound size={15} />)}
                  <input className="field ps-10" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} dir="ltr" placeholder="••••••" required />
                </div>
              </Field>
            </div>
            <Field label={t("auth.shopName")}>
              <div className="relative">{icon(<Store size={15} />)}
                <input className="field ps-10" value={form.shopName} onChange={(e) => setForm({ ...form, shopName: e.target.value })} placeholder={t("br.shopPh")} />
              </div>
            </Field>
            <Field label={`${t("auth.telegram")} (${t("c.optional")})`}>
              <div className="relative">{icon(<AtSign size={15} />)}
                <input className="field ps-10" value={form.telegram} onChange={(e) => setForm({ ...form, telegram: e.target.value })} dir="ltr" placeholder="@username" />
              </div>
            </Field>
            <ErrBox />
            <Btn loading={pending} className="w-full" size="lg" disabled={code.length < 6}>
              {t("auth.registerBtn")}
            </Btn>
            <button type="button" onClick={() => setStep(1)} className="w-full text-center text-xs text-slate-400 hover:text-white">
              {t("c.back")}
            </button>
          </form>
        )}
      </div>
    </Shell>
  );
}
