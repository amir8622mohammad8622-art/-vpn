import { redirect } from "next/navigation";
import { getSession } from "@/lib/auth";
import { RegisterForm } from "@/components/auth-forms";

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  const s = await getSession();
  if (s) redirect("/dashboard");
  return <RegisterForm />;
}
