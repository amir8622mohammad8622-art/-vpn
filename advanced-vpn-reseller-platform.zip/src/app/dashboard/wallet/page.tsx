import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { paymentRequests, transactions, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getSiteSettings } from "@/lib/settings";
import { WalletView } from "@/components/views/wallet";

export const dynamic = "force-dynamic";

export default async function WalletPage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));
  const st = await getSiteSettings();

  const reqs = await db
    .select()
    .from(paymentRequests)
    .where(eq(paymentRequests.userId, s.uid))
    .orderBy(desc(paymentRequests.createdAt))
    .limit(8);

  const txs = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, s.uid))
    .orderBy(desc(transactions.createdAt))
    .limit(40);

  return (
    <WalletView
      balance={user.balance}
      settings={{
        cardNumber: st.card_number,
        cardHolder: st.card_holder,
        minCharge: Number(st.min_charge) || 50000,
      }}
      requests={reqs.map((r) => ({
        id: r.id,
        amount: r.amount,
        status: r.status,
        adminNote: r.adminNote,
        receiptPath: r.receiptPath,
        createdAt: r.createdAt.toISOString(),
      }))}
      txs={txs.map((x) => ({
        id: x.id,
        type: x.type,
        amount: x.amount,
        status: x.status,
        description: x.description,
        createdAt: x.createdAt.toISOString(),
      }))}
    />
  );
}
