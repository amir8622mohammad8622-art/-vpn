import { eq, sql } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { paymentRequests, tickets, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getSiteSettings } from "@/lib/settings";
import { Shell } from "@/components/shell";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));
  if (!user) redirect("/login");

  const st = await getSiteSettings();

  let badges = { payments: 0, tickets: 0 };
  if (user.role === "admin") {
    try {
      const [pay] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(paymentRequests)
        .where(eq(paymentRequests.status, "pending"));
      const [tks] = await db
        .select({ n: sql<number>`count(*)::int` })
        .from(tickets)
        .where(eq(tickets.status, "open"));
      badges = { payments: pay.n, tickets: tks.n };
    } catch {
      /* pre-migration */
    }
  }

  return (
    <Shell
      user={{
        username: user.username,
        shopName: user.shopName,
        balance: user.balance,
        role: user.role as "admin" | "reseller",
      }}
      badges={badges}
      announcement={user.role === "admin" ? "" : user.status === "banned" ? "" : st.announcement}
    >
      {children}
    </Shell>
  );
}
