export default function DashboardLoading() {
  return (
    <div className="animate-pulse">
      <div className="h-8 w-56 rounded-2xl bg-white/[.06]" />
      <div className="mt-2 h-4 w-80 max-w-full rounded-xl bg-white/[.04]" />
      <div className="mt-7 grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="glass rounded-3xl p-5 h-32">
            <div className="w-8 h-8 rounded-xl bg-white/[.07]" />
            <div className="mt-4 h-5 w-24 rounded-lg bg-white/[.06]" />
            <div className="mt-3 h-3 w-16 rounded-lg bg-white/[.04]" />
          </div>
        ))}
      </div>
      <div className="mt-4 grid lg:grid-cols-2 gap-4">
        <div className="glass rounded-3xl h-56" />
        <div className="glass rounded-3xl h-56" />
      </div>
    </div>
  );
}
