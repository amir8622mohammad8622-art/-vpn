import { requireAdmin } from "@/lib/auth";
import { getSiteSettings } from "@/lib/settings";
import { AdminSettingsView } from "@/components/views/admin-settings";

export const dynamic = "force-dynamic";

export default async function AdminSettingsPage() {
  await requireAdmin();
  const st = await getSiteSettings();
  return <AdminSettingsView initial={st} />;
}
