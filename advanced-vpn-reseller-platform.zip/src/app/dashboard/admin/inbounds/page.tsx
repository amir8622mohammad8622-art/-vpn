import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { inbounds, panels } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminInboundsView } from "@/components/views/admin-inbounds";

export const dynamic = "force-dynamic";

export default async function AdminInboundsPage() {
  await requireAdmin();

  const rows = await db
    .select({ ib: inbounds, panel: panels })
    .from(inbounds)
    .innerJoin(panels, eq(inbounds.panelId, panels.id))
    .orderBy(asc(inbounds.id));

  return (
    <AdminInboundsView
      rows={rows.map((r) => ({
        id: r.ib.id,
        remark: r.ib.remark,
        protocol: r.ib.protocol,
        port: r.ib.port,
        network: r.ib.network,
        security: r.ib.security,
        pricePerGb: r.ib.pricePerGb,
        pricePerMonth: r.ib.pricePerMonth,
        enabled: r.ib.enabled,
        totalClients: r.ib.totalClients,
        panelName: r.panel.name,
        location: r.panel.location,
      }))}
    />
  );
}
