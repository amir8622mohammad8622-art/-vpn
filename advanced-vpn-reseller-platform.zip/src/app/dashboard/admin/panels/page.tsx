import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { inbounds, panels } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { PanelsView } from "@/components/views/admin-panels";

export const dynamic = "force-dynamic";

export default async function AdminPanelsPage() {
  await requireAdmin();

  const rows = await db.select().from(panels).orderBy(asc(panels.id));
  const counts = await db
    .select({ panelId: inbounds.panelId, n: sql<number>`count(*)::int` })
    .from(inbounds)
    .groupBy(inbounds.panelId);
  const countMap = new Map(counts.map((c) => [c.panelId, c.n]));

  return (
    <PanelsView
      panels={rows.map((p) => ({
        id: p.id,
        name: p.name,
        type: p.type,
        baseUrl: p.baseUrl,
        subHost: p.subHost,
        location: p.location,
        status: p.status,
        hidden: p.hidden,
        apiUsername: p.apiUsername,
        lastSyncAt: p.lastSyncAt ? p.lastSyncAt.toISOString() : null,
        inboundCount: countMap.get(p.id) ?? 0,
      }))}
    />
  );
}
