import { asc, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { ticketMessages, tickets, users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminTicketsView, type AdminTicketRow } from "@/components/views/admin-tickets";

export const dynamic = "force-dynamic";

export default async function AdminTicketsPage() {
  await requireAdmin();

  const list = await db
    .select({ tk: tickets, user: users })
    .from(tickets)
    .innerJoin(users, eq(tickets.userId, users.id))
    .orderBy(desc(tickets.updatedAt))
    .limit(100);

  const ids = list.map((l) => l.tk.id);
  const msgs = ids.length
    ? await db
        .select()
        .from(ticketMessages)
        .where(inArray(ticketMessages.ticketId, ids))
        .orderBy(asc(ticketMessages.createdAt))
    : [];

  const data: AdminTicketRow[] = list.map(({ tk, user }) => ({
    id: tk.id,
    subject: tk.subject,
    status: tk.status,
    username: user.username,
    shopName: user.shopName,
    createdAt: tk.createdAt.toISOString(),
    messages: msgs
      .filter((m) => m.ticketId === tk.id)
      .map((m) => ({
        id: m.id,
        mine: m.senderId !== user.id,
        body: m.body,
        createdAt: m.createdAt.toISOString(),
      })),
  }));

  return <AdminTicketsView tickets={data} />;
}
