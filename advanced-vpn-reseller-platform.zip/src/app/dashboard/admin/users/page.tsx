import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users, vpnUsers } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminUsersView } from "@/components/views/admin-users";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  await requireAdmin();

  const rows = await db
    .select({
      u: users,
      vpnCount: sql<number>`(select count(*) from ${vpnUsers} where ${vpnUsers.ownerId} = ${users.id})::int`,
    })
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(200);

  return (
    <AdminUsersView
      rows={rows.map(({ u, vpnCount }) => ({
        id: u.id,
        username: u.username,
        shopName: u.shopName,
        telegram: u.telegram,
        balance: u.balance,
        totalSpent: u.totalSpent,
        status: u.status,
        role: u.role,
        vpnCount,
        createdAt: u.createdAt.toISOString(),
        lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
      }))}
    />
  );
}
