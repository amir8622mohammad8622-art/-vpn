import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { panels, paymentRequests, transactions, users, vpnUsers } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminOverview } from "@/components/views/admin-overview";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  await requireAdmin();

  const [resellerCount] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(users)
    .where(eq(users.role, "reseller"));

  const [vpnCount] = await db
    .select({ n: sql<number>`count(*)::int`, a: sql<number>`count(*) filter (where ${vpnUsers.status} = 'active')::int` })
    .from(vpnUsers);

  const [rev] = await db
    .select({ s: sql<number>`coalesce(sum(${users.totalSpent}),0)::int` })
    .from(users);

  const [pend] = await db
    .select({
      n: sql<number>`count(*)::int`,
      s: sql<number>`coalesce(sum(${paymentRequests.amount}),0)::int`,
    })
    .from(paymentRequests)
    .where(eq(paymentRequests.status, "pending"));

  const panelRows = await db.select().from(panels);
  const online = panelRows.filter((p) => p.status === "online").length;

  const weekAgo = new Date(Date.now() - 7 * 86400000);
  const weeklyTx = await db
    .select({ amount: transactions.amount, createdAt: transactions.createdAt })
    .from(transactions)
    .where(and(eq(transactions.type, "purchase"), gt(transactions.createdAt, weekAgo)));

  const days: number[] = new Array(7).fill(0);
  for (const tx of weeklyTx) {
    const d = Math.floor((Date.now() - tx.createdAt.getTime()) / 86400000);
    if (d >= 0 && d < 7) days[6 - d] += Math.abs(tx.amount);
  }

  const latestPayments = await db
    .select({ pr: paymentRequests, username: users.username, shop: users.shopName })
    .from(paymentRequests)
    .innerJoin(users, eq(paymentRequests.userId, users.id))
    .orderBy(desc(paymentRequests.createdAt))
    .limit(5);

  const latestUsers = await db
    .select()
    .from(users)
    .where(eq(users.role, "reseller"))
    .orderBy(desc(users.createdAt))
    .limit(5);

  const [traffic] = await db
    .select({ s: sql<number>`coalesce(sum(${vpnUsers.dataLimitGb}),0)::float` })
    .from(vpnUsers);

  return (
    <AdminOverview
      stats={{
        resellers: resellerCount.n,
        vpnUsers: vpnCount.n,
        vpnActive: vpnCount.a,
        revenue: rev.s,
        pendingCount: pend.n,
        pendingSum: pend.s,
        panelsOnline: online,
        panelsTotal: panelRows.length,
        trafficSold: Math.round((traffic?.s ?? 0) * 10) / 10,
        weekly: days,
      }}
      latestPayments={latestPayments.map((p) => ({
        id: p.pr.id,
        username: p.username,
        shop: p.shop,
        amount: p.pr.amount,
        status: p.pr.status,
        createdAt: p.pr.createdAt.toISOString(),
      }))}
      latestUsers={latestUsers.map((u) => ({
        id: u.id,
        username: u.username,
        shopName: u.shopName,
        balance: u.balance,
        status: u.status,
        createdAt: u.createdAt.toISOString(),
      }))}
    />
  );
}
