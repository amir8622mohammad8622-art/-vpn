import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { paymentRequests, users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminPaymentsView } from "@/components/views/admin-payments";

export const dynamic = "force-dynamic";

export default async function AdminPaymentsPage() {
  await requireAdmin();

  const rows = await db
    .select({ pr: paymentRequests, user: users })
    .from(paymentRequests)
    .innerJoin(users, eq(paymentRequests.userId, users.id))
    .orderBy(sql`case when ${paymentRequests.status} = 'pending' then 0 else 1 end`, desc(paymentRequests.createdAt))
    .limit(80);

  return (
    <AdminPaymentsView
      rows={rows.map((r) => ({
        id: r.pr.id,
        username: r.user.username,
        shop: r.user.shopName,
        amount: r.pr.amount,
        status: r.pr.status,
        receiptPath: r.pr.receiptPath,
        adminNote: r.pr.adminNote,
        createdAt: r.pr.createdAt.toISOString(),
      }))}
    />
  );
}
