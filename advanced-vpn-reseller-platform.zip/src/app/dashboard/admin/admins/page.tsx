import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { AdminsView } from "@/components/views/admins";

export const dynamic = "force-dynamic";

export default async function AdminsPage() {
  const me = await requireAdmin();

  const rows = await db
    .select()
    .from(users)
    .where(eq(users.role, "admin"))
    .orderBy(asc(users.id));

  return (
    <AdminsView
      meId={me.uid}
      rows={rows.map((u) => ({
        id: u.id,
        username: u.username,
        shopName: u.shopName,
        telegram: u.telegram,
        createdAt: u.createdAt.toISOString(),
        lastSeenAt: u.lastSeenAt ? u.lastSeenAt.toISOString() : null,
      }))}
    />
  );
}
