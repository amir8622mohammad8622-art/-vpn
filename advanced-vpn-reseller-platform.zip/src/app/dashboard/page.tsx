import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { transactions, users, vpnUsers } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { DashOverview } from "@/components/views/dash-overview";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));

  const mine = await db
    .select()
    .from(vpnUsers)
    .where(eq(vpnUsers.ownerId, s.uid))
    .orderBy(desc(vpnUsers.createdAt))
    .limit(8);

  const txs = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, s.uid))
    .orderBy(desc(transactions.createdAt))
    .limit(6);

  const allCount = mine.length;
  const active = mine.filter((u) => u.status === "active").length;
  const used = mine.reduce((a, u) => a + u.usedGb, 0);
  const limit = mine.reduce((a, u) => a + u.dataLimitGb, 0);

  return (
    <DashOverview
      user={{
        shopName: user.shopName,
        username: user.username,
        balance: user.balance,
        totalSpent: user.totalSpent,
        subToken: user.subToken,
        status: user.status,
      }}
      stats={{ total: allCount, active, used, limit }}
      txs={txs.map((t) => ({
        id: t.id,
        type: t.type,
        amount: t.amount,
        status: t.status,
        description: t.description,
        createdAt: t.createdAt.toISOString(),
      }))}
      topUsers={mine.slice(0, 5).map((u) => ({
        id: u.id,
        label: u.label,
        usedGb: u.usedGb,
        dataLimitGb: u.dataLimitGb,
        status: u.status,
      }))}
    />
  );
}
