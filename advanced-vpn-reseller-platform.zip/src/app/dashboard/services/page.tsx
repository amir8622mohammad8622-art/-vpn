import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { inbounds, panels, users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { ServicesView, type ServiceInbound } from "@/components/views/services";

export const dynamic = "force-dynamic";

export default async function ServicesPage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));

  const rows = await db
    .select({ ib: inbounds, panel: panels })
    .from(inbounds)
    .innerJoin(panels, eq(inbounds.panelId, panels.id))
    .where(eq(inbounds.enabled, true))
    .orderBy(asc(inbounds.id));

  const list: ServiceInbound[] = rows
    .filter((r) => !r.panel.hidden)
    .map((r) => ({
      id: r.ib.id,
      remark: r.ib.remark,
      protocol: r.ib.protocol,
      port: r.ib.port,
      network: r.ib.network,
      security: r.ib.security,
      pricePerGb: r.ib.pricePerGb,
      pricePerMonth: r.ib.pricePerMonth,
      totalClients: r.ib.totalClients,
      panelName: r.panel.name,
      location: r.panel.location,
      panelStatus: r.panel.status,
    }));

  return <ServicesView inbounds={list} balance={user.balance} />;
}
