import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { ProfileView } from "@/components/views/profile";

export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));
  return (
    <ProfileView
      user={{
        username: user.username,
        shopName: user.shopName,
        telegram: user.telegram,
        balance: user.balance,
        totalSpent: user.totalSpent,
        role: user.role,
        createdAt: user.createdAt.toISOString(),
      }}
    />
  );
}
