import { eq } from "drizzle-orm";
import { headers } from "next/headers";
import QRCode from "qrcode";
import { db } from "@/db";
import { users, vpnUsers } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { BrandingView } from "@/components/views/branding";

export const dynamic = "force-dynamic";

export default async function BrandingPage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));

  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  const link = `${proto}://${host}/api/sub/${user.subToken}`;

  let qr = "";
  try {
    qr = await QRCode.toDataURL(link, { margin: 1, width: 240, color: { dark: "#111a33", light: "#ffffff" } });
  } catch {}

  const vus = await db.select().from(vpnUsers).where(eq(vpnUsers.ownerId, s.uid));
  const total = vus.reduce((a, u) => a + u.dataLimitGb, 0);
  const used = vus.reduce((a, u) => a + u.usedGb, 0);
  const nearest = vus
    .map((v) => v.expireAt.getTime())
    .filter((t) => t > Date.now())
    .sort((a, b) => a - b)[0];

  return (
    <BrandingView
      shopName={user.shopName}
      telegram={user.telegram}
      link={link}
      qr={qr}
      stats={{
        users: vus.length,
        usedGb: Math.round(used * 100) / 100,
        totalGb: total,
        expireAt: nearest ? new Date(nearest).toISOString() : null,
      }}
    />
  );
}
