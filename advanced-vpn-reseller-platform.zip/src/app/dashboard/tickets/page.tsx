import { asc, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { ticketMessages, tickets } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { getSiteSettings } from "@/lib/settings";
import { TicketsView, type TicketWithMsgs } from "@/components/views/tickets";

export const dynamic = "force-dynamic";

export default async function TicketsPage() {
  const s = await requireUser();
  const st = await getSiteSettings();

  const list = await db
    .select()
    .from(tickets)
    .where(eq(tickets.userId, s.uid))
    .orderBy(desc(tickets.updatedAt))
    .limit(60);

  const msgs = list.length
    ? await db
        .select()
        .from(ticketMessages)
        .where(inArray(ticketMessages.ticketId, list.map((t) => t.id)))
        .orderBy(asc(ticketMessages.createdAt))
    : [];

  const data: TicketWithMsgs[] = list.map((tk) => ({
    id: tk.id,
    subject: tk.subject,
    status: tk.status,
    createdAt: tk.createdAt.toISOString(),
    messages: msgs
      .filter((m) => m.ticketId === tk.id)
      .map((m) => ({
        id: m.id,
        mine: m.senderId === s.uid,
        body: m.body,
        createdAt: m.createdAt.toISOString(),
      })),
  }));

  return <TicketsView tickets={data} supportUser={st.support_user} />;
}
