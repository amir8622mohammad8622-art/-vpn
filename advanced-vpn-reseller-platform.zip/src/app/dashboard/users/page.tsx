import { desc, eq } from "drizzle-orm";
import QRCode from "qrcode";
import { db } from "@/db";
import { inbounds, panels, users, vpnUsers } from "@/db/schema";
import { requireUser } from "@/lib/auth";
import { buildClientConfig } from "@/lib/configs";
import { UsersView, type VpnRow } from "@/components/views/my-users";

export const dynamic = "force-dynamic";

export default async function MyUsersPage() {
  const s = await requireUser();
  const [user] = await db.select().from(users).where(eq(users.id, s.uid));

  const rows = await db
    .select({ vu: vpnUsers, ib: inbounds, panel: panels })
    .from(vpnUsers)
    .innerJoin(inbounds, eq(vpnUsers.inboundId, inbounds.id))
    .innerJoin(panels, eq(vpnUsers.panelId, panels.id))
    .where(eq(vpnUsers.ownerId, s.uid))
    .orderBy(desc(vpnUsers.createdAt))
    .limit(120);

  const shop = user.shopName || user.username;

  const list: VpnRow[] = await Promise.all(
    rows.map(async ({ vu, ib, panel }) => {
      const remark = `${vu.label} | ${shop}`;
      const config = buildClientConfig(vu, ib, panel, remark);
      let qr = "";
      try {
        qr = await QRCode.toDataURL(config, { margin: 1, width: 220, color: { dark: "#111a33", light: "#ffffff" } });
      } catch {}
      const expired = new Date(vu.expireAt).getTime() < Date.now();
      const displayStatus =
        vu.status === "disabled" ? "disabled" : expired ? "expired" : vu.status;
      return {
        id: vu.id,
        label: vu.label,
        email: vu.email,
        protocol: vu.protocol,
        inboundRemark: ib.remark,
        panelName: panel.name,
        location: panel.location,
        usedGb: Math.round(vu.usedGb * 100) / 100,
        dataLimitGb: vu.dataLimitGb,
        expireAt: vu.expireAt.toISOString(),
        ipLimit: vu.ipLimit,
        status: displayStatus,
        pricePerGb: ib.pricePerGb,
        pricePerMonth: ib.pricePerMonth,
        config,
        qr,
      };
    })
  );

  return <UsersView rows={list} balance={user.balance} shop={shop} />;
}
