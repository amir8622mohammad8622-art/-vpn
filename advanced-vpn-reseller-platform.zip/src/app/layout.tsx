import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { cookies } from "next/headers";
import { LanguageProvider } from "@/lib/i18n";
import { dirOf, type Lang } from "@/lib/lang";
import { ToastProvider } from "@/components/toast";
import "./globals.css";

export const metadata: Metadata = {
  title: "hector | هکتور — پنل نمایندگی و مدیریت VPN",
  description:
    "پنل نمایندگی VPN: اتصال خودکار به هر پنلی (3x-ui، X-UI، Marzban، WG-Easy)، مدیریت اینباندها، ساب‌لینک با برند شما، کیف پول کارت‌به‌کارت — VLESS, VMess, Trojan, Shadowsocks, WireGuard",
};

export const viewport: Viewport = {
  themeColor: "#0a0f1e",
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  viewportFit: "cover",
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const store = await cookies();
  const lang: Lang = store.get("nova_lang")?.value === "en" ? "en" : "fa";

  return (
    <html lang={lang} dir={dirOf(lang)} suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300..700&family=Vazirmatn:wght@100..900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#0a0f1e] text-slate-100 antialiased bg-noise min-h-screen">
        <LanguageProvider initial={lang}>
          <ToastProvider>{children}</ToastProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
