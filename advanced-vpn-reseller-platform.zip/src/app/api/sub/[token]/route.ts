import { eq, ne, and } from "drizzle-orm";
import { db } from "@/db";
import { inbounds, panels, users, vpnUsers } from "@/db/schema";
import { buildClientConfig, subUserInfo } from "@/lib/configs";

export const dynamic = "force-dynamic";

export async function GET(
  req: Request,
  { params }: { params: Promise<{ token: string }> }
) {
  const { token } = await params;
  if (!token || token.length < 8)
    return new Response("not found", { status: 404 });

  const [owner] = await db.select().from(users).where(eq(users.subToken, token));
  if (!owner) return new Response("not found", { status: 404 });
  if (owner.status === "banned") return new Response("suspended", { status: 403 });

  const rows = await db
    .select({ vu: vpnUsers, ib: inbounds, panel: panels })
    .from(vpnUsers)
    .innerJoin(inbounds, eq(vpnUsers.inboundId, inbounds.id))
    .innerJoin(panels, eq(vpnUsers.panelId, panels.id))
    .where(and(eq(vpnUsers.ownerId, owner.id), ne(vpnUsers.status, "disabled")));

  const shop = owner.shopName || owner.username;
  const configs = rows
    .filter(({ vu }) => new Date(vu.expireAt).getTime() > Date.now())
    .map(({ vu, ib, panel }) =>
      buildClientConfig(vu, ib, panel, `${vu.label} | ${shop}`)
    );

  const url = new URL(req.url);
  const ua = req.headers.get("user-agent") ?? "";
  const wantB64 =
    url.searchParams.get("b64") === "1" || /v2rayNG|v2rayN|okhttp/i.test(ua);

  const body = wantB64
    ? Buffer.from(configs.join("\n"), "utf-8").toString("base64")
    : configs.join("\n");

  const headers = new Headers({
    "content-type": "text/plain; charset=utf-8",
    "profile-title": Buffer.from(shop, "utf-8").toString("base64"),
    "profile-update-interval": "6",
    "subscription-userinfo": subUserInfo(rows.map((r) => r.vu)),
    "cache-control": "no-store",
  });

  return new Response(body, { headers });
}
