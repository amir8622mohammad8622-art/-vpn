import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { getSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX = 5 * 1024 * 1024;

export async function POST(req: Request) {
  const s = await getSession();
  if (!s) return Response.json({ ok: false, error: "err.unauth" }, { status: 401 });

  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) return Response.json({ ok: false, error: "err.upload" }, { status: 400 });
    if (file.size > MAX || !file.type.startsWith("image/"))
      return Response.json({ ok: false, error: "err.upload" }, { status: 400 });

    const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    const name = `${randomUUID()}.${ext}`;
    const dir = path.join(process.cwd(), "public", "uploads");
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));

    return Response.json({ ok: true, path: `/uploads/${name}` });
  } catch {
    return Response.json({ ok: false, error: "err.upload" }, { status: 500 });
  }
}
