import { db } from "@/db";
import { panels } from "@/db/schema";
import { syncPanel } from "@/lib/panel";

export const dynamic = "force-dynamic";

/**
 * Periodic panel sync + traffic simulation.
 * Protect with CRON_SECRET (pass ?secret= or x-cron-secret header).
 * Example external call:  curl https://your-site/api/cron/sync?secret=XYZ
 */
export async function GET(req: Request) {
  const expected = process.env.CRON_SECRET;
  if (expected) {
    const url = new URL(req.url);
    const given = req.headers.get("x-cron-secret") ?? url.searchParams.get("secret");
    if (given !== expected) return new Response("forbidden", { status: 403 });
  }

  const all = await db.select().from(panels);
  const results: Record<string, unknown>[] = [];
  for (const p of all) {
    const r = await syncPanel(p.id);
    results.push({ id: p.id, name: p.name, ...r });
  }
  return Response.json({ ok: true, synced: all.length, results });
}
