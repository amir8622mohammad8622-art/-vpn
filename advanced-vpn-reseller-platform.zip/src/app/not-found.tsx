import Link from "next/link";
import { Compass } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-clip px-6">
      <div className="absolute inset-0 bg-grid" />
      <div className="orb w-[420px] h-[420px] bg-[#d4a800]/18 -top-24 -start-24" />
      <div className="orb w-[380px] h-[380px] bg-[#38e1d4]/12 -bottom-24 -end-20" />
      <div className="relative glass-deep edge-glow rounded-[32px] p-10 sm:p-14 text-center max-w-md w-full">
        <div className="mx-auto w-16 h-16 rounded-3xl bg-[#d4a800]/15 border border-[#d4a800]/35 flex items-center justify-center text-[#f5c518]">
          <Compass size={28} />
        </div>
        <div className="mt-6 text-6xl font-black text-grad">404</div>
        <p className="mt-3 text-sm text-slate-400 leading-7">
          صفحه‌ای که دنبالش بودی پیدا نشد
          <br />
          <span className="text-slate-500 text-xs">The page you are looking for could not be found</span>
        </p>
        <Link
          href="/"
          className="mt-7 inline-flex items-center gap-2 rounded-2xl px-6 py-3 font-bold text-white bg-gradient-to-l from-[#d4a800] to-[#e8b800] shadow-[0_12px_34px_-10px_rgba(212,168,0,.8)] hover:-translate-y-0.5 transition-transform"
        >
          بازگشت به خانه · Home
        </Link>
      </div>
    </div>
  );
}
