import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { inbounds, panels } from "@/db/schema";
import { getSession } from "@/lib/auth";
import { Landing, type LivePrice } from "@/components/landing";

export const dynamic = "force-dynamic";

export default async function Home() {
  const session = await getSession();
  let livePricing: LivePrice[] = [];
  try {
    const rows = await db
      .select({ ib: inbounds, panel: panels })
      .from(inbounds)
      .innerJoin(panels, eq(inbounds.panelId, panels.id))
      .where(eq(inbounds.enabled, true))
      .orderBy(asc(inbounds.id))
      .limit(3);
    livePricing = rows
      .filter((r) => !r.panel.hidden)
      .map((r) => ({
        protocol: r.ib.protocol,
        remark: r.ib.remark,
        port: r.ib.port,
        pricePerGb: r.ib.pricePerGb,
        pricePerMonth: r.ib.pricePerMonth,
        location: r.panel.location,
      }));
  } catch {
    /* pre-migration fallback */
  }

  return <Landing loggedIn={!!session} livePricing={livePricing} />;
}
