import {
  pgTable,
  serial,
  varchar,
  integer,
  boolean,
  timestamp,
  text,
  real,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Users: admin + resellers (customers)                                */
/* ------------------------------------------------------------------ */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 64 }).notNull().unique(),
  email: varchar("email", { length: 160 }).notNull().default(""),
  emailVerified: boolean("email_verified").notNull().default(false),
  passwordHash: text("password_hash").notNull(),
  role: varchar("role", { length: 16 }).notNull().default("reseller"), // admin | reseller
  shopName: varchar("shop_name", { length: 90 }).notNull().default(""),
  subToken: varchar("sub_token", { length: 64 }).notNull().unique(),
  telegram: varchar("telegram", { length: 64 }).notNull().default(""),
  balance: integer("balance").notNull().default(0), // تومان
  totalSpent: integer("total_spent").notNull().default(0),
  status: varchar("status", { length: 16 }).notNull().default("active"), // active | banned
  adminNote: text("admin_note").notNull().default(""),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
  lastSeenAt: timestamp("last_seen_at", { mode: "date" }),
});

/* ------------------------------------------------------------------ */
/* Remote panels (3x-ui / x-ui) connected via API — or simulated demo   */
/* ------------------------------------------------------------------ */
export const panels = pgTable("panels", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 90 }).notNull(),
  type: varchar("type", { length: 16 }).notNull().default("demo"), // demo | xui
  baseUrl: text("base_url").notNull().default(""),
  subHost: varchar("sub_host", { length: 140 }).notNull().default(""),
  apiUsername: varchar("api_username", { length: 90 }).notNull().default(""),
  apiPassword: text("api_password").notNull().default(""),
  location: varchar("location", { length: 12 }).notNull().default("DE"),
  status: varchar("status", { length: 16 }).notNull().default("online"), // online | offline
  hidden: boolean("hidden").notNull().default(false),
  lastSyncAt: timestamp("last_sync_at", { mode: "date" }),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Inbounds cached from panels (protocol is locked for resellers)       */
/* ------------------------------------------------------------------ */
export const inbounds = pgTable("inbounds", {
  id: serial("id").primaryKey(),
  panelId: integer("panel_id")
    .notNull()
    .references(() => panels.id, { onDelete: "cascade" }),
  remoteId: integer("remote_id").notNull().default(0),
  remoteTag: varchar("remote_tag", { length: 140 }).notNull().default(""),
  remark: varchar("remark", { length: 140 }).notNull(),
  protocol: varchar("protocol", { length: 24 }).notNull(),
  port: integer("port").notNull(),
  network: varchar("network", { length: 16 }).notNull().default("tcp"),
  security: varchar("security", { length: 16 }).notNull().default("none"),
  sni: varchar("sni", { length: 140 }).notNull().default(""),
  path: varchar("path", { length: 140 }).notNull().default(""),
  hostHeader: varchar("host_header", { length: 140 }).notNull().default(""),
  pbk: text("pbk").notNull().default(""),
  sid: varchar("sid", { length: 40 }).notNull().default(""),
  flow: varchar("flow", { length: 48 }).notNull().default(""),
  method: varchar("method", { length: 48 }).notNull().default(""),
  enabled: boolean("enabled").notNull().default(true),
  pricePerGb: integer("price_per_gb").notNull().default(3000),
  pricePerMonth: integer("price_per_month").notNull().default(10000),
  totalClients: integer("total_clients").notNull().default(0),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* VPN clients created by resellers on inbounds                         */
/* ------------------------------------------------------------------ */
export const vpnUsers = pgTable(
  "vpn_users",
  {
    id: serial("id").primaryKey(),
    ownerId: integer("owner_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    panelId: integer("panel_id")
      .notNull()
      .references(() => panels.id, { onDelete: "cascade" }),
    inboundId: integer("inbound_id")
      .notNull()
      .references(() => inbounds.id, { onDelete: "cascade" }),
    clientUuid: varchar("client_uuid", { length: 64 }).notNull(),
    email: varchar("email", { length: 160 }).notNull(),
    label: varchar("label", { length: 140 }).notNull(),
    protocol: varchar("protocol", { length: 24 }).notNull(),
    dataLimitGb: real("data_limit_gb").notNull(),
    usedGb: real("used_gb").notNull().default(0),
    expireAt: timestamp("expire_at", { mode: "date" }).notNull(),
    ipLimit: integer("ip_limit").notNull().default(0), // 0 = unlimited
    status: varchar("status", { length: 16 }).notNull().default("active"), // active | disabled | depleted | expired
    secret: text("secret").notNull().default(""), // wireguard keys / ss password (JSON)
    createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { mode: "date" }).notNull().defaultNow(),
  },
  (t) => [index("vpn_users_owner_idx").on(t.ownerId), index("vpn_users_inbound_idx").on(t.inboundId)]
);

/* ------------------------------------------------------------------ */
/* Wallet ledger                                                        */
/* ------------------------------------------------------------------ */
export const transactions = pgTable(
  "transactions",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 20 }).notNull(), // charge | purchase | refund | adjust
    amount: integer("amount").notNull(), // signed, toman
    balanceAfter: integer("balance_after").notNull(),
    method: varchar("method", { length: 20 }).notNull().default("system"), // card | wallet | admin | system
    status: varchar("status", { length: 16 }).notNull().default("completed"), // completed | pending | rejected
    description: text("description").notNull().default(""),
    createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
  },
  (t) => [index("transactions_user_idx").on(t.userId)]
);

/* ------------------------------------------------------------------ */
/* Card-to-card top-up requests (receipt upload + admin approval)       */
/* ------------------------------------------------------------------ */
export const paymentRequests = pgTable(
  "payment_requests",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    amount: integer("amount").notNull(),
    receiptPath: text("receipt_path").notNull().default(""),
    status: varchar("status", { length: 16 }).notNull().default("pending"), // pending | approved | rejected
    adminNote: text("admin_note").notNull().default(""),
    createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
    reviewedAt: timestamp("reviewed_at", { mode: "date" }),
  },
  (t) => [index("payment_status_idx").on(t.status)]
);

/* ------------------------------------------------------------------ */
/* Support tickets                                                      */
/* ------------------------------------------------------------------ */
export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 160 }).notNull(),
  status: varchar("status", { length: 16 }).notNull().default("open"), // open | answered | closed
  priority: varchar("priority", { length: 16 }).notNull().default("normal"),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { mode: "date" }).notNull().defaultNow(),
});

export const ticketMessages = pgTable("ticket_messages", {
  id: serial("id").primaryKey(),
  ticketId: integer("ticket_id")
    .notNull()
    .references(() => tickets.id, { onDelete: "cascade" }),
  senderId: integer("sender_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  body: text("body").notNull(),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
});

/* ------------------------------------------------------------------ */
/* Key/value settings                                                   */
/* ------------------------------------------------------------------ */
export const settings = pgTable("settings", {
  key: varchar("key", { length: 60 }).primaryKey(),
  value: text("value").notNull().default(""),
});

/* ------------------------------------------------------------------ */
/* OTP codes for email verification & password reset                   */
/* ------------------------------------------------------------------ */
export const otpCodes = pgTable("otp_codes", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 160 }).notNull(),
  code: varchar("code", { length: 8 }).notNull(),
  purpose: varchar("purpose", { length: 20 }).notNull(), // register | login | reset
  expiresAt: timestamp("expires_at", { mode: "date" }).notNull(),
  used: boolean("used").notNull().default(false),
  createdAt: timestamp("created_at", { mode: "date" }).notNull().defaultNow(),
});

export type User = typeof users.$inferSelect;
export type Panel = typeof panels.$inferSelect;
export type Inbound = typeof inbounds.$inferSelect;
export type VpnUser = typeof vpnUsers.$inferSelect;
export type Transaction = typeof transactions.$inferSelect;
export type PaymentRequest = typeof paymentRequests.$inferSelect;
export type Ticket = typeof tickets.$inferSelect;
export type TicketMessage = typeof ticketMessages.$inferSelect;
