import "dotenv/config";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db, pool } from "./index";
import {
  inbounds,
  panels,
  settings,
  ticketMessages,
  tickets,
  transactions,
  users,
  vpnUsers,
} from "./schema";
import { addDays, genWireGuardKeys, newUuid, randomToken } from "../lib/utils";

async function main() {
  const [existing] = await db.select().from(users).where(eq(users.username, "admin"));
  if (existing) {
    console.log("seed: admin exists, skipping");
    return;
  }

  console.log("seed: creating settings…");
  const defaults: Record<string, string> = {
    card_number: "6037 9971 3200 8814",
    card_holder: "hector Pay",
    min_charge: "50000",
    support_user: "@hector_support",
    announcement:
      "به هکتور خوش اومدید! برای شارژ حساب از بخش کیف پول اقدام کنید؛ رسیدها معمولاً زیر ۳۰ دقیقه تایید می‌شن.",
  };
  for (const [key, value] of Object.entries(defaults)) {
    await db
      .insert(settings)
      .values({ key, value })
      .onConflictDoUpdate({ target: settings.key, set: { value } });
  }

  console.log("seed: creating users…");
  const [admin] = await db
    .insert(users)
    .values({
      username: "admin",
      passwordHash: await bcrypt.hash("admin123", 10),
      role: "admin",
      shopName: "hector HQ",
      subToken: randomToken(16),
      balance: 0,
    })
    .returning();

  const [demo] = await db
    .insert(users)
    .values({
      username: "demo",
      passwordHash: await bcrypt.hash("demo123", 10),
      role: "reseller",
      shopName: "استار VPN",
      telegram: "@star_vpn",
      subToken: randomToken(16),
      balance: 850000,
      totalSpent: 154500,
    })
    .returning();

  console.log("seed: creating panels & inbounds…");
  const [de] = await db
    .insert(panels)
    .values({
      name: "Germany Core",
      type: "demo",
      baseUrl: "demo://de-core",
      subHost: "de-1.nova-vps.io",
      location: "DE",
      status: "online",
      lastSyncAt: new Date(),
    })
    .returning();

  const [nl] = await db
    .insert(panels)
    .values({
      name: "Netherlands Edge",
      type: "demo",
      baseUrl: "demo://nl-edge",
      subHost: "nl-2.nova-vps.io",
      location: "NL",
      status: "online",
      lastSyncAt: new Date(),
    })
    .returning();

  const [tr] = await db
    .insert(panels)
    .values({
      name: "Turkey Budget",
      type: "demo",
      baseUrl: "demo://tr-budget",
      subHost: "tr-1.nova-vps.io",
      location: "TR",
      status: "online",
      lastSyncAt: new Date(),
    })
    .returning();

  const [vlessIb] = await db
    .insert(inbounds)
    .values({
      panelId: de.id,
      remoteId: 1,
      remark: "Germany 01 — VLESS Reality",
      protocol: "vless",
      port: 443,
      network: "tcp",
      security: "reality",
      sni: "www.microsoft.com",
      pbk: "mVf8KZQ2x1pY7sA9dN4hJ6uT3wE0rI5oP8gF2cV1bN0",
      sid: "6ba85179e30d4fc2",
      flow: "xtls-rprx-vision",
      pricePerGb: 4500,
      pricePerMonth: 12000,
      totalClients: 2,
    })
    .returning();

  const [trojanIb] = await db
    .insert(inbounds)
    .values({
      panelId: nl.id,
      remoteId: 2,
      remark: "Netherlands — Trojan WS+TLS",
      protocol: "trojan",
      port: 8443,
      network: "ws",
      security: "tls",
      sni: "cdn.nova-vps.io",
      path: "/trojan-ws",
      hostHeader: "cdn.nova-vps.io",
      pricePerGb: 3800,
      pricePerMonth: 10000,
      totalClients: 1,
    })
    .returning();

  const [wgIb] = await db
    .insert(inbounds)
    .values({
      panelId: tr.id,
      remoteId: 3,
      remark: "Turkey — WireGuard Fast",
      protocol: "wireguard",
      port: 51820,
      network: "udp",
      security: "none",
      pbk: "pK3sA9dN4hJ6uT3wE0rI5oP8gF2cV1bN0mVf8KZQ2x1p",
      pricePerGb: 3200,
      pricePerMonth: 9000,
      totalClients: 1,
    })
    .returning();

  const [vmessIb] = await db
    .insert(inbounds)
    .values({
      panelId: de.id,
      remoteId: 4,
      remark: "Germany 02 — VMess WS",
      protocol: "vmess",
      port: 2053,
      network: "ws",
      security: "tls",
      sni: "de-1.nova-vps.io",
      path: "/vmess-ws",
      hostHeader: "de-1.nova-vps.io",
      pricePerGb: 3000,
      pricePerMonth: 8000,
      totalClients: 0,
    })
    .returning();

  await db.insert(inbounds).values({
    panelId: nl.id,
    remoteId: 5,
    remark: "Netherlands — Shadowsocks 2022",
    protocol: "shadowsocks",
    port: 8388,
    network: "tcp",
    security: "none",
    method: "2022-blake3-aes-128-gcm",
    pricePerGb: 2500,
    pricePerMonth: 7000,
    totalClients: 0,
  });

  console.log("seed: demo vpn users…");
  const wgKeys = genWireGuardKeys();
  const demos = [
    {
      ib: vlessIb,
      panelId: de.id,
      label: "اشتراک حرفه‌ای — ماهانه",
      gb: 100,
      used: 47.32,
      days: 22,
      ipLimit: 2,
      secret: "",
    },
    {
      ib: trojanIb,
      panelId: nl.id,
      label: "VIP گیمینگ",
      gb: 50,
      used: 12.05,
      days: 15,
      ipLimit: 1,
      secret: "",
    },
    {
      ib: wgIb,
      panelId: tr.id,
      label: "وایرگارد اقتصادی",
      gb: 30,
      used: 29.6,
      days: 9,
      ipLimit: 0,
      secret: JSON.stringify(wgKeys),
    },
  ];

  for (const d of demos) {
    const status =
      d.used >= d.gb ? ("depleted" as const) : ("active" as const);
    await db.insert(vpnUsers).values({
      ownerId: demo.id,
      panelId: d.panelId,
      inboundId: d.ib.id,
      clientUuid: newUuid(),
      email: `${demo.id}.${randomToken(4)}`.toLowerCase(),
      label: d.label,
      protocol: d.ib.protocol,
      dataLimitGb: d.gb,
      usedGb: d.used,
      expireAt: addDays(new Date(), d.days),
      ipLimit: d.ipLimit,
      status,
      secret: d.secret,
    });
  }

  console.log("seed: transactions…");
  await db.insert(transactions).values([
    {
      userId: demo.id,
      type: "charge",
      amount: 1000000,
      balanceAfter: 1000000,
      method: "card",
      status: "completed",
      description: "card-to-card #1",
    },
    {
      userId: demo.id,
      type: "purchase",
      amount: -59800,
      balanceAfter: 940200,
      method: "wallet",
      status: "completed",
      description: "اشتراک حرفه‌ای — ماهانه · Germany 01",
    },
    {
      userId: demo.id,
      type: "purchase",
      amount: -95700,
      balanceAfter: 844500,
      method: "wallet",
      status: "completed",
      description: "VIP گیمینگ + وایرگارد اقتصادی",
    },
  ]);

  console.log("seed: ticket…");
  const [t] = await db
    .insert(tickets)
    .values({
      userId: demo.id,
      subject: "تغییر لوکیشن سرور آلمان",
      status: "answered",
    })
    .returning();
  await db.insert(ticketMessages).values([
    {
      ticketId: t.id,
      senderId: demo.id,
      body: "سلام، امکانش هست لوکیشن جدید فرانسه هم اضافه بشه؟ مشتری‌هام درخواست دارن.",
    },
    {
      ticketId: t.id,
      senderId: admin.id,
      body: "سلام! بله، هفته آینده دو لوکیشن جدید (فرانسه و فنلاند) به لیست اضافه می‌شه. اعلانش رو روی داشبورد می‌ذاریم.",
    },
  ]);

  console.log("seed: done ✔ admin/admin123 · demo/demo123");
}

main()
  .catch((e) => {
    console.error("seed failed:", e);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
